#!/usr/bin/env bash
# run.sh
#
# One-command launcher for the local training UI:
# - creates/uses .recorder-venv
# - installs pinned dependencies once
# - runs uvicorn from the venv (never uses global /opt/homebrew/bin/uvicorn)

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SUPPORT_DIR="${WAKEWORD_TRAINER_SUPPORT_DIR:-${HOME}/.taterwakewordtrainer}"
DATA_DIR="${WAKEWORD_TRAINER_DATA_DIR:-${SUPPORT_DIR}/app/current}"
mkdir -p "$DATA_DIR"
export WAKEWORD_TRAINER_SUPPORT_DIR="$SUPPORT_DIR"
export WAKEWORD_TRAINER_DATA_DIR="$DATA_DIR"
export PYTHONDONTWRITEBYTECODE="${PYTHONDONTWRITEBYTECODE:-1}"
cd "$ROOT_DIR"

VENV_DIR="${REC_VENV_DIR:-$SUPPORT_DIR/recorder-venv}"
export REC_VENV_DIR="$VENV_DIR"
PYTHON_BIN="${REC_PYTHON_BIN:-/opt/homebrew/bin/python3.11}"
PY="$VENV_DIR/bin/python"
PIP="$PY -m pip"
PIN_FILE="$VENV_DIR/.pinned_installed"

# Optional host/port
HOST="${REC_HOST:-0.0.0.0}"
PORT="${REC_PORT:-8789}"

# Pinned deps (edit if you want)
FASTAPI_VERSION="${REC_FASTAPI_VERSION:-0.115.6}"
UVICORN_VERSION="${REC_UVICORN_VERSION:-0.30.6}"
PY_MULTIPART_VERSION="${REC_PY_MULTIPART_VERSION:-0.0.9}"

UI_DEPENDENCIES=(
  "fastapi==${FASTAPI_VERSION}"
  "uvicorn[standard]==${UVICORN_VERSION}"
  "python-multipart==${PY_MULTIPART_VERSION}"
  "silero-vad>=5.0.0"
  "numpy>=1.24.0"
  "mlx-whisper"
  "faster-whisper>=1.0.0"
  "onnx-asr[hub]>=0.12.0"
)

echo "🎙️ microWakeWord Trainer UI (local)"
echo "→ SOURCE: $ROOT_DIR"
echo "→ DATA: $DATA_DIR"
echo "→ VENV: $VENV_DIR"
echo "→ PYTHON_BIN: $PYTHON_BIN"

install_ui_deps() {
  $PIP install "${UI_DEPENDENCIES[@]}"
}

dependency_fingerprint() {
  printf '%s\n' "${UI_DEPENDENCIES[@]}" | /usr/bin/shasum -a 256 | awk '{print $1}'
}

record_dependency_fingerprint() {
  dependency_fingerprint > "$PIN_FILE"
}

if [[ ! -x "$PYTHON_BIN" ]]; then
  echo "❌ Required Python 3.11 interpreter not found at: $PYTHON_BIN"
  echo "   Install python@3.11 with Homebrew or set REC_PYTHON_BIN to your python3.11 path."
  exit 1
fi

# Create venv if missing
if [[ ! -x "$PY" ]]; then
  echo "🧹 Creating trainer UI venv: $VENV_DIR"
  "$PYTHON_BIN" -m venv "$VENV_DIR"
fi

# Always activate (handy for PATH vars), but we still use $PY explicitly
# shellcheck disable=SC1091
source "$VENV_DIR/bin/activate"

# Install dependencies whenever their specification changes. Existing empty
# marker files from older releases intentionally trigger one refresh.
EXPECTED_DEPENDENCY_FINGERPRINT="$(dependency_fingerprint)"
INSTALLED_DEPENDENCY_FINGERPRINT="$(tr -d '[:space:]' < "$PIN_FILE" 2>/dev/null || true)"
if [[ "$INSTALLED_DEPENDENCY_FINGERPRINT" != "$EXPECTED_DEPENDENCY_FINGERPRINT" ]]; then
  if [[ -f "$PIN_FILE" ]]; then
    echo "📦 Trainer UI dependencies changed → refreshing recorder dependencies"
  else
    echo "🧹 Fresh trainer UI venv → installing pinned dependencies"
  fi
  $PIP install -U pip setuptools wheel

  install_ui_deps
  record_dependency_fingerprint
else
  echo "✅ Reusing existing .recorder-venv (dependencies match)"
  if ! "$PY" - "$FASTAPI_VERSION" "$UVICORN_VERSION" "$PY_MULTIPART_VERSION" <<'PY' >/dev/null 2>&1
import importlib.metadata as md
import sys

fastapi_version, uvicorn_version, multipart_version = sys.argv[1:4]

def version_tuple(value):
    parts = []
    for token in str(value).replace("-", ".").split("."):
        if token.isdigit():
            parts.append(int(token))
        else:
            digits = "".join(ch for ch in token if ch.isdigit())
            if digits:
                parts.append(int(digits))
            break
    return tuple(parts)

exact = {
    "fastapi": fastapi_version,
    "uvicorn": uvicorn_version,
    "python-multipart": multipart_version,
}
minimum = {
    "silero-vad": "5.0.0",
    "numpy": "1.24.0",
    "faster-whisper": "1.0.0",
    "onnx-asr": "0.12.0",
}
present = ("torch", "mlx-whisper", "onnxruntime")

for package, expected in exact.items():
    if md.version(package) != expected:
        raise SystemExit(1)
for package, minimum_version in minimum.items():
    if version_tuple(md.version(package)) < version_tuple(minimum_version):
        raise SystemExit(1)
for package in present:
    md.version(package)
PY
  then
    echo "📦 UI dependencies missing or stale → installing recorder dependencies"
    install_ui_deps
    record_dependency_fingerprint
  fi
fi

# HARD FAIL: ensure pip is the venv pip
VENV_PREFIX="$("$PY" -c 'import sys; print(sys.prefix)')"
$PIP -V | grep -q "$VENV_PREFIX" || {
  echo "❌ pip is not using venv ($VENV_PREFIX)"
  $PIP -V
  exit 1
}

# HARD FAIL: ensure uvicorn is the venv one
UVICORN="$VENV_DIR/bin/uvicorn"
if [[ ! -x "$UVICORN" ]]; then
  echo "❌ uvicorn not found in venv: $UVICORN"
  echo "   Try: $PIP install 'uvicorn[standard]'"
  exit 1
fi

echo "→ Launching: $UVICORN trainer_server:app --host $HOST --port $PORT"
exec "$UVICORN" trainer_server:app --host "$HOST" --port "$PORT"
