# scripts_macos/make_features.py

import os
import sys

from mmap_ninja.ragged import RaggedMmap
from microwakeword.audio.augmentation import Augmentation
from microwakeword.audio.clips import Clips
from microwakeword.audio.spectrograms import SpectrogramGeneration
from pathlib import Path
from training_progress import tracked_generator

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(line_buffering=True, write_through=True)
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(line_buffering=True, write_through=True)


def validate(paths):
    for p in paths:
        if not os.path.exists(p):
            raise SystemExit(f"❌ Missing directory: {p}. Run dataset prep first.")
    print(f"✅ Validated all {len(paths)} dataset directories")


impulse_paths = ["mit_rirs"]
background_paths = [
    "chime_16k",
    "fma_16k",
    "audioset_16k",
]
validate(impulse_paths + background_paths)
print("⏳ Preparing clip indexes and augmentation pipeline (please wait)…")

tts_wav_count = len(list(Path("./generated_samples").glob("*.wav")))
print(f"🎤 Generated sample count: {tts_wav_count}")

# Process TTS generated samples (default)
clips_tts = Clips(
    input_directory="./generated_samples",
    file_pattern="*.wav",
    max_clip_duration_s=5,
    remove_silence=True,
    random_split_seed=10,
    split_count=0.1,
)

# Process personal recordings if available (optional)
clips_personal = None
if os.path.exists("./personal_samples") and any(Path("./personal_samples").glob("*.wav")):
    clips_personal = Clips(
        input_directory="./personal_samples",
        file_pattern="*.wav",
        max_clip_duration_s=5,
        remove_silence=True,
        random_split_seed=10,
        split_count=0.1,
    )
    print("✅ Found personal samples, will create separate feature set")
else:
    print("ℹ️ No personal samples found; continuing with generated samples only")

# Process reviewed false-positive samples if available (optional)
clips_reviewed_negative = None
if os.path.exists("./negative_samples") and any(Path("./negative_samples").glob("*.wav")):
    clips_reviewed_negative = Clips(
        input_directory="./negative_samples",
        file_pattern="*.wav",
        max_clip_duration_s=5,
        remove_silence=False,
        random_split_seed=10,
        split_count=0.1,
    )
    print("✅ Found reviewed negative samples, will create a separate negative feature set")
else:
    print("ℹ️ No reviewed negative samples found; continuing with stock negative datasets only")

# Process generated near-miss phrases as a separately weighted hard-negative
# source. Keeping this corpus separate lets reviewed real-world false wakes
# retain their stronger weight in the training configuration.
clips_generated_negative = None
generated_negative_dir = Path("./generated_negative_samples/combined")
if generated_negative_dir.exists() and any(generated_negative_dir.glob("*.wav")):
    clips_generated_negative = Clips(
        input_directory=str(generated_negative_dir),
        file_pattern="*.wav",
        max_clip_duration_s=5,
        remove_silence=True,
        random_split_seed=10,
        split_count=0.1,
    )
    print("✅ Found generated near-miss samples, will create a separate hard-negative feature set")
else:
    print("ℹ️ No generated near-miss samples selected")

# Wake+immediate-speech clips are the essential boundary supervision. They are
# negative only at the end of the clip; paired wake-only clips remain positive,
# teaching the streaming network to peak at the acoustic phrase endpoint and
# decay as soon as command speech begins.
clips_boundary_negative = None
boundary_negative_dir = Path("./boundary_negative_samples")
if boundary_negative_dir.exists() and any(boundary_negative_dir.glob("*.wav")):
    clips_boundary_negative = Clips(
        input_directory=str(boundary_negative_dir),
        file_pattern="*.wav",
        max_clip_duration_s=5,
        remove_silence=False,
        random_split_seed=10,
        split_count=0.1,
    )
    print("✅ Found wake+speech endpoint hard negatives")
else:
    raise SystemExit("❌ Missing boundary_negative_samples; endpoint model cannot be trained")

augmenter = Augmentation(
    augmentation_duration_s=3.2,
    augmentation_probabilities={
        "SevenBandParametricEQ": 0.1,
        "TanhDistortion": 0.05,
        "PitchShift": 0.15,
        "BandStopFilter": 0.1,
        "AddColorNoise": 0.1,
        "AddBackgroundNoise": 0.7,
        "Gain": 0.8,
        "RIR": 0.7,
    },
    impulse_paths=impulse_paths,
    background_paths=background_paths,
    background_min_snr_db=5,
    background_max_snr_db=10,
    min_jitter_s=0.2,
    max_jitter_s=0.3,
)

out_root = Path("generated_augmented_features")
out_root.mkdir(exist_ok=True)

split_cfg = {
    "training":   {"name": "train",      "repetition": 2, "slide_frames": 10},
    "validation": {"name": "validation", "repetition": 1, "slide_frames": 10},
    "testing":    {"name": "test",       "repetition": 1, "slide_frames": 1},
}


def write_feature_mmap(*, clips, split, cfg, out_dir, source_label):
    """Build one mmap with an exact, UI-readable feature total."""
    spectros = SpectrogramGeneration(
        clips=clips,
        augmenter=augmenter,
        slide_frames=cfg["slide_frames"],
        step_ms=10,
    )
    clip_count = len(clips.split_clips[cfg["name"]])
    total = clip_count * cfg["repetition"] * cfg["slide_frames"]
    generator = tracked_generator(
        spectros.spectrogram_generator(
            split=cfg["name"],
            repeat=cfg["repetition"],
        ),
        total=total,
        stage=f"features:{source_label.lower().replace(' ', '-')}:{split}",
        label=f"{source_label} · {split.title()} features",
        unit="features",
    )
    RaggedMmap.from_generator(
        out_dir=str(out_dir / "wakeword_mmap"),
        sample_generator=generator,
        batch_size=100,
        verbose=False,
    )

# Process TTS samples
for split, cfg in split_cfg.items():
    out_dir = out_root / split
    out_dir.mkdir(parents=True, exist_ok=True)
    print(f"🧪 Processing {split} (TTS) …")
    print("⏳ Building spectrogram mmap; first progress update can take a moment…")
    write_feature_mmap(
        clips=clips_tts, split=split, cfg=cfg, out_dir=out_dir, source_label="TTS"
    )

# Process personal samples if available
if clips_personal is not None:
    out_root_personal = Path("personal_augmented_features")
    out_root_personal.mkdir(exist_ok=True)
    for split, cfg in split_cfg.items():
        out_dir = out_root_personal / split
        out_dir.mkdir(parents=True, exist_ok=True)
        print(f"🧪 Processing {split} (personal) …")
        print("⏳ Building personal spectrogram mmap; first progress update can take a moment…")
        write_feature_mmap(
            clips=clips_personal,
            split=split,
            cfg=cfg,
            out_dir=out_dir,
            source_label="Personal",
        )

# Process reviewed negative samples if available
if clips_reviewed_negative is not None:
    out_root_negative = Path("reviewed_negative_features")
    out_root_negative.mkdir(exist_ok=True)
    for split, cfg in split_cfg.items():
        out_dir = out_root_negative / split
        out_dir.mkdir(parents=True, exist_ok=True)
        print(f"🧪 Processing {split} (reviewed negatives) …")
        print("⏳ Building reviewed negative spectrogram mmap; first progress update can take a moment…")
        write_feature_mmap(
            clips=clips_reviewed_negative,
            split=split,
            cfg=cfg,
            out_dir=out_dir,
            source_label="Reviewed negatives",
        )

# Process generated near-miss samples if available. Clips creates deterministic
# training/validation/testing partitions, so quality evaluation never reuses
# the exact generated utterances seen during optimization.
if clips_generated_negative is not None:
    out_root_generated_negative = Path("generated_negative_features")
    out_root_generated_negative.mkdir(exist_ok=True)
    for split, cfg in split_cfg.items():
        out_dir = out_root_generated_negative / split
        out_dir.mkdir(parents=True, exist_ok=True)
        print(f"🧪 Processing {split} (generated hard negatives) …")
        print("⏳ Building generated hard-negative spectrogram mmap; first progress update can take a moment…")
        write_feature_mmap(
            clips=clips_generated_negative,
            split=split,
            cfg=cfg,
            out_dir=out_dir,
            source_label="Generated hard negatives",
        )

if clips_boundary_negative is not None:
    out_root_boundary = Path("boundary_negative_features")
    out_root_boundary.mkdir(exist_ok=True)
    for split, cfg in split_cfg.items():
        out_dir = out_root_boundary / split
        out_dir.mkdir(parents=True, exist_ok=True)
        print(f"🧪 Processing {split} (wake endpoint hard negatives) …")
        write_feature_mmap(
            clips=clips_boundary_negative,
            split=split,
            cfg=cfg,
            out_dir=out_dir,
            source_label="Wake endpoint negatives",
        )
print("✅ Features ready.")
