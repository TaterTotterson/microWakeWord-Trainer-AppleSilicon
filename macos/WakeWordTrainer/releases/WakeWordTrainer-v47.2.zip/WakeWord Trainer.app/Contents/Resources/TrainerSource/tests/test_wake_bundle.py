import json
import tempfile
import unittest
from pathlib import Path

from wake_bundle import (
    bundle_catalog_fields,
    esphome_manifest,
    migrate_legacy_micro_manifest,
    publish_micro_wake_word,
    publish_nano_wake_word,
    publish_open_wake_word,
)


class WakeBundleTests(unittest.TestCase):
    def test_public_bundle_omits_private_training_paths_and_diagnostics(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            oww = root / "hey_tater.oww.onnx"
            nww = root / "hey_tater.nww.cnn.onnx"
            oww.write_bytes(b"oww")
            nww.write_bytes(b"nww")
            stale_files = (
                root / "hey_tater.oww.json",
                root / "hey_tater.nww.cnn.json",
                root / "hey_tater.nww.dnn.json",
                root / "hey_tater.nww.dnn.onnx",
            )
            for stale in stale_files:
                stale.write_text("private", encoding="utf-8")
            publish_open_wake_word(
                trained_dir=root,
                safe_word="hey_tater",
                phrase="hey tater",
                metadata={
                    "config_path": "/Users/test/private/config.yaml",
                    "quality": {"examples": [{"path": "/Users/test/private/clip.wav"}]},
                    "model_name": "hey_tater",
                },
                artifacts={"onnx": {"file": oww.name, "sha256": "a" * 64, "size_bytes": 3}},
                recommended_threshold=0.92,
                recommended_patience=3,
                recommended_confirmation_threshold=0.96,
                recommended_confirmation_patience=3,
            )
            publish_nano_wake_word(
                trained_dir=root,
                safe_word="hey_tater",
                phrase="hey tater",
                architecture="cnn",
                metadata={
                    "name": "hey_tater",
                    "quality": {"validation": {"model": "/Volumes/private/model.onnx"}},
                    "feature_bank_dir": "/Volumes/private/features",
                },
                model_path=nww,
            )
            raw = (root / "hey_tater.wake-bundle.json").read_text(encoding="utf-8")
            bundle = json.loads(raw)
            self.assertNotIn("/Users/", raw)
            self.assertNotIn("/Volumes/", raw)
            self.assertNotIn("quality", bundle["nano_wake_word"]["variants"]["cnn"])
            self.assertNotIn("config_path", bundle["open_wake_word"])
            self.assertFalse(any(stale.exists() for stale in stale_files))

    def test_legacy_micro_json_is_removed_after_successful_migration(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            model = root / "hey_tater.tflite"
            legacy = root / "hey_tater.json"
            model.write_bytes(b"model")
            legacy.write_text(
                json.dumps({"type": "micro", "wake_word": "hey tater", "model": model.name}),
                encoding="utf-8",
            )

            migrated = migrate_legacy_micro_manifest(root, legacy)

            self.assertEqual(migrated, (root / "hey_tater.wake-bundle.json").resolve())
            self.assertFalse(legacy.exists())

    def test_mix_and_match_models_share_one_self_contained_bundle(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            mww = root / "hey_tater.tflite"
            oww = root / "hey_tater.oww.onnx"
            cnn = root / "hey_tater.nww.cnn.onnx"
            gru = root / "hey_tater.nww.gru.onnx"
            for path in (mww, oww, cnn, gru):
                path.write_bytes(path.name.encode())

            publish_micro_wake_word(
                trained_dir=root,
                safe_word="hey_tater",
                phrase="hey tater",
                metadata={"type": "micro", "wake_word": "hey tater", "model": mww.name, "micro": {"probability_cutoff": 0.95}},
                model_path=mww,
            )
            publish_open_wake_word(
                trained_dir=root,
                safe_word="hey_tater",
                phrase="hey tater",
                metadata={"calibration": {"passed": True}},
                artifacts={"onnx": {"file": oww.name, "sha256": "abc", "size_bytes": oww.stat().st_size}},
                recommended_threshold=0.92,
                recommended_patience=3,
                recommended_confirmation_threshold=0.88,
                recommended_confirmation_patience=2,
            )
            bundle_path = root / "hey_tater.wake-bundle.json"
            stale = json.loads(bundle_path.read_text(encoding="utf-8"))
            stale["nano_wake_word"] = {
                "default_architecture": "dnn",
                "variants": {"dnn": {"model": "obsolete.onnx"}},
            }
            bundle_path.write_text(json.dumps(stale), encoding="utf-8")
            for architecture, model in (("cnn", cnn), ("gru", gru)):
                publish_nano_wake_word(
                    trained_dir=root,
                    safe_word="hey_tater",
                    phrase="hey tater",
                    architecture=architecture,
                    metadata={"validation": {"passed": True}},
                    model_path=model,
                )

            bundle = json.loads(bundle_path.read_text(encoding="utf-8"))
            self.assertEqual(bundle["schema_version"], 3)
            self.assertEqual(bundle["micro_wake_word"]["model"], mww.name)
            self.assertNotIn("manifest", bundle["micro_wake_word"])
            self.assertNotIn("calibration", bundle["open_wake_word"])
            self.assertEqual(set(bundle["nano_wake_word"]["variants"]), {"cnn", "gru"})
            self.assertEqual(bundle["nano_wake_word"]["default_architecture"], "cnn")
            self.assertEqual(esphome_manifest(bundle["micro_wake_word"])["type"], "micro")

            catalog = bundle_catalog_fields(root, "hey_tater", "http://trainer.test")
            self.assertEqual(catalog["available_engines"], ["micro_wake_word", "open_wake_word", "nano_wake_word"])
            self.assertEqual(set(catalog["nanowakeword_architectures"]), {"cnn", "gru"})

    def test_nano_default_uses_streaming_quality_instead_of_fixed_cnn(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            cnn = root / "wake.nww.cnn.onnx"
            gru = root / "wake.nww.gru.onnx"
            cnn.write_bytes(b"cnn")
            gru.write_bytes(b"gru")
            publish_nano_wake_word(
                trained_dir=root, safe_word="wake", phrase="wake", architecture="cnn",
                metadata={"quality_summary": {"recall": 0.97, "negative_rate": 0.065}},
                model_path=cnn, recommended_patience=3,
            )
            bundle_path = publish_nano_wake_word(
                trained_dir=root, safe_word="wake", phrase="wake", architecture="gru",
                metadata={"quality_summary": {"recall": 0.96, "negative_rate": 0.015}},
                model_path=gru, recommended_patience=3,
            )
            bundle = json.loads(bundle_path.read_text(encoding="utf-8"))
            self.assertEqual(bundle["nano_wake_word"]["default_architecture"], "gru")

    def test_nano_default_prefers_a_passing_variant(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            cnn = root / "wake.nww.cnn.onnx"
            gru = root / "wake.nww.gru.onnx"
            cnn.write_bytes(b"cnn")
            gru.write_bytes(b"gru")
            publish_nano_wake_word(
                trained_dir=root, safe_word="wake", phrase="wake", architecture="cnn",
                metadata={
                    "quality_status": "low_quality", "quality_passed": False,
                    "quality_summary": {"recall": 0.99, "negative_rate": 0.0},
                },
                model_path=cnn, recommended_patience=2,
            )
            bundle_path = publish_nano_wake_word(
                trained_dir=root, safe_word="wake", phrase="wake", architecture="gru",
                metadata={
                    "quality_status": "passed", "quality_passed": True,
                    "quality_summary": {"recall": 0.95, "negative_rate": 0.04},
                },
                model_path=gru, recommended_patience=4,
            )
            bundle = json.loads(bundle_path.read_text(encoding="utf-8"))
            self.assertEqual(bundle["nano_wake_word"]["default_architecture"], "gru")


if __name__ == "__main__":
    unittest.main()
