//#region node_modules/@vue/shared/dist/shared.esm-bundler.js
// @__NO_SIDE_EFFECTS__
function e(e) {
	let t = /* @__PURE__ */ Object.create(null);
	for (let n of e.split(",")) t[n] = 1;
	return (e) => e in t;
}
var t = {}, n = [], r = () => {}, i = () => !1, a = (e) => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && (e.charCodeAt(2) > 122 || e.charCodeAt(2) < 97), o = (e) => e.startsWith("onUpdate:"), s = Object.assign, c = (e, t) => {
	let n = e.indexOf(t);
	n > -1 && e.splice(n, 1);
}, l = Object.prototype.hasOwnProperty, u = (e, t) => l.call(e, t), d = Array.isArray, f = (e) => x(e) === "[object Map]", p = (e) => x(e) === "[object Set]", m = (e) => x(e) === "[object Date]", h = (e) => typeof e == "function", g = (e) => typeof e == "string", _ = (e) => typeof e == "symbol", v = (e) => typeof e == "object" && !!e, y = (e) => (v(e) || h(e)) && h(e.then) && h(e.catch), b = Object.prototype.toString, x = (e) => b.call(e), S = (e) => x(e).slice(8, -1), C = (e) => x(e) === "[object Object]", w = (e) => g(e) && e !== "NaN" && e[0] !== "-" && "" + parseInt(e, 10) === e, ee = /* @__PURE__ */ e(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"), te = (e) => {
	let t = /* @__PURE__ */ Object.create(null);
	return ((n) => t[n] || (t[n] = e(n)));
}, ne = /-\w/g, T = te((e) => e.replace(ne, (e) => e.slice(1).toUpperCase())), re = /\B([A-Z])/g, E = te((e) => e.replace(re, "-$1").toLowerCase()), ie = te((e) => e.charAt(0).toUpperCase() + e.slice(1)), ae = te((e) => e ? `on${ie(e)}` : ""), oe = (e, t) => !Object.is(e, t), se = (e, ...t) => {
	for (let n = 0; n < e.length; n++) e[n](...t);
}, D = (e, t, n, r = !1) => {
	Object.defineProperty(e, t, {
		configurable: !0,
		enumerable: !1,
		writable: r,
		value: n
	});
}, ce = (e) => {
	let t = parseFloat(e);
	return isNaN(t) ? e : t;
}, le = (e) => {
	let t = g(e) ? Number(e) : NaN;
	return isNaN(t) ? e : t;
}, ue, de = () => ue ||= typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : typeof global < "u" ? global : {};
function fe(e) {
	if (d(e)) {
		let t = {};
		for (let n = 0; n < e.length; n++) {
			let r = e[n], i = g(r) ? ge(r) : fe(r);
			if (i) for (let e in i) t[e] = i[e];
		}
		return t;
	}
	if (g(e) || v(e)) return e;
}
var pe = /;(?![^(]*\))/g, me = /:([^]+)/, he = /\/\*[^]*?\*\//g;
function ge(e) {
	let t = {};
	return e.replace(he, "").split(pe).forEach((e) => {
		if (e) {
			let n = e.split(me);
			n.length > 1 && (t[n[0].trim()] = n[1].trim());
		}
	}), t;
}
function O(e) {
	let t = "";
	if (g(e)) t = e;
	else if (d(e)) for (let n = 0; n < e.length; n++) {
		let r = O(e[n]);
		r && (t += r + " ");
	}
	else if (v(e)) for (let n in e) e[n] && (t += n + " ");
	return t.trim();
}
var _e = "itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly", ve = /* @__PURE__ */ e(_e);
_e + "";
function ye(e) {
	return !!e || e === "";
}
function be(e, t) {
	if (e.length !== t.length) return !1;
	let n = !0;
	for (let r = 0; n && r < e.length; r++) n = xe(e[r], t[r]);
	return n;
}
function xe(e, t) {
	if (e === t) return !0;
	let n = m(e), r = m(t);
	if (n || r) return n && r ? e.getTime() === t.getTime() : !1;
	if (n = _(e), r = _(t), n || r) return e === t;
	if (n = d(e), r = d(t), n || r) return n && r ? be(e, t) : !1;
	if (n = v(e), r = v(t), n || r) {
		if (!n || !r || Object.keys(e).length !== Object.keys(t).length) return !1;
		for (let n in e) {
			let r = e.hasOwnProperty(n), i = t.hasOwnProperty(n);
			if (r && !i || !r && i || !xe(e[n], t[n])) return !1;
		}
	}
	return String(e) === String(t);
}
function Se(e, t) {
	return e.findIndex((e) => xe(e, t));
}
var Ce = (e) => !!(e && e.__v_isRef === !0), k = (e) => g(e) ? e : e == null ? "" : d(e) || v(e) && (e.toString === b || !h(e.toString)) ? Ce(e) ? k(e.value) : JSON.stringify(e, we, 2) : String(e), we = (e, t) => Ce(t) ? we(e, t.value) : f(t) ? { [`Map(${t.size})`]: [...t.entries()].reduce((e, [t, n], r) => (e[Te(t, r) + " =>"] = n, e), {}) } : p(t) ? { [`Set(${t.size})`]: [...t.values()].map((e) => Te(e)) } : _(t) ? Te(t) : v(t) && !d(t) && !C(t) ? String(t) : t, Te = (e, t = "") => _(e) ? `Symbol(${e.description ?? t})` : e, A, Ee = class {
	constructor(e = !1) {
		this.detached = e, this._active = !0, this._on = 0, this.effects = [], this.cleanups = [], this._isPaused = !1, this._warnOnRun = !0, this.__v_skip = !0, !e && A && (A.active ? (this.parent = A, this.index = (A.scopes || (A.scopes = [])).push(this) - 1) : (this._active = !1, this._warnOnRun = !1));
	}
	get active() {
		return this._active;
	}
	pause() {
		if (this._active) {
			this._isPaused = !0;
			let e, t;
			if (this.scopes) {
				let n = this.scopes.slice();
				for (e = 0, t = n.length; e < t; e++) n[e].pause();
			}
			for (e = 0, t = this.effects.length; e < t; e++) this.effects[e].pause();
		}
	}
	resume() {
		if (this._active && this._isPaused) {
			this._isPaused = !1;
			let e, t;
			if (this.scopes) {
				let n = this.scopes.slice();
				for (e = 0, t = n.length; e < t; e++) n[e].resume();
			}
			let n = this.effects.slice();
			for (e = 0, t = n.length; e < t; e++) n[e].resume();
		}
	}
	run(e) {
		if (this._active) {
			let t = A;
			try {
				return A = this, e();
			} finally {
				A = t;
			}
		}
	}
	on() {
		++this._on === 1 && (this.prevScope = A, A = this);
	}
	off() {
		if (this._on > 0 && --this._on === 0) {
			if (A === this) A = this.prevScope;
			else {
				let e = A;
				for (; e;) {
					if (e.prevScope === this) {
						e.prevScope = this.prevScope;
						break;
					}
					e = e.prevScope;
				}
			}
			this.prevScope = void 0;
		}
	}
	stop(e) {
		if (this._active) {
			this._active = !1;
			let t, n;
			for (t = 0, n = this.effects.length; t < n; t++) this.effects[t].stop();
			for (this.effects.length = 0, t = 0, n = this.cleanups.length; t < n; t++) this.cleanups[t]();
			if (this.cleanups.length = 0, this.scopes) {
				let e = this.scopes.slice();
				for (t = 0, n = e.length; t < n; t++) e[t].stop(!0);
				this.scopes.length = 0;
			}
			if (!this.detached && this.parent && !e) {
				let e = this.parent.scopes.pop();
				e && e !== this && (this.parent.scopes[this.index] = e, e.index = this.index);
			}
			this.parent = void 0;
		}
	}
};
function De() {
	return A;
}
var j, Oe = /* @__PURE__ */ new WeakSet(), ke = class {
	constructor(e) {
		this.fn = e, this.deps = void 0, this.depsTail = void 0, this.flags = 5, this.next = void 0, this.cleanup = void 0, this.scheduler = void 0, A && (A.active ? A.effects.push(this) : this.flags &= -2);
	}
	pause() {
		this.flags |= 64;
	}
	resume() {
		this.flags & 64 && (this.flags &= -65, Oe.has(this) && (Oe.delete(this), this.trigger()));
	}
	notify() {
		this.flags & 2 && !(this.flags & 32) || this.flags & 8 || Ne(this);
	}
	run() {
		if (!(this.flags & 1)) return this.fn();
		this.flags |= 2, Ke(this), Ie(this);
		let e = j, t = He;
		j = this, He = !0;
		try {
			return this.fn();
		} finally {
			Le(this), j = e, He = t, this.flags &= -3;
		}
	}
	stop() {
		if (this.flags & 1) {
			for (let e = this.deps; e; e = e.nextDep) Be(e);
			this.deps = this.depsTail = void 0, Ke(this), this.onStop && this.onStop(), this.flags &= -2;
		}
	}
	trigger() {
		this.flags & 64 ? Oe.add(this) : this.scheduler ? this.scheduler() : this.runIfDirty();
	}
	runIfDirty() {
		Re(this) && this.run();
	}
	get dirty() {
		return Re(this);
	}
}, Ae = 0, je, Me;
function Ne(e, t = !1) {
	if (e.flags |= 8, t) {
		e.next = Me, Me = e;
		return;
	}
	e.next = je, je = e;
}
function Pe() {
	Ae++;
}
function Fe() {
	if (--Ae > 0) return;
	if (Me) {
		let e = Me;
		for (Me = void 0; e;) {
			let t = e.next;
			e.next = void 0, e.flags &= -9, e = t;
		}
	}
	let e;
	for (; je;) {
		let t = je;
		for (je = void 0; t;) {
			let n = t.next;
			if (t.next = void 0, t.flags &= -9, t.flags & 1) try {
				t.trigger();
			} catch (t) {
				e ||= t;
			}
			t = n;
		}
	}
	if (e) throw e;
}
function Ie(e) {
	for (let t = e.deps; t; t = t.nextDep) t.version = -1, t.prevActiveLink = t.dep.activeLink, t.dep.activeLink = t;
}
function Le(e) {
	let t, n = e.depsTail, r = n;
	for (; r;) {
		let e = r.prevDep;
		r.version === -1 ? (r === n && (n = e), Be(r), Ve(r)) : t = r, r.dep.activeLink = r.prevActiveLink, r.prevActiveLink = void 0, r = e;
	}
	e.deps = t, e.depsTail = n;
}
function Re(e) {
	for (let t = e.deps; t; t = t.nextDep) if (t.dep.version !== t.version || t.dep.computed && (ze(t.dep.computed) || t.dep.version !== t.version)) return !0;
	return !!e._dirty;
}
function ze(e) {
	if (e.flags & 4 && !(e.flags & 16) || (e.flags &= -17, e.globalVersion === qe) || (e.globalVersion = qe, !e.isSSR && e.flags & 128 && (!e.deps && !e._dirty || !Re(e)))) return;
	e.flags |= 2;
	let t = e.dep, n = j, r = He;
	j = e, He = !0;
	try {
		Ie(e);
		let n = e.fn(e._value);
		(t.version === 0 || oe(n, e._value)) && (e.flags |= 128, e._value = n, t.version++);
	} catch (e) {
		throw t.version++, e;
	} finally {
		j = n, He = r, Le(e), e.flags &= -3;
	}
}
function Be(e, t = !1) {
	let { dep: n, prevSub: r, nextSub: i } = e;
	if (r && (r.nextSub = i, e.prevSub = void 0), i && (i.prevSub = r, e.nextSub = void 0), n.subs === e && (n.subs = r, !r && n.computed)) {
		n.computed.flags &= -5;
		for (let e = n.computed.deps; e; e = e.nextDep) Be(e, !0);
	}
	!t && !--n.sc && n.map && n.map.delete(n.key);
}
function Ve(e) {
	let { prevDep: t, nextDep: n } = e;
	t && (t.nextDep = n, e.prevDep = void 0), n && (n.prevDep = t, e.nextDep = void 0);
}
var He = !0, Ue = [];
function We() {
	Ue.push(He), He = !1;
}
function Ge() {
	let e = Ue.pop();
	He = e === void 0 || e;
}
function Ke(e) {
	let { cleanup: t } = e;
	if (e.cleanup = void 0, t) {
		let e = j;
		j = void 0;
		try {
			t();
		} finally {
			j = e;
		}
	}
}
var qe = 0, Je = class {
	constructor(e, t) {
		this.sub = e, this.dep = t, this.version = t.version, this.nextDep = this.prevDep = this.nextSub = this.prevSub = this.prevActiveLink = void 0;
	}
}, Ye = class {
	constructor(e) {
		this.computed = e, this.version = 0, this.activeLink = void 0, this.subs = void 0, this.map = void 0, this.key = void 0, this.sc = 0, this.__v_skip = !0;
	}
	track(e) {
		if (!j || !He || j === this.computed) return;
		let t = this.activeLink;
		if (t === void 0 || t.sub !== j) t = this.activeLink = new Je(j, this), j.deps ? (t.prevDep = j.depsTail, j.depsTail.nextDep = t, j.depsTail = t) : j.deps = j.depsTail = t, Xe(t);
		else if (t.version === -1 && (t.version = this.version, t.nextDep)) {
			let e = t.nextDep;
			e.prevDep = t.prevDep, t.prevDep && (t.prevDep.nextDep = e), t.prevDep = j.depsTail, t.nextDep = void 0, j.depsTail.nextDep = t, j.depsTail = t, j.deps === t && (j.deps = e);
		}
		return t;
	}
	trigger(e) {
		this.version++, qe++, this.notify(e);
	}
	notify(e) {
		Pe();
		try {
			for (let e = this.subs; e; e = e.prevSub) e.sub.notify() && e.sub.dep.notify();
		} finally {
			Fe();
		}
	}
};
function Xe(e) {
	if (e.dep.sc++, e.sub.flags & 4) {
		let t = e.dep.computed;
		if (t && !e.dep.subs) {
			t.flags |= 20;
			for (let e = t.deps; e; e = e.nextDep) Xe(e);
		}
		let n = e.dep.subs;
		n !== e && (e.prevSub = n, n && (n.nextSub = e)), e.dep.subs = e;
	}
}
var Ze = /* @__PURE__ */ new WeakMap(), Qe = /* @__PURE__ */ Symbol(""), $e = /* @__PURE__ */ Symbol(""), et = /* @__PURE__ */ Symbol("");
function M(e, t, n) {
	if (He && j) {
		let t = Ze.get(e);
		t || Ze.set(e, t = /* @__PURE__ */ new Map());
		let r = t.get(n);
		r || (t.set(n, r = new Ye()), r.map = t, r.key = n), r.track();
	}
}
function tt(e, t, n, r, i, a) {
	let o = Ze.get(e);
	if (!o) {
		qe++;
		return;
	}
	let s = (e) => {
		e && e.trigger();
	};
	if (Pe(), t === "clear") o.forEach(s);
	else {
		let i = d(e), a = i && w(n);
		if (i && n === "length") {
			let e = Number(r);
			o.forEach((t, n) => {
				(n === "length" || n === et || !_(n) && n >= e) && s(t);
			});
		} else switch ((n !== void 0 || o.has(void 0)) && s(o.get(n)), a && s(o.get(et)), t) {
			case "add":
				i ? a && s(o.get("length")) : (s(o.get(Qe)), f(e) && s(o.get($e)));
				break;
			case "delete":
				i || (s(o.get(Qe)), f(e) && s(o.get($e)));
				break;
			case "set": f(e) && s(o.get(Qe));
		}
	}
	Fe();
}
function nt(e) {
	let t = /* @__PURE__ */ N(e);
	return t === e ? t : (M(t, "iterate", et), /* @__PURE__ */ Vt(e) ? t : t.map(Wt));
}
function rt(e) {
	return M(e = /* @__PURE__ */ N(e), "iterate", et), e;
}
function it(e, t) {
	return /* @__PURE__ */ Bt(e) ? Gt(/* @__PURE__ */ zt(e) ? Wt(t) : t) : Wt(t);
}
var at = {
	__proto__: null,
	[Symbol.iterator]() {
		return ot(this, Symbol.iterator, (e) => it(this, e));
	},
	concat(...e) {
		return nt(this).concat(...e.map((e) => d(e) ? nt(e) : e));
	},
	entries() {
		return ot(this, "entries", (e) => (e[1] = it(this, e[1]), e));
	},
	every(e, t) {
		return ct(this, "every", e, t, void 0, arguments);
	},
	filter(e, t) {
		return ct(this, "filter", e, t, (e) => e.map((e) => it(this, e)), arguments);
	},
	find(e, t) {
		return ct(this, "find", e, t, (e) => it(this, e), arguments);
	},
	findIndex(e, t) {
		return ct(this, "findIndex", e, t, void 0, arguments);
	},
	findLast(e, t) {
		return ct(this, "findLast", e, t, (e) => it(this, e), arguments);
	},
	findLastIndex(e, t) {
		return ct(this, "findLastIndex", e, t, void 0, arguments);
	},
	forEach(e, t) {
		return ct(this, "forEach", e, t, void 0, arguments);
	},
	includes(...e) {
		return ut(this, "includes", e);
	},
	indexOf(...e) {
		return ut(this, "indexOf", e);
	},
	join(e) {
		return nt(this).join(e);
	},
	lastIndexOf(...e) {
		return ut(this, "lastIndexOf", e);
	},
	map(e, t) {
		return ct(this, "map", e, t, void 0, arguments);
	},
	pop() {
		return dt(this, "pop");
	},
	push(...e) {
		return dt(this, "push", e);
	},
	reduce(e, ...t) {
		return lt(this, "reduce", e, t);
	},
	reduceRight(e, ...t) {
		return lt(this, "reduceRight", e, t);
	},
	shift() {
		return dt(this, "shift");
	},
	some(e, t) {
		return ct(this, "some", e, t, void 0, arguments);
	},
	splice(...e) {
		return dt(this, "splice", e);
	},
	toReversed() {
		return nt(this).toReversed();
	},
	toSorted(e) {
		return nt(this).toSorted(e);
	},
	toSpliced(...e) {
		return nt(this).toSpliced(...e);
	},
	unshift(...e) {
		return dt(this, "unshift", e);
	},
	values() {
		return ot(this, "values", (e) => it(this, e));
	}
};
function ot(e, t, n) {
	let r = rt(e), i = r[t]();
	return r !== e && !/* @__PURE__ */ Vt(e) && (i._next = i.next, i.next = () => {
		let e = i._next();
		return e.done || (e.value = n(e.value)), e;
	}), i;
}
var st = Array.prototype;
function ct(e, t, n, r, i, a) {
	let o = rt(e), s = o !== e && !/* @__PURE__ */ Vt(e), c = o[t];
	if (c !== st[t]) {
		let t = c.apply(e, a);
		return s ? Wt(t) : t;
	}
	let l = n;
	o !== e && (s ? l = function(t, r) {
		return n.call(this, it(e, t), r, e);
	} : n.length > 2 && (l = function(t, r) {
		return n.call(this, t, r, e);
	}));
	let u = c.call(o, l, r);
	return s && i ? i(u) : u;
}
function lt(e, t, n, r) {
	let i = rt(e), a = i !== e && !/* @__PURE__ */ Vt(e), o = n, s = !1;
	i !== e && (a ? (s = r.length === 0, o = function(t, r, i) {
		return s && (s = !1, t = it(e, t)), n.call(this, t, it(e, r), i, e);
	}) : n.length > 3 && (o = function(t, r, i) {
		return n.call(this, t, r, i, e);
	}));
	let c = i[t](o, ...r);
	return s ? it(e, c) : c;
}
function ut(e, t, n) {
	let r = /* @__PURE__ */ N(e);
	M(r, "iterate", et);
	let i = r[t](...n);
	return (i === -1 || i === !1) && /* @__PURE__ */ Ht(n[0]) ? (n[0] = /* @__PURE__ */ N(n[0]), r[t](...n)) : i;
}
function dt(e, t, n = []) {
	We(), Pe();
	let r = (/* @__PURE__ */ N(e))[t].apply(e, n);
	return Fe(), Ge(), r;
}
var ft = /* @__PURE__ */ e("__proto__,__v_isRef,__isVue"), pt = new Set(/* @__PURE__ */ Object.getOwnPropertyNames(Symbol).filter((e) => e !== "arguments" && e !== "caller").map((e) => Symbol[e]).filter(_));
function mt(e) {
	_(e) || (e = String(e));
	let t = /* @__PURE__ */ N(this);
	return M(t, "has", e), t.hasOwnProperty(e);
}
var ht = class {
	constructor(e = !1, t = !1) {
		this._isReadonly = e, this._isShallow = t;
	}
	get(e, t, n) {
		if (t === "__v_skip") return e.__v_skip;
		let r = this._isReadonly, i = this._isShallow;
		if (t === "__v_isReactive") return !r;
		if (t === "__v_isReadonly") return r;
		if (t === "__v_isShallow") return i;
		if (t === "__v_raw") return n === (r ? i ? Nt : Mt : i ? jt : At).get(e) || Object.getPrototypeOf(e) === Object.getPrototypeOf(n) ? e : void 0;
		let a = d(e);
		if (!r) {
			let e;
			if (a && (e = at[t])) return e;
			if (t === "hasOwnProperty") return mt;
		}
		let o = Reflect.get(e, t, /* @__PURE__ */ P(e) ? e : n);
		if ((_(t) ? pt.has(t) : ft(t)) || (r || M(e, "get", t), i)) return o;
		if (/* @__PURE__ */ P(o)) {
			let e = a && w(t) ? o : o.value;
			return r && v(e) ? /* @__PURE__ */ Lt(e) : e;
		}
		return v(o) ? r ? /* @__PURE__ */ Lt(o) : /* @__PURE__ */ Ft(o) : o;
	}
}, gt = class extends ht {
	constructor(e = !1) {
		super(!1, e);
	}
	set(e, t, n, r) {
		let i = e[t], a = d(e) && w(t);
		if (!this._isShallow) {
			let e = /* @__PURE__ */ Bt(i);
			if (!/* @__PURE__ */ Vt(n) && !/* @__PURE__ */ Bt(n) && (i = /* @__PURE__ */ N(i), n = /* @__PURE__ */ N(n)), !a && /* @__PURE__ */ P(i) && !/* @__PURE__ */ P(n)) return e || (i.value = n), !0;
		}
		let o = a ? Number(t) < e.length : u(e, t), s = Reflect.set(e, t, n, /* @__PURE__ */ P(e) ? e : r);
		return e === /* @__PURE__ */ N(r) && s && (o ? oe(n, i) && tt(e, "set", t, n, i) : tt(e, "add", t, n)), s;
	}
	deleteProperty(e, t) {
		let n = u(e, t), r = e[t], i = Reflect.deleteProperty(e, t);
		return i && n && tt(e, "delete", t, void 0, r), i;
	}
	has(e, t) {
		let n = Reflect.has(e, t);
		return (!_(t) || !pt.has(t)) && M(e, "has", t), n;
	}
	ownKeys(e) {
		return M(e, "iterate", d(e) ? "length" : Qe), Reflect.ownKeys(e);
	}
}, _t = class extends ht {
	constructor(e = !1) {
		super(!0, e);
	}
	set(e, t) {
		return !0;
	}
	deleteProperty(e, t) {
		return !0;
	}
}, vt = /* @__PURE__ */ new gt(), yt = /* @__PURE__ */ new _t(), bt = /* @__PURE__ */ new gt(!0), xt = (e) => e, St = (e) => Reflect.getPrototypeOf(e);
function Ct(e, t, n) {
	return function(...r) {
		let i = this.__v_raw, a = /* @__PURE__ */ N(i), o = f(a), c = e === "entries" || e === Symbol.iterator && o, l = e === "keys" && o, u = i[e](...r), d = n ? xt : t ? Gt : Wt;
		return !t && M(a, "iterate", l ? $e : Qe), s(Object.create(u), { next() {
			let { value: e, done: t } = u.next();
			return t ? {
				value: e,
				done: t
			} : {
				value: c ? [d(e[0]), d(e[1])] : d(e),
				done: t
			};
		} });
	};
}
function wt(e) {
	return function(...t) {
		return e === "delete" ? !1 : e === "clear" ? void 0 : this;
	};
}
function Tt(e, t) {
	let n = {
		get(n) {
			let r = this.__v_raw, i = /* @__PURE__ */ N(r), a = /* @__PURE__ */ N(n);
			e || (oe(n, a) && M(i, "get", n), M(i, "get", a));
			let { has: o } = St(i), s = t ? xt : e ? Gt : Wt;
			if (o.call(i, n)) return s(r.get(n));
			if (o.call(i, a)) return s(r.get(a));
			r !== i && r.get(n);
		},
		get size() {
			let t = this.__v_raw;
			return !e && M(/* @__PURE__ */ N(t), "iterate", Qe), t.size;
		},
		has(t) {
			let n = this.__v_raw, r = /* @__PURE__ */ N(n), i = /* @__PURE__ */ N(t);
			return e || (oe(t, i) && M(r, "has", t), M(r, "has", i)), t === i ? n.has(t) : n.has(t) || n.has(i);
		},
		forEach(n, r) {
			let i = this, a = i.__v_raw, o = /* @__PURE__ */ N(a), s = t ? xt : e ? Gt : Wt;
			return !e && M(o, "iterate", Qe), a.forEach((e, t) => n.call(r, s(e), s(t), i));
		}
	};
	return s(n, e ? {
		add: wt("add"),
		set: wt("set"),
		delete: wt("delete"),
		clear: wt("clear")
	} : {
		add(e) {
			let n = /* @__PURE__ */ N(this), r = St(n), i = /* @__PURE__ */ N(e), a = !t && !/* @__PURE__ */ Vt(e) && !/* @__PURE__ */ Bt(e) ? i : e;
			return r.has.call(n, a) || oe(e, a) && r.has.call(n, e) || oe(i, a) && r.has.call(n, i) || (n.add(a), tt(n, "add", a, a)), this;
		},
		set(e, n) {
			!t && !/* @__PURE__ */ Vt(n) && !/* @__PURE__ */ Bt(n) && (n = /* @__PURE__ */ N(n));
			let r = /* @__PURE__ */ N(this), { has: i, get: a } = St(r), o = i.call(r, e);
			o ||= (e = /* @__PURE__ */ N(e), i.call(r, e));
			let s = a.call(r, e);
			return r.set(e, n), o ? oe(n, s) && tt(r, "set", e, n, s) : tt(r, "add", e, n), this;
		},
		delete(e) {
			let t = /* @__PURE__ */ N(this), { has: n, get: r } = St(t), i = n.call(t, e);
			i ||= (e = /* @__PURE__ */ N(e), n.call(t, e));
			let a = r ? r.call(t, e) : void 0, o = t.delete(e);
			return i && tt(t, "delete", e, void 0, a), o;
		},
		clear() {
			let e = /* @__PURE__ */ N(this), t = e.size !== 0, n = e.clear();
			return t && tt(e, "clear", void 0, void 0, void 0), n;
		}
	}), [
		"keys",
		"values",
		"entries",
		Symbol.iterator
	].forEach((r) => {
		n[r] = Ct(r, e, t);
	}), n;
}
function Et(e, t) {
	let n = Tt(e, t);
	return (t, r, i) => r === "__v_isReactive" ? !e : r === "__v_isReadonly" ? e : r === "__v_raw" ? t : Reflect.get(u(n, r) && r in t ? n : t, r, i);
}
var Dt = { get: /* @__PURE__ */ Et(!1, !1) }, Ot = { get: /* @__PURE__ */ Et(!1, !0) }, kt = { get: /* @__PURE__ */ Et(!0, !1) }, At = /* @__PURE__ */ new WeakMap(), jt = /* @__PURE__ */ new WeakMap(), Mt = /* @__PURE__ */ new WeakMap(), Nt = /* @__PURE__ */ new WeakMap();
function Pt(e) {
	switch (e) {
		case "Object":
		case "Array": return 1;
		case "Map":
		case "Set":
		case "WeakMap":
		case "WeakSet": return 2;
		default: return 0;
	}
}
// @__NO_SIDE_EFFECTS__
function Ft(e) {
	return /* @__PURE__ */ Bt(e) ? e : Rt(e, !1, vt, Dt, At);
}
// @__NO_SIDE_EFFECTS__
function It(e) {
	return Rt(e, !1, bt, Ot, jt);
}
// @__NO_SIDE_EFFECTS__
function Lt(e) {
	return Rt(e, !0, yt, kt, Mt);
}
function Rt(e, t, n, r, i) {
	if (!v(e) || e.__v_raw && !(t && e.__v_isReactive) || e.__v_skip || !Object.isExtensible(e)) return e;
	let a = i.get(e);
	if (a) return a;
	let o = Pt(S(e));
	if (o === 0) return e;
	let s = new Proxy(e, o === 2 ? r : n);
	return i.set(e, s), s;
}
// @__NO_SIDE_EFFECTS__
function zt(e) {
	return /* @__PURE__ */ Bt(e) ? /* @__PURE__ */ zt(e.__v_raw) : !!(e && e.__v_isReactive);
}
// @__NO_SIDE_EFFECTS__
function Bt(e) {
	return !!(e && e.__v_isReadonly);
}
// @__NO_SIDE_EFFECTS__
function Vt(e) {
	return !!(e && e.__v_isShallow);
}
// @__NO_SIDE_EFFECTS__
function Ht(e) {
	return e ? !!e.__v_raw : !1;
}
// @__NO_SIDE_EFFECTS__
function N(e) {
	let t = e && e.__v_raw;
	return t ? /* @__PURE__ */ N(t) : e;
}
function Ut(e) {
	return !u(e, "__v_skip") && Object.isExtensible(e) && D(e, "__v_skip", !0), e;
}
var Wt = (e) => v(e) ? /* @__PURE__ */ Ft(e) : e, Gt = (e) => v(e) ? /* @__PURE__ */ Lt(e) : e;
// @__NO_SIDE_EFFECTS__
function P(e) {
	return e ? e.__v_isRef === !0 : !1;
}
// @__NO_SIDE_EFFECTS__
function Kt(e) {
	return qt(e, !1);
}
function qt(e, t) {
	return /* @__PURE__ */ P(e) ? e : new Jt(e, t);
}
var Jt = class {
	constructor(e, t) {
		this.dep = new Ye(), this.__v_isRef = !0, this.__v_isShallow = !1, this._rawValue = t ? e : /* @__PURE__ */ N(e), this._value = t ? e : Wt(e), this.__v_isShallow = t;
	}
	get value() {
		return this.dep.track(), this._value;
	}
	set value(e) {
		let t = this._rawValue, n = this.__v_isShallow || /* @__PURE__ */ Vt(e) || /* @__PURE__ */ Bt(e);
		e = n ? e : /* @__PURE__ */ N(e), oe(e, t) && (this._rawValue = e, this._value = n ? e : Wt(e), this.dep.trigger());
	}
};
function F(e) {
	return /* @__PURE__ */ P(e) ? e.value : e;
}
var Yt = {
	get: (e, t, n) => t === "__v_raw" ? e : F(Reflect.get(e, t, n)),
	set: (e, t, n, r) => {
		let i = e[t];
		return /* @__PURE__ */ P(i) && !/* @__PURE__ */ P(n) ? (i.value = n, !0) : Reflect.set(e, t, n, r);
	}
};
function Xt(e) {
	return /* @__PURE__ */ zt(e) ? e : new Proxy(e, Yt);
}
var Zt = class {
	constructor(e, t, n) {
		this.fn = e, this.setter = t, this._value = void 0, this.dep = new Ye(this), this.__v_isRef = !0, this.deps = void 0, this.depsTail = void 0, this.flags = 16, this.globalVersion = qe - 1, this.next = void 0, this.effect = this, this.__v_isReadonly = !t, this.isSSR = n;
	}
	notify() {
		if (this.flags |= 16, !(this.flags & 8) && j !== this) return Ne(this, !0), !0;
	}
	get value() {
		let e = this.dep.track();
		return ze(this), e && (e.version = this.dep.version), this._value;
	}
	set value(e) {
		this.setter && this.setter(e);
	}
};
// @__NO_SIDE_EFFECTS__
function Qt(e, t, n = !1) {
	let r, i;
	return h(e) ? r = e : (r = e.get, i = e.set), new Zt(r, i, n);
}
var $t = {}, en = /* @__PURE__ */ new WeakMap(), tn = void 0;
function nn(e, t = !1, n = tn) {
	if (n) {
		let t = en.get(n);
		t || en.set(n, t = []), t.push(e);
	}
}
function rn(e, n, i = t) {
	let { immediate: a, deep: o, once: s, scheduler: l, augmentJob: u, call: f } = i, p = (e) => o ? e : /* @__PURE__ */ Vt(e) || o === !1 || o === 0 ? an(e, 1) : an(e), m, g, _, v, y = !1, b = !1;
	if (/* @__PURE__ */ P(e) ? (g = () => e.value, y = /* @__PURE__ */ Vt(e)) : /* @__PURE__ */ zt(e) ? (g = () => p(e), y = !0) : d(e) ? (b = !0, y = e.some((e) => /* @__PURE__ */ zt(e) || /* @__PURE__ */ Vt(e)), g = () => e.map((e) => {
		if (/* @__PURE__ */ P(e)) return e.value;
		if (/* @__PURE__ */ zt(e)) return p(e);
		if (h(e)) return f ? f(e, 2) : e();
	})) : g = h(e) ? n ? f ? () => f(e, 2) : e : () => {
		if (_) {
			We();
			try {
				_();
			} finally {
				Ge();
			}
		}
		let t = tn;
		tn = m;
		try {
			return f ? f(e, 3, [v]) : e(v);
		} finally {
			tn = t;
		}
	} : r, n && o) {
		let e = g, t = o === !0 ? Infinity : o;
		g = () => an(e(), t);
	}
	let x = De(), S = () => {
		m.stop(), x && x.active && c(x.effects, m);
	};
	if (s && n) {
		let e = n;
		n = (...t) => {
			let n = e(...t);
			return S(), n;
		};
	}
	let C = b ? Array(e.length).fill($t) : $t, w = (e) => {
		if (!(!(m.flags & 1) || !m.dirty && !e)) if (n) {
			let t = m.run();
			if (e || o || y || (b ? t.some((e, t) => oe(e, C[t])) : oe(t, C))) {
				_ && _();
				let e = tn;
				tn = m;
				try {
					let e = [
						t,
						C === $t ? void 0 : b && C[0] === $t ? [] : C,
						v
					];
					C = t, f ? f(n, 3, e) : n(...e);
				} finally {
					tn = e;
				}
			}
		} else m.run();
	};
	return u && u(w), m = new ke(g), m.scheduler = l ? () => l(w, !1) : w, v = (e) => nn(e, !1, m), _ = m.onStop = () => {
		let e = en.get(m);
		if (e) {
			if (f) f(e, 4);
			else for (let t of e) t();
			en.delete(m);
		}
	}, n ? a ? w(!0) : C = m.run() : l ? l(w.bind(null, !0), !0) : m.run(), S.pause = m.pause.bind(m), S.resume = m.resume.bind(m), S.stop = S, S;
}
function an(e, t = Infinity, n) {
	if (t <= 0 || !v(e) || e.__v_skip || (n ||= /* @__PURE__ */ new Map(), (n.get(e) || 0) >= t)) return e;
	if (n.set(e, t), t--, /* @__PURE__ */ P(e)) an(e.value, t, n);
	else if (d(e)) for (let r = 0; r < e.length; r++) an(e[r], t, n);
	else if (p(e) || f(e)) e.forEach((e) => {
		an(e, t, n);
	});
	else if (C(e)) {
		for (let r in e) an(e[r], t, n);
		for (let r of Object.getOwnPropertySymbols(e)) Object.prototype.propertyIsEnumerable.call(e, r) && an(e[r], t, n);
	}
	return e;
}
//#endregion
//#region node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
function on(e, t, n, r) {
	try {
		return r ? e(...r) : e();
	} catch (e) {
		cn(e, t, n);
	}
}
function sn(e, t, n, r) {
	if (h(e)) {
		let i = on(e, t, n, r);
		return i && y(i) && i.catch((e) => {
			cn(e, t, n);
		}), i;
	}
	if (d(e)) {
		let i = [];
		for (let a = 0; a < e.length; a++) i.push(sn(e[a], t, n, r));
		return i;
	}
}
function cn(e, n, r, i = !0) {
	let a = n ? n.vnode : null, { errorHandler: o, throwUnhandledErrorInProduction: s } = n && n.appContext.config || t;
	if (n) {
		let t = n.parent, i = n.proxy, a = `https://vuejs.org/error-reference/#runtime-${r}`;
		for (; t;) {
			let n = t.ec;
			if (n) {
				for (let t = 0; t < n.length; t++) if (n[t](e, i, a) === !1) return;
			}
			t = t.parent;
		}
		if (o) {
			We(), on(o, null, 10, [
				e,
				i,
				a
			]), Ge();
			return;
		}
	}
	ln(e, r, a, i, s);
}
function ln(e, t, n, r = !0, i = !1) {
	if (i) throw e;
	console.error(e);
}
var I = [], un = -1, dn = [], fn = null, pn = 0, mn = /* @__PURE__ */ Promise.resolve(), hn = null;
function gn(e) {
	let t = hn || mn;
	return e ? t.then(this ? e.bind(this) : e) : t;
}
function _n(e) {
	let t = un + 1, n = I.length;
	for (; t < n;) {
		let r = t + n >>> 1, i = I[r], a = Cn(i);
		a < e || a === e && i.flags & 2 ? t = r + 1 : n = r;
	}
	return t;
}
function vn(e) {
	if (!(e.flags & 1)) {
		let t = Cn(e), n = I[I.length - 1];
		!n || !(e.flags & 2) && t >= Cn(n) ? I.push(e) : I.splice(_n(t), 0, e), e.flags |= 1, yn();
	}
}
function yn() {
	hn ||= mn.then(wn);
}
function bn(e) {
	d(e) ? dn.push(...e) : fn && e.id === -1 ? fn.splice(pn + 1, 0, e) : e.flags & 1 || (dn.push(e), e.flags |= 1), yn();
}
function xn(e, t, n = un + 1) {
	for (; n < I.length; n++) {
		let t = I[n];
		if (t && t.flags & 2) {
			if (e && t.id !== e.uid) continue;
			I.splice(n, 1), n--, t.flags & 4 && (t.flags &= -2), t(), t.flags & 4 || (t.flags &= -2);
		}
	}
}
function Sn(e) {
	if (dn.length) {
		let e = [...new Set(dn)].sort((e, t) => Cn(e) - Cn(t));
		if (dn.length = 0, fn) {
			fn.push(...e);
			return;
		}
		for (fn = e, pn = 0; pn < fn.length; pn++) {
			let e = fn[pn];
			e.flags & 4 && (e.flags &= -2), e.flags & 8 || e(), e.flags &= -2;
		}
		fn = null, pn = 0;
	}
}
var Cn = (e) => e.id == null ? e.flags & 2 ? -1 : Infinity : e.id;
function wn(e) {
	try {
		for (un = 0; un < I.length; un++) {
			let e = I[un];
			e && !(e.flags & 8) && (e.flags & 4 && (e.flags &= -2), on(e, e.i, e.i ? 15 : 14), e.flags & 4 || (e.flags &= -2));
		}
	} finally {
		for (; un < I.length; un++) {
			let e = I[un];
			e && (e.flags &= -2);
		}
		un = -1, I.length = 0, Sn(e), hn = null, (I.length || dn.length) && wn(e);
	}
}
var Tn = null, En = null;
function Dn(e) {
	let t = Tn;
	return Tn = e, En = e && e.type.__scopeId || null, t;
}
function On(e, t = Tn, n) {
	if (!t || e._n) return e;
	let r = (...n) => {
		r._d && na(-1);
		let i = Dn(t), a = Qi.length, o;
		try {
			o = e(...n);
		} finally {
			for (let e = Qi.length; e > a; e--) ea();
			Dn(i), r._d && na(1);
		}
		return o;
	};
	return r._n = !0, r._c = !0, r._d = !0, r;
}
function L(e, n) {
	if (Tn === null) return e;
	let r = La(Tn), i = e.dirs ||= [];
	for (let e = 0; e < n.length; e++) {
		let [a, o, s, c = t] = n[e];
		a && (h(a) && (a = {
			mounted: a,
			updated: a
		}), a.deep && an(o), i.push({
			dir: a,
			instance: r,
			value: o,
			oldValue: void 0,
			arg: s,
			modifiers: c
		}));
	}
	return e;
}
function kn(e, t, n, r) {
	let i = e.dirs, a = t && t.dirs;
	for (let o = 0; o < i.length; o++) {
		let s = i[o];
		a && (s.oldValue = a[o].value);
		let c = s.dir[r];
		c && (We(), sn(c, n, 8, [
			e.el,
			s,
			e,
			t
		]), Ge());
	}
}
function An(e, t) {
	if (q) {
		let n = q.provides, r = q.parent && q.parent.provides;
		r === n && (n = q.provides = Object.create(r)), n[e] = t;
	}
}
function jn(e, t, n = !1) {
	let r = Sa();
	if (r || oi) {
		let i = oi ? oi._context.provides : r ? r.parent == null || r.ce ? r.vnode.appContext && r.vnode.appContext.provides : r.parent.provides : void 0;
		if (i && e in i) return i[e];
		if (arguments.length > 1) return n && h(t) ? t.call(r && r.proxy) : t;
	}
}
var Mn = /* @__PURE__ */ Symbol.for("v-scx"), Nn = () => jn(Mn);
function Pn(e, t, n) {
	return Fn(e, t, n);
}
function Fn(e, n, i = t) {
	let { immediate: a, deep: o, flush: c, once: l } = i, u = s({}, i), d = n && a || !n && c !== "post", f;
	if (Oa) {
		if (c === "sync") {
			let e = Nn();
			f = e.__watcherHandles ||= [];
		} else if (!d) {
			let e = () => {};
			return e.stop = r, e.resume = r, e.pause = r, e;
		}
	}
	let p = q;
	u.call = (e, t, n) => sn(e, p, t, n);
	let m = !1;
	c === "post" ? u.scheduler = (e) => {
		B(e, p && p.suspense);
	} : c !== "sync" && (m = !0, u.scheduler = (e, t) => {
		t ? e() : vn(e);
	}), u.augmentJob = (e) => {
		n && (e.flags |= 4), m && (e.flags |= 2, p && (e.id = p.uid, e.i = p));
	};
	let h = rn(e, n, u);
	return Oa && (f ? f.push(h) : d && h()), h;
}
function In(e, t, n) {
	let r = this.proxy, i = g(e) ? e.includes(".") ? Ln(r, e) : () => r[e] : e.bind(r, r), a;
	h(t) ? a = t : (a = t.handler, n = t);
	let o = Ta(this), s = Fn(i, a.bind(r), n);
	return o(), s;
}
function Ln(e, t) {
	let n = t.split(".");
	return () => {
		let t = e;
		for (let e = 0; e < n.length && t; e++) t = t[n[e]];
		return t;
	};
}
var Rn = /* @__PURE__ */ new WeakMap(), zn = /* @__PURE__ */ Symbol("_vte"), Bn = (e) => e.__isTeleport, Vn = (e) => e && (e.disabled || e.disabled === ""), Hn = (e) => e && (e.defer || e.defer === ""), Un = (e) => typeof SVGElement < "u" && e instanceof SVGElement, Wn = (e) => typeof MathMLElement == "function" && e instanceof MathMLElement, Gn = (e, t) => {
	let n = e && e.to;
	return g(n) ? t ? t(n) : null : n;
}, Kn = {
	name: "Teleport",
	__isTeleport: !0,
	process(e, t, n, r, i, a, o, s, c, l) {
		let { mc: u, pc: d, pbc: f, o: { insert: p, querySelector: m, createText: h, createComment: g, parentNode: _ } } = l, v = Vn(t.props), { dynamicChildren: y } = t, b = (e, t, n) => {
			e.shapeFlag & 16 && u(e.children, t, n, i, a, o, s, c);
		}, x = (e = t) => {
			let n = Vn(e.props), r = e.target = Gn(e.props, m), a = Zn(r, e, h, p);
			r && (o !== "svg" && Un(r) ? o = "svg" : o !== "mathml" && Wn(r) && (o = "mathml"), i && i.isCE && (i.ce._teleportTargets || (i.ce._teleportTargets = /* @__PURE__ */ new Set())).add(r), n || (b(e, r, a), Xn(e, !1)));
		}, S = (e) => {
			let t = () => {
				if (Rn.get(e) === t) {
					if (Rn.delete(e), Vn(e.props)) {
						let t = _(e.el) || n;
						b(e, t, e.anchor), Xn(e, !0);
					}
					x(e);
				}
			};
			Rn.set(e, t), B(t, a);
		};
		if (e == null) {
			let e = t.el = h(""), i = t.anchor = h("");
			if (p(e, n, r), p(i, n, r), Hn(t.props) || a && a.pendingBranch) {
				S(t);
				return;
			}
			v && (b(t, n, i), Xn(t, !0)), x();
		} else {
			t.el = e.el;
			let r = t.anchor = e.anchor, u = Rn.get(e);
			if (u) {
				u.flags |= 8, Rn.delete(e), S(t);
				return;
			}
			t.targetStart = e.targetStart;
			let p = t.target = e.target, h = t.targetAnchor = e.targetAnchor, g = Vn(e.props), _ = g ? n : p, b = g ? r : h;
			if (o === "svg" || Un(p) ? o = "svg" : (o === "mathml" || Wn(p)) && (o = "mathml"), y ? (f(e.dynamicChildren, y, _, i, a, o, s), Hi(e, t, !0)) : c || d(e, t, _, b, i, a, o, s, !1), v) g ? t.props && e.props && t.props.to !== e.props.to && (t.props.to = e.props.to) : qn(t, n, r, l, 1);
			else if ((t.props && t.props.to) !== (e.props && e.props.to)) {
				let e = Gn(t.props, m);
				e && (t.target = e, qn(t, e, null, l, 0));
			} else g && qn(t, p, h, l, 1);
			Xn(t, v);
		}
	},
	remove(e, t, n, { um: r, o: { remove: i } }, a) {
		let { shapeFlag: o, children: s, anchor: c, targetStart: l, targetAnchor: u, target: d, props: f } = e, p = Vn(f), m = a || !p, h = Rn.get(e);
		if (h && (h.flags |= 8, Rn.delete(e)), d && (i(l), i(u)), a && i(c), !h && (p || d) && o & 16) for (let e = 0; e < s.length; e++) {
			let i = s[e];
			r(i, t, n, m, !!i.dynamicChildren);
		}
	},
	move: qn,
	hydrate: Jn
};
function qn(e, t, n, { o: { insert: r }, m: i }, a = 2) {
	a === 0 && r(e.targetAnchor, t, n);
	let { el: o, anchor: s, shapeFlag: c, children: l, props: u } = e, d = a === 2;
	if (d && r(o, t, n), !Rn.has(e) && (!d || Vn(u)) && c & 16) for (let e = 0; e < l.length; e++) i(l[e], t, n, 2);
	d && r(s, t, n);
}
function Jn(e, t, n, r, i, a, { o: { nextSibling: o, parentNode: s, querySelector: c, insert: l, createText: u } }, d) {
	function f(e, n) {
		let r = n;
		for (; r;) {
			if (r && r.nodeType === 8) {
				if (r.data === "teleport start anchor") t.targetStart = r;
				else if (r.data === "teleport anchor") {
					t.targetAnchor = r, e._lpa = t.targetAnchor && o(t.targetAnchor);
					break;
				}
			}
			r = o(r);
		}
	}
	function p(e, t) {
		t.anchor = d(o(e), t, s(e), n, r, i, a);
	}
	let m = t.target = Gn(t.props, c), h = Vn(t.props);
	if (m) {
		let c = m._lpa || m.firstChild;
		t.shapeFlag & 16 && (h ? (p(e, t), f(m, c), t.targetAnchor || Zn(m, t, u, l, s(e) === m ? e : null)) : (t.anchor = o(e), f(m, c), t.targetAnchor || Zn(m, t, u, l), d(c && o(c), t, m, n, r, i, a))), Xn(t, h);
	} else h && t.shapeFlag & 16 && (p(e, t), t.targetStart = e, t.targetAnchor = o(e));
	return t.anchor && o(t.anchor);
}
var Yn = Kn;
function Xn(e, t) {
	let n = e.ctx;
	if (n && n.ut) {
		let r, i;
		for (t ? (r = e.el, i = e.anchor) : (r = e.targetStart, i = e.targetAnchor); r && r !== i;) r.nodeType === 1 && r.setAttribute("data-v-owner", n.uid), r = r.nextSibling;
		n.ut();
	}
}
function Zn(e, t, n, r, i = null) {
	let a = t.targetStart = n(""), o = t.targetAnchor = n("");
	return a[zn] = o, e && (r(a, e, i), r(o, e, i)), o;
}
var Qn = /* @__PURE__ */ Symbol("_leaveCb"), $n = /* @__PURE__ */ Symbol("_enterCb");
function er() {
	let e = {
		isMounted: !1,
		isLeaving: !1,
		isUnmounting: !1,
		leavingVNodes: /* @__PURE__ */ new Map()
	};
	return Or(() => {
		e.isMounted = !0;
	}), jr(() => {
		e.isUnmounting = !0;
	}), e;
}
var tr = [Function, Array], nr = {
	mode: String,
	appear: Boolean,
	persisted: Boolean,
	onBeforeEnter: tr,
	onEnter: tr,
	onAfterEnter: tr,
	onEnterCancelled: tr,
	onBeforeLeave: tr,
	onLeave: tr,
	onAfterLeave: tr,
	onLeaveCancelled: tr,
	onBeforeAppear: tr,
	onAppear: tr,
	onAfterAppear: tr,
	onAppearCancelled: tr
}, rr = (e) => {
	let t = e.subTree;
	return t.component ? rr(t.component) : t;
}, ir = {
	name: "BaseTransition",
	props: nr,
	setup(e, { slots: t }) {
		let n = Sa(), r = er();
		return () => {
			let i = t.default && fr(t.default(), !0), a = i && i.length ? ar(i) : n.subTree ? K() : void 0;
			if (!a) return;
			let o = /* @__PURE__ */ N(e), { mode: s } = o;
			if (r.isLeaving) return lr(a);
			let c = ur(a);
			if (!c) return lr(a);
			let l = cr(c, o, r, n, (e) => l = e);
			c.type !== Xi && dr(c, l);
			let u = n.subTree && ur(n.subTree);
			if (u && u.type !== Xi && !oa(u, c) && rr(n).type !== Xi) {
				let e = cr(u, o, r, n);
				if (dr(u, e), s === "out-in" && c.type !== Xi) return r.isLeaving = !0, e.afterLeave = () => {
					r.isLeaving = !1, n.job.flags & 8 || n.update(), delete e.afterLeave, u = void 0;
				}, lr(a);
				s === "in-out" && c.type !== Xi ? e.delayLeave = (e, t, n) => {
					let i = sr(r, u);
					i[String(u.key)] = u, e[Qn] = () => {
						t(), e[Qn] = void 0, delete l.delayedLeave, u = void 0;
					}, l.delayedLeave = () => {
						n(), delete l.delayedLeave, u = void 0;
					};
				} : u = void 0;
			} else u &&= void 0;
			return a;
		};
	}
};
function ar(e) {
	let t = e[0];
	if (e.length > 1) {
		for (let n of e) if (n.type !== Xi) {
			t = n;
			break;
		}
	}
	return t;
}
var or = ir;
function sr(e, t) {
	let { leavingVNodes: n } = e, r = n.get(t.type);
	return r || (r = /* @__PURE__ */ Object.create(null), n.set(t.type, r)), r;
}
function cr(e, t, n, r, i) {
	let { appear: a, mode: o, persisted: s = !1, onBeforeEnter: c, onEnter: l, onAfterEnter: u, onEnterCancelled: f, onBeforeLeave: p, onLeave: m, onAfterLeave: h, onLeaveCancelled: g, onBeforeAppear: _, onAppear: v, onAfterAppear: y, onAppearCancelled: b } = t, x = String(e.key), S = sr(n, e), C = (e, t) => {
		e && sn(e, r, 9, t);
	}, w = (e, t) => {
		let n = t[1];
		C(e, t), d(e) ? e.every((e) => e.length <= 1) && n() : e.length <= 1 && n();
	}, ee = {
		mode: o,
		persisted: s,
		beforeEnter(t) {
			let r = c;
			if (!n.isMounted) if (a) r = _ || c;
			else return;
			t[Qn] && t[Qn](!0);
			let i = S[x];
			i && oa(e, i) && i.el[Qn] && i.el[Qn](), C(r, [t]);
		},
		enter(t) {
			if (S[x] === e) return;
			let r = l, i = u, o = f;
			if (!n.isMounted) if (a) r = v || l, i = y || u, o = b || f;
			else return;
			let s = !1;
			t[$n] = (e) => {
				s || (s = !0, C(e ? o : i, [t]), ee.delayedLeave && ee.delayedLeave(), t[$n] = void 0);
			};
			let c = t[$n].bind(null, !1);
			r ? w(r, [t, c]) : c();
		},
		leave(t, r) {
			let i = String(e.key);
			if (t[$n] && t[$n](!0), n.isUnmounting) return r();
			C(p, [t]);
			let a = !1;
			t[Qn] = (n) => {
				a || (a = !0, r(), C(n ? g : h, [t]), t[Qn] = void 0, S[i] === e && delete S[i]);
			};
			let o = t[Qn].bind(null, !1);
			S[i] = e, m ? w(m, [t, o]) : o();
		},
		clone(e) {
			let a = cr(e, t, n, r, i);
			return i && i(a), a;
		}
	};
	return ee;
}
function lr(e) {
	if (br(e)) return e = da(e), e.children = null, e;
}
function ur(e) {
	if (!br(e)) return Bn(e.type) && e.children ? ar(e.children) : e;
	if (e.component) return e.component.subTree;
	let { shapeFlag: t, children: n } = e;
	if (n) {
		if (t & 16) return n[0];
		if (t & 32 && h(n.default)) return n.default();
	}
}
function dr(e, t) {
	e.shapeFlag & 6 && e.component ? (e.transition = t, dr(e.component.subTree, t)) : e.shapeFlag & 128 ? (e.ssContent.transition = t.clone(e.ssContent), e.ssFallback.transition = t.clone(e.ssFallback)) : e.transition = t;
}
function fr(e, t = !1, n) {
	let r = [], i = 0;
	for (let a = 0; a < e.length; a++) {
		let o = e[a], s = n == null ? o.key : String(n) + String(o.key == null ? a : o.key);
		o.type === V ? (o.patchFlag & 128 && i++, r = r.concat(fr(o.children, t, s))) : (t || o.type !== Xi) && r.push(s == null ? o : da(o, { key: s }));
	}
	if (i > 1) for (let e = 0; e < r.length; e++) r[e].patchFlag = -2;
	return r;
}
// @__NO_SIDE_EFFECTS__
function pr(e, t) {
	return h(e) ? /* @__PURE__ */ s({ name: e.name }, t, { setup: e }) : e;
}
function mr(e) {
	e.ids = [
		e.ids[0] + e.ids[2]++ + "-",
		0,
		0
	];
}
function hr(e, t) {
	let n;
	return !!((n = Object.getOwnPropertyDescriptor(e, t)) && !n.configurable);
}
var gr = /* @__PURE__ */ new WeakMap();
function _r(e, n, r, a, o = !1) {
	if (d(e)) {
		e.forEach((e, t) => _r(e, n && (d(n) ? n[t] : n), r, a, o));
		return;
	}
	if (yr(a) && !o) {
		a.shapeFlag & 512 && a.type.__asyncResolved && a.component.subTree.component && _r(e, n, r, a.component.subTree);
		return;
	}
	let s = a.shapeFlag & 4 ? La(a.component) : a.el, l = o ? null : s, { i: f, r: p } = e, m = n && n.r, _ = f.refs === t ? f.refs = {} : f.refs, v = f.setupState, y = /* @__PURE__ */ N(v), b = v === t ? i : (e) => !hr(_, e) && u(y, e), x = (e, t) => !(t && hr(_, t));
	if (m != null && m !== p) {
		if (vr(n), g(m)) _[m] = null, b(m) && (v[m] = null);
		else if (/* @__PURE__ */ P(m)) {
			let e = n;
			x(m, e.k) && (m.value = null), e.k && (_[e.k] = null);
		}
	}
	if (h(p)) on(p, f, 12, [l, _]);
	else {
		let t = g(p), n = /* @__PURE__ */ P(p);
		if (t || n) {
			let i = () => {
				if (e.f) {
					let n = t ? b(p) ? v[p] : _[p] : x(p) || !e.k ? p.value : _[e.k];
					if (o) d(n) && c(n, s);
					else if (d(n)) n.includes(s) || n.push(s);
					else if (t) _[p] = [s], b(p) && (v[p] = _[p]);
					else {
						let t = [s];
						x(p, e.k) && (p.value = t), e.k && (_[e.k] = t);
					}
				} else t ? (_[p] = l, b(p) && (v[p] = l)) : n && (x(p, e.k) && (p.value = l), e.k && (_[e.k] = l));
			};
			if (l) {
				let t = () => {
					i(), gr.delete(e);
				};
				t.id = -1, gr.set(e, t), B(t, r);
			} else vr(e), i();
		}
	}
}
function vr(e) {
	let t = gr.get(e);
	t && (t.flags |= 8, gr.delete(e));
}
de().requestIdleCallback, de().cancelIdleCallback;
var yr = (e) => !!e.type.__asyncLoader, br = (e) => e.type.__isKeepAlive;
function xr(e, t) {
	Cr(e, "a", t);
}
function Sr(e, t) {
	Cr(e, "da", t);
}
function Cr(e, t, n = q) {
	let r = e.__wdc ||= () => {
		let t = n;
		for (; t;) {
			if (t.isDeactivated) return;
			t = t.parent;
		}
		return e();
	};
	if (Tr(t, r, n), n) {
		let e = n.parent;
		for (; e && e.parent;) br(e.parent.vnode) && wr(r, t, n, e), e = e.parent;
	}
}
function wr(e, t, n, r) {
	let i = Tr(t, e, r, !0);
	Mr(() => {
		c(r[t], i);
	}, n);
}
function Tr(e, t, n = q, r = !1) {
	if (n) {
		let i = n[e] || (n[e] = []), a = t.__weh ||= (...r) => {
			We();
			let i = Ta(n), a = sn(t, n, e, r);
			return i(), Ge(), a;
		};
		return r ? i.unshift(a) : i.push(a), a;
	}
}
var Er = (e) => (t, n = q) => {
	(!Oa || e === "sp") && Tr(e, (...e) => t(...e), n);
}, Dr = Er("bm"), Or = Er("m"), kr = Er("bu"), Ar = Er("u"), jr = Er("bum"), Mr = Er("um"), Nr = Er("sp"), Pr = Er("rtg"), Fr = Er("rtc");
function Ir(e, t = q) {
	Tr("ec", e, t);
}
var Lr = /* @__PURE__ */ Symbol.for("v-ndc");
function R(e, t, n, r) {
	let i, a = n && n[r], o = d(e);
	if (o || g(e)) {
		let n = o && /* @__PURE__ */ zt(e), r = !1, s = !1;
		n && (r = !/* @__PURE__ */ Vt(e), s = /* @__PURE__ */ Bt(e), e = rt(e)), i = Array(e.length);
		for (let n = 0, o = e.length; n < o; n++) i[n] = t(r ? s ? Gt(Wt(e[n])) : Wt(e[n]) : e[n], n, void 0, a && a[n]);
	} else if (typeof e == "number") {
		i = Array(e);
		for (let n = 0; n < e; n++) i[n] = t(n + 1, n, void 0, a && a[n]);
	} else if (v(e)) if (e[Symbol.iterator]) i = Array.from(e, (e, n) => t(e, n, void 0, a && a[n]));
	else {
		let n = Object.keys(e);
		i = Array(n.length);
		for (let r = 0, o = n.length; r < o; r++) {
			let o = n[r];
			i[r] = t(e[o], o, r, a && a[r]);
		}
	}
	else i = [];
	return n && (n[r] = i), i;
}
var Rr = (e) => e ? Da(e) ? La(e) : Rr(e.parent) : null, zr = /* @__PURE__ */ s(/* @__PURE__ */ Object.create(null), {
	$: (e) => e,
	$el: (e) => e.vnode.el,
	$data: (e) => e.data,
	$props: (e) => e.props,
	$attrs: (e) => e.attrs,
	$slots: (e) => e.slots,
	$refs: (e) => e.refs,
	$parent: (e) => Rr(e.parent),
	$root: (e) => Rr(e.root),
	$host: (e) => e.ce,
	$emit: (e) => e.emit,
	$options: (e) => Jr(e),
	$forceUpdate: (e) => e.f ||= () => {
		vn(e.update);
	},
	$nextTick: (e) => e.n ||= gn.bind(e.proxy),
	$watch: (e) => In.bind(e)
}), Br = (e, n) => e !== t && !e.__isScriptSetup && u(e, n), Vr = {
	get({ _: e }, n) {
		if (n === "__v_skip") return !0;
		let { ctx: r, setupState: i, data: a, props: o, accessCache: s, type: c, appContext: l } = e;
		if (n[0] !== "$") {
			let e = s[n];
			if (e !== void 0) switch (e) {
				case 1: return i[n];
				case 2: return a[n];
				case 4: return r[n];
				case 3: return o[n];
			}
			else if (Br(i, n)) return s[n] = 1, i[n];
			else if (a !== t && u(a, n)) return s[n] = 2, a[n];
			else if (u(o, n)) return s[n] = 3, o[n];
			else if (r !== t && u(r, n)) return s[n] = 4, r[n];
			else Ur && (s[n] = 0);
		}
		let d = zr[n], f, p;
		if (d) return n === "$attrs" && M(e.attrs, "get", ""), d(e);
		if ((f = c.__cssModules) && (f = f[n])) return f;
		if (r !== t && u(r, n)) return s[n] = 4, r[n];
		if (p = l.config.globalProperties, u(p, n)) return p[n];
	},
	set({ _: e }, n, r) {
		let { data: i, setupState: a, ctx: o } = e;
		return Br(a, n) ? (a[n] = r, !0) : i !== t && u(i, n) ? (i[n] = r, !0) : u(e.props, n) || n[0] === "$" && n.slice(1) in e ? !1 : (o[n] = r, !0);
	},
	has({ _: { data: e, setupState: n, accessCache: r, ctx: i, appContext: a, props: o, type: s } }, c) {
		let l;
		return !!(r[c] || e !== t && c[0] !== "$" && u(e, c) || Br(n, c) || u(o, c) || u(i, c) || u(zr, c) || u(a.config.globalProperties, c) || (l = s.__cssModules) && l[c]);
	},
	defineProperty(e, t, n) {
		return n.get == null ? u(n, "value") && this.set(e, t, n.value, null) : e._.accessCache[t] = 0, Reflect.defineProperty(e, t, n);
	}
};
function Hr(e) {
	return d(e) ? e.reduce((e, t) => (e[t] = null, e), {}) : e;
}
var Ur = !0;
function Wr(e) {
	let t = Jr(e), n = e.proxy, i = e.ctx;
	Ur = !1, t.beforeCreate && Kr(t.beforeCreate, e, "bc");
	let { data: a, computed: o, methods: s, watch: c, provide: l, inject: u, created: f, beforeMount: p, mounted: m, beforeUpdate: g, updated: _, activated: y, deactivated: b, beforeDestroy: x, beforeUnmount: S, destroyed: C, unmounted: w, render: ee, renderTracked: te, renderTriggered: ne, errorCaptured: T, serverPrefetch: re, expose: E, inheritAttrs: ie, components: ae, directives: oe, filters: se } = t;
	if (u && Gr(u, i, null), s) for (let e in s) {
		let t = s[e];
		h(t) && (i[e] = t.bind(n));
	}
	if (a) {
		let t = a.call(n, n);
		v(t) && (e.data = /* @__PURE__ */ Ft(t));
	}
	if (Ur = !0, o) for (let e in o) {
		let t = o[e], a = J({
			get: h(t) ? t.bind(n, n) : h(t.get) ? t.get.bind(n, n) : r,
			set: !h(t) && h(t.set) ? t.set.bind(n) : r
		});
		Object.defineProperty(i, e, {
			enumerable: !0,
			configurable: !0,
			get: () => a.value,
			set: (e) => a.value = e
		});
	}
	if (c) for (let e in c) qr(c[e], i, n, e);
	if (l) {
		let e = h(l) ? l.call(n) : l;
		Reflect.ownKeys(e).forEach((t) => {
			An(t, e[t]);
		});
	}
	f && Kr(f, e, "c");
	function D(e, t) {
		d(t) ? t.forEach((t) => e(t.bind(n))) : t && e(t.bind(n));
	}
	if (D(Dr, p), D(Or, m), D(kr, g), D(Ar, _), D(xr, y), D(Sr, b), D(Ir, T), D(Fr, te), D(Pr, ne), D(jr, S), D(Mr, w), D(Nr, re), d(E)) if (E.length) {
		let t = e.exposed ||= {};
		E.forEach((e) => {
			Object.defineProperty(t, e, {
				get: () => n[e],
				set: (t) => n[e] = t,
				enumerable: !0
			});
		});
	} else e.exposed ||= {};
	ee && e.render === r && (e.render = ee), ie != null && (e.inheritAttrs = ie), ae && (e.components = ae), oe && (e.directives = oe), re && mr(e);
}
function Gr(e, t, n = r) {
	d(e) && (e = $r(e));
	for (let n in e) {
		let r = e[n], i;
		i = v(r) ? "default" in r ? jn(r.from || n, r.default, !0) : jn(r.from || n) : jn(r), /* @__PURE__ */ P(i) ? Object.defineProperty(t, n, {
			enumerable: !0,
			configurable: !0,
			get: () => i.value,
			set: (e) => i.value = e
		}) : t[n] = i;
	}
}
function Kr(e, t, n) {
	sn(d(e) ? e.map((e) => e.bind(t.proxy)) : e.bind(t.proxy), t, n);
}
function qr(e, t, n, r) {
	let i = r.includes(".") ? Ln(n, r) : () => n[r];
	if (g(e)) {
		let n = t[e];
		h(n) && Pn(i, n);
	} else if (h(e)) Pn(i, e.bind(n));
	else if (v(e)) if (d(e)) e.forEach((e) => qr(e, t, n, r));
	else {
		let r = h(e.handler) ? e.handler.bind(n) : t[e.handler];
		h(r) && Pn(i, r, e);
	}
}
function Jr(e) {
	let t = e.type, { mixins: n, extends: r } = t, { mixins: i, optionsCache: a, config: { optionMergeStrategies: o } } = e.appContext, s = a.get(t), c;
	return s ? c = s : !i.length && !n && !r ? c = t : (c = {}, i.length && i.forEach((e) => Yr(c, e, o, !0)), Yr(c, t, o)), v(t) && a.set(t, c), c;
}
function Yr(e, t, n, r = !1) {
	let { mixins: i, extends: a } = t;
	a && Yr(e, a, n, !0), i && i.forEach((t) => Yr(e, t, n, !0));
	for (let i in t) if (!(r && i === "expose")) {
		let r = Xr[i] || n && n[i];
		e[i] = r ? r(e[i], t[i]) : t[i];
	}
	return e;
}
var Xr = {
	data: Zr,
	props: ti,
	emits: ti,
	methods: ei,
	computed: ei,
	beforeCreate: z,
	created: z,
	beforeMount: z,
	mounted: z,
	beforeUpdate: z,
	updated: z,
	beforeDestroy: z,
	beforeUnmount: z,
	destroyed: z,
	unmounted: z,
	activated: z,
	deactivated: z,
	errorCaptured: z,
	serverPrefetch: z,
	components: ei,
	directives: ei,
	watch: ni,
	provide: Zr,
	inject: Qr
};
function Zr(e, t) {
	return t ? e ? function() {
		return s(h(e) ? e.call(this, this) : e, h(t) ? t.call(this, this) : t);
	} : t : e;
}
function Qr(e, t) {
	return ei($r(e), $r(t));
}
function $r(e) {
	if (d(e)) {
		let t = {};
		for (let n = 0; n < e.length; n++) t[e[n]] = e[n];
		return t;
	}
	return e;
}
function z(e, t) {
	return e ? [...new Set([].concat(e, t))] : t;
}
function ei(e, t) {
	return e ? s(/* @__PURE__ */ Object.create(null), e, t) : t;
}
function ti(e, t) {
	return e ? d(e) && d(t) ? [.../* @__PURE__ */ new Set([...e, ...t])] : s(/* @__PURE__ */ Object.create(null), Hr(e), Hr(t ?? {})) : t;
}
function ni(e, t) {
	if (!e) return t;
	if (!t) return e;
	let n = s(/* @__PURE__ */ Object.create(null), e);
	for (let r in t) n[r] = z(e[r], t[r]);
	return n;
}
function ri() {
	return {
		app: null,
		config: {
			isNativeTag: i,
			performance: !1,
			globalProperties: {},
			optionMergeStrategies: {},
			errorHandler: void 0,
			warnHandler: void 0,
			compilerOptions: {}
		},
		mixins: [],
		components: {},
		directives: {},
		provides: /* @__PURE__ */ Object.create(null),
		optionsCache: /* @__PURE__ */ new WeakMap(),
		propsCache: /* @__PURE__ */ new WeakMap(),
		emitsCache: /* @__PURE__ */ new WeakMap()
	};
}
var ii = 0;
function ai(e, t) {
	return function(n, r = null) {
		h(n) || (n = s({}, n)), r != null && !v(r) && (r = null);
		let i = ri(), a = /* @__PURE__ */ new WeakSet(), o = [], c = !1, l = i.app = {
			_uid: ii++,
			_component: n,
			_props: r,
			_container: null,
			_context: i,
			_instance: null,
			version: Ba,
			get config() {
				return i.config;
			},
			set config(e) {},
			use(e, ...t) {
				return a.has(e) || (e && h(e.install) ? (a.add(e), e.install(l, ...t)) : h(e) && (a.add(e), e(l, ...t))), l;
			},
			mixin(e) {
				return i.mixins.includes(e) || i.mixins.push(e), l;
			},
			component(e, t) {
				return t ? (i.components[e] = t, l) : i.components[e];
			},
			directive(e, t) {
				return t ? (i.directives[e] = t, l) : i.directives[e];
			},
			mount(a, o, s) {
				if (!c) {
					let u = l._ceVNode || G(n, r);
					return u.appContext = i, s === !0 ? s = "svg" : s === !1 && (s = void 0), o && t ? t(u, a) : e(u, a, s), c = !0, l._container = a, a.__vue_app__ = l, La(u.component);
				}
			},
			onUnmount(e) {
				o.push(e);
			},
			unmount() {
				c && (sn(o, l._instance, 16), e(null, l._container), delete l._container.__vue_app__);
			},
			provide(e, t) {
				return i.provides[e] = t, l;
			},
			runWithContext(e) {
				let t = oi;
				oi = l;
				try {
					return e();
				} finally {
					oi = t;
				}
			}
		};
		return l;
	};
}
var oi = null, si = (e, t) => t === "modelValue" || t === "model-value" ? e.modelModifiers : e[`${t}Modifiers`] || e[`${T(t)}Modifiers`] || e[`${E(t)}Modifiers`];
function ci(e, n, ...r) {
	if (e.isUnmounted) return;
	let i = e.vnode.props || t, a = r, o = n.startsWith("update:"), s = o && si(i, n.slice(7));
	s && (s.trim && (a = r.map((e) => g(e) ? e.trim() : e)), s.number && (a = r.map(ce)));
	let c, l = i[c = ae(n)] || i[c = ae(T(n))];
	!l && o && (l = i[c = ae(E(n))]), l && sn(l, e, 6, a);
	let u = i[c + "Once"];
	if (u) {
		if (!e.emitted) e.emitted = {};
		else if (e.emitted[c]) return;
		e.emitted[c] = !0, sn(u, e, 6, a);
	}
}
var li = /* @__PURE__ */ new WeakMap();
function ui(e, t, n = !1) {
	let r = n ? li : t.emitsCache, i = r.get(e);
	if (i !== void 0) return i;
	let a = e.emits, o = {}, c = !1;
	if (!h(e)) {
		let r = (e) => {
			let n = ui(e, t, !0);
			n && (c = !0, s(o, n));
		};
		!n && t.mixins.length && t.mixins.forEach(r), e.extends && r(e.extends), e.mixins && e.mixins.forEach(r);
	}
	return !a && !c ? (v(e) && r.set(e, null), null) : (d(a) ? a.forEach((e) => o[e] = null) : s(o, a), v(e) && r.set(e, o), o);
}
function di(e, t) {
	return !e || !a(t) ? !1 : (t = t.slice(2), t = t === "Once" ? t : t.replace(/Once$/, ""), u(e, t[0].toLowerCase() + t.slice(1)) || u(e, E(t)) || u(e, t));
}
function fi(e) {
	let { type: t, vnode: n, proxy: r, withProxy: i, propsOptions: [a], slots: s, attrs: c, emit: l, render: u, renderCache: d, props: f, data: p, setupState: m, ctx: h, inheritAttrs: g } = e, _ = Dn(e), v, y;
	try {
		if (n.shapeFlag & 4) {
			let e = i || r, t = e;
			v = ma(u.call(t, e, d, f, m, p, h)), y = c;
		} else {
			let e = t;
			v = ma(e.length > 1 ? e(f, {
				attrs: c,
				slots: s,
				emit: l
			}) : e(f, null)), y = t.props ? c : pi(c);
		}
	} catch (t) {
		Qi.length = 0, cn(t, e, 1), v = G(Xi);
	}
	let b = v;
	if (y && g !== !1) {
		let e = Object.keys(y), { shapeFlag: t } = b;
		e.length && t & 7 && (a && e.some(o) && (y = mi(y, a)), b = da(b, y, !1, !0));
	}
	return n.dirs && (b = da(b, null, !1, !0), b.dirs = b.dirs ? b.dirs.concat(n.dirs) : n.dirs), n.transition && dr(b, n.transition), v = b, Dn(_), v;
}
var pi = (e) => {
	let t;
	for (let n in e) (n === "class" || n === "style" || a(n)) && ((t ||= {})[n] = e[n]);
	return t;
}, mi = (e, t) => {
	let n = {};
	for (let r in e) (!o(r) || !(r.slice(9) in t)) && (n[r] = e[r]);
	return n;
};
function hi(e, t, n) {
	let { props: r, children: i, component: a } = e, { props: o, children: s, patchFlag: c } = t, l = a.emitsOptions;
	if (t.dirs || t.transition) return !0;
	if (n && c >= 0) {
		if (c & 1024) return !0;
		if (c & 16) return r ? gi(r, o, l) : !!o;
		if (c & 8) {
			let e = t.dynamicProps;
			for (let t = 0; t < e.length; t++) {
				let n = e[t];
				if (_i(o, r, n) && !di(l, n)) return !0;
			}
		}
	} else return (i || s) && (!s || !s.$stable) ? !0 : r === o ? !1 : r ? !o || gi(r, o, l) : !!o;
	return !1;
}
function gi(e, t, n) {
	let r = Object.keys(t);
	if (r.length !== Object.keys(e).length) return !0;
	for (let i = 0; i < r.length; i++) {
		let a = r[i];
		if (_i(t, e, a) && !di(n, a)) return !0;
	}
	return !1;
}
function _i(e, t, n) {
	let r = e[n], i = t[n];
	return n === "style" && v(r) && v(i) ? !xe(r, i) : r !== i;
}
function vi({ vnode: e, parent: t, suspense: n }, r) {
	for (; t;) {
		let n = t.subTree;
		if (n.suspense && n.suspense.activeBranch === e && (n.suspense.vnode.el = n.el = r, e = n), n === e) (e = t.vnode).el = r, t = t.parent;
		else break;
	}
	n && n.activeBranch === e && (n.vnode.el = r);
}
var yi = {}, bi = () => Object.create(yi), xi = (e) => Object.getPrototypeOf(e) === yi;
function Si(e, t, n, r = !1) {
	let i = {}, a = bi();
	e.propsDefaults = /* @__PURE__ */ Object.create(null), wi(e, t, i, a);
	for (let t in e.propsOptions[0]) t in i || (i[t] = void 0);
	e.props = n ? r ? i : /* @__PURE__ */ It(i) : e.type.props ? i : a, e.attrs = a;
}
function Ci(e, t, n, r) {
	let { props: i, attrs: a, vnode: { patchFlag: o } } = e, s = /* @__PURE__ */ N(i), [c] = e.propsOptions, l = !1;
	if ((r || o > 0) && !(o & 16)) {
		if (o & 8) {
			let n = e.vnode.dynamicProps;
			for (let r = 0; r < n.length; r++) {
				let o = n[r];
				if (di(e.emitsOptions, o)) continue;
				let d = t[o];
				if (c) if (u(a, o)) d !== a[o] && (a[o] = d, l = !0);
				else {
					let t = T(o);
					i[t] = Ti(c, s, t, d, e, !1);
				}
				else d !== a[o] && (a[o] = d, l = !0);
			}
		}
	} else {
		wi(e, t, i, a) && (l = !0);
		let r;
		for (let a in s) (!t || !u(t, a) && ((r = E(a)) === a || !u(t, r))) && (c ? n && (n[a] !== void 0 || n[r] !== void 0) && (i[a] = Ti(c, s, a, void 0, e, !0)) : delete i[a]);
		if (a !== s) for (let e in a) (!t || !u(t, e)) && (delete a[e], l = !0);
	}
	l && tt(e.attrs, "set", "");
}
function wi(e, n, r, i) {
	let [a, o] = e.propsOptions, s = !1, c;
	if (n) for (let t in n) {
		if (ee(t)) continue;
		let l = n[t], d;
		a && u(a, d = T(t)) ? !o || !o.includes(d) ? r[d] = l : (c ||= {})[d] = l : di(e.emitsOptions, t) || (!(t in i) || l !== i[t]) && (i[t] = l, s = !0);
	}
	if (o) {
		let n = /* @__PURE__ */ N(r), i = c || t;
		for (let t = 0; t < o.length; t++) {
			let s = o[t];
			r[s] = Ti(a, n, s, i[s], e, !u(i, s));
		}
	}
	return s;
}
function Ti(e, t, n, r, i, a) {
	let o = e[n];
	if (o != null) {
		let e = u(o, "default");
		if (e && r === void 0) {
			let e = o.default;
			if (o.type !== Function && !o.skipFactory && h(e)) {
				let { propsDefaults: a } = i;
				if (n in a) r = a[n];
				else {
					let o = Ta(i);
					r = a[n] = e.call(null, t), o();
				}
			} else r = e;
			i.ce && i.ce._setProp(n, r);
		}
		o[0] && (a && !e ? r = !1 : o[1] && (r === "" || r === E(n)) && (r = !0));
	}
	return r;
}
var Ei = /* @__PURE__ */ new WeakMap();
function Di(e, r, i = !1) {
	let a = i ? Ei : r.propsCache, o = a.get(e);
	if (o) return o;
	let c = e.props, l = {}, f = [], p = !1;
	if (!h(e)) {
		let t = (e) => {
			p = !0;
			let [t, n] = Di(e, r, !0);
			s(l, t), n && f.push(...n);
		};
		!i && r.mixins.length && r.mixins.forEach(t), e.extends && t(e.extends), e.mixins && e.mixins.forEach(t);
	}
	if (!c && !p) return v(e) && a.set(e, n), n;
	if (d(c)) for (let e = 0; e < c.length; e++) {
		let n = T(c[e]);
		Oi(n) && (l[n] = t);
	}
	else if (c) for (let e in c) {
		let t = T(e);
		if (Oi(t)) {
			let n = c[e], r = l[t] = d(n) || h(n) ? { type: n } : s({}, n), i = r.type, a = !1, o = !0;
			if (d(i)) for (let e = 0; e < i.length; ++e) {
				let t = i[e], n = h(t) && t.name;
				if (n === "Boolean") {
					a = !0;
					break;
				}
				n === "String" && (o = !1);
			}
			else a = h(i) && i.name === "Boolean";
			r[0] = a, r[1] = o, (a || u(r, "default")) && f.push(t);
		}
	}
	let m = [l, f];
	return v(e) && a.set(e, m), m;
}
function Oi(e) {
	return e[0] !== "$" && !ee(e);
}
var ki = (e) => e === "_" || e === "_ctx" || e === "$stable", Ai = (e) => d(e) ? e.map(ma) : [ma(e)], ji = (e, t, n) => {
	if (t._n) return t;
	let r = On((...e) => Ai(t(...e)), n);
	return r._c = !1, r;
}, Mi = (e, t, n) => {
	let r = e._ctx;
	for (let n in e) {
		if (ki(n)) continue;
		let i = e[n];
		if (h(i)) t[n] = ji(n, i, r);
		else if (i != null) {
			let e = Ai(i);
			t[n] = () => e;
		}
	}
}, Ni = (e, t) => {
	let n = Ai(t);
	e.slots.default = () => n;
}, Pi = (e, t, n) => {
	for (let r in t) (n || !ki(r)) && (e[r] = t[r]);
}, Fi = (e, t, n) => {
	let r = e.slots = bi();
	if (e.vnode.shapeFlag & 32) {
		let e = t._;
		e ? (Pi(r, t, n), n && D(r, "_", e, !0)) : Mi(t, r);
	} else t && Ni(e, t);
}, Ii = (e, n, r) => {
	let { vnode: i, slots: a } = e, o = !0, s = t;
	if (i.shapeFlag & 32) {
		let e = n._;
		e ? r && e === 1 ? o = !1 : Pi(a, n, r) : (o = !n.$stable, Mi(n, a)), s = n;
	} else n && (Ni(e, n), s = { default: 1 });
	if (o) for (let e in a) !ki(e) && s[e] == null && delete a[e];
}, B = Ji;
function Li(e) {
	return Ri(e);
}
function Ri(e, i) {
	let a = de();
	a.__VUE__ = !0;
	let { insert: o, remove: s, patchProp: c, createElement: l, createText: u, createComment: d, setText: f, setElementText: p, parentNode: m, nextSibling: h, setScopeId: g = r, insertStaticContent: _ } = e, v = (e, t, n, r = null, i = null, a = null, o = void 0, s = null, c = !!t.dynamicChildren) => {
		if (e === t) return;
		e && !oa(e, t) && (r = be(e), ge(e, i, a, !0), e = null), t.patchFlag === -2 && (c = !1, t.dynamicChildren = null);
		let { type: l, ref: u, shapeFlag: d } = t;
		switch (l) {
			case Yi:
				y(e, t, n, r);
				break;
			case Xi:
				b(e, t, n, r);
				break;
			case Zi:
				e ?? x(t, n, r, o);
				break;
			case V:
				ae(e, t, n, r, i, a, o, s, c);
				break;
			default: d & 1 ? w(e, t, n, r, i, a, o, s, c) : d & 6 ? oe(e, t, n, r, i, a, o, s, c) : (d & 64 || d & 128) && l.process(e, t, n, r, i, a, o, s, c, Ce);
		}
		u != null && i ? _r(u, e && e.ref, a, t || e, !t) : u == null && e && e.ref != null && _r(e.ref, null, a, e, !0);
	}, y = (e, t, n, r) => {
		if (e == null) o(t.el = u(t.children), n, r);
		else {
			let n = t.el = e.el;
			t.children !== e.children && f(n, t.children);
		}
	}, b = (e, t, n, r) => {
		e == null ? o(t.el = d(t.children || ""), n, r) : t.el = e.el;
	}, x = (e, t, n, r) => {
		[e.el, e.anchor] = _(e.children, t, n, r, e.el, e.anchor);
	}, S = ({ el: e, anchor: t }, n, r) => {
		let i;
		for (; e && e !== t;) i = h(e), o(e, n, r), e = i;
		o(t, n, r);
	}, C = ({ el: e, anchor: t }) => {
		let n;
		for (; e && e !== t;) n = h(e), s(e), e = n;
		s(t);
	}, w = (e, t, n, r, i, a, o, s, c) => {
		if (t.type === "svg" ? o = "svg" : t.type === "math" && (o = "mathml"), e == null) te(t, n, r, i, a, o, s, c);
		else {
			let n = e.el && e.el._isVueCE ? e.el : null;
			try {
				n && n._beginPatch(), re(e, t, i, a, o, s, c);
			} finally {
				n && n._endPatch();
			}
		}
	}, te = (e, t, n, r, i, a, s, u) => {
		let d, f, { props: m, shapeFlag: h, transition: g, dirs: _ } = e;
		if (d = e.el = l(e.type, a, m && m.is, m), h & 8 ? p(d, e.children) : h & 16 && T(e.children, d, null, r, i, zi(e, a), s, u), _ && kn(e, null, r, "created"), ne(d, e, e.scopeId, s, r), m) {
			for (let e in m) e !== "value" && !ee(e) && c(d, e, null, m[e], a, r);
			"value" in m && c(d, "value", null, m.value, a), (f = m.onVnodeBeforeMount) && va(f, r, e);
		}
		_ && kn(e, null, r, "beforeMount");
		let v = Vi(i, g);
		v && g.beforeEnter(d), o(d, t, n), ((f = m && m.onVnodeMounted) || v || _) && B(() => {
			try {
				f && va(f, r, e), v && g.enter(d), _ && kn(e, null, r, "mounted");
			} finally {}
		}, i);
	}, ne = (e, t, n, r, i) => {
		if (n && g(e, n), r) for (let t = 0; t < r.length; t++) g(e, r[t]);
		if (i) {
			let n = i.subTree;
			if (t === n || qi(n.type) && (n.ssContent === t || n.ssFallback === t)) {
				let t = i.vnode;
				ne(e, t, t.scopeId, t.slotScopeIds, i.parent);
			}
		}
	}, T = (e, t, n, r, i, a, o, s, c = 0) => {
		for (let l = c; l < e.length; l++) {
			let c = e[l] = s ? ha(e[l]) : ma(e[l]);
			v(null, c, t, n, r, i, a, o, s);
		}
	}, re = (e, n, r, i, a, o, s) => {
		let l = n.el = e.el, { patchFlag: u, dynamicChildren: d, dirs: f } = n;
		u |= e.patchFlag & 16;
		let m = e.props || t, h = n.props || t, g;
		if (r && Bi(r, !1), (g = h.onVnodeBeforeUpdate) && va(g, r, n, e), f && kn(n, e, r, "beforeUpdate"), r && Bi(r, !0), d && (!e.dynamicChildren || e.dynamicChildren.length !== d.length) && (u = 0, s = !1, d = null), (m.innerHTML && h.innerHTML == null || m.textContent && h.textContent == null) && p(l, ""), d ? E(e.dynamicChildren, d, l, r, i, zi(n, a), o) : s || fe(e, n, l, null, r, i, zi(n, a), o, !1), u > 0) {
			if (u & 16) ie(l, m, h, r, a);
			else if (u & 2 && m.class !== h.class && c(l, "class", null, h.class, a), u & 4 && c(l, "style", m.style, h.style, a), u & 8) {
				let e = n.dynamicProps;
				for (let t = 0; t < e.length; t++) {
					let n = e[t], i = m[n], o = h[n];
					(o !== i || n === "value") && c(l, n, i, o, a, r);
				}
			}
			u & 1 && e.children !== n.children && p(l, n.children);
		} else !s && d == null && ie(l, m, h, r, a);
		((g = h.onVnodeUpdated) || f) && B(() => {
			g && va(g, r, n, e), f && kn(n, e, r, "updated");
		}, i);
	}, E = (e, t, n, r, i, a, o) => {
		for (let s = 0; s < t.length; s++) {
			let c = e[s], l = t[s], u = c.el && (c.type === V || !oa(c, l) || c.shapeFlag & 198) ? m(c.el) : n;
			v(c, l, u, null, r, i, a, o, !0);
		}
	}, ie = (e, n, r, i, a) => {
		if (n !== r) {
			if (n !== t) for (let t in n) !ee(t) && !(t in r) && c(e, t, n[t], null, a, i);
			for (let t in r) {
				if (ee(t)) continue;
				let o = r[t], s = n[t];
				o !== s && t !== "value" && c(e, t, s, o, a, i);
			}
			"value" in r && c(e, "value", n.value, r.value, a);
		}
	}, ae = (e, t, n, r, i, a, s, c, l) => {
		let d = t.el = e ? e.el : u(""), f = t.anchor = e ? e.anchor : u(""), { patchFlag: p, dynamicChildren: m, slotScopeIds: h } = t;
		h && (c = c ? c.concat(h) : h), e == null ? (o(d, n, r), o(f, n, r), T(t.children || [], n, f, i, a, s, c, l)) : p > 0 && p & 64 && m && e.dynamicChildren && e.dynamicChildren.length === m.length ? (E(e.dynamicChildren, m, n, i, a, s, c), (t.key != null || i && t === i.subTree) && Hi(e, t, !0)) : fe(e, t, n, f, i, a, s, c, l);
	}, oe = (e, t, n, r, i, a, o, s, c) => {
		t.slotScopeIds = s, e == null ? t.shapeFlag & 512 ? i.ctx.activate(t, n, r, o, c) : D(t, n, r, i, a, o, c) : ce(e, t, c);
	}, D = (e, t, n, r, i, a, o) => {
		let s = e.component = xa(e, r, i);
		if (br(e) && (s.ctx.renderer = Ce), ka(s, !1, o), s.asyncDep) {
			if (i && i.registerDep(s, le, o), !e.el) {
				let r = s.subTree = G(Xi);
				b(null, r, t, n), e.placeholder = r.el;
			}
		} else le(s, e, t, n, i, a, o);
	}, ce = (e, t, n) => {
		let r = t.component = e.component;
		if (hi(e, t, n)) if (r.asyncDep && !r.asyncResolved) {
			ue(r, t, n);
			return;
		} else r.next = t, r.update();
		else t.el = e.el, r.vnode = t;
	}, le = (e, t, n, r, i, a, o) => {
		let s = () => {
			if (e.isMounted) {
				let { next: t, bu: n, u: r, parent: s, vnode: c } = e;
				{
					let n = Wi(e);
					if (n) {
						t && (t.el = c.el, ue(e, t, o)), n.asyncDep.then(() => {
							B(() => {
								e.isUnmounted || l();
							}, i);
						});
						return;
					}
				}
				let u = t, d;
				Bi(e, !1), t ? (t.el = c.el, ue(e, t, o)) : t = c, n && se(n), (d = t.props && t.props.onVnodeBeforeUpdate) && va(d, s, t, c), Bi(e, !0);
				let f = fi(e), p = e.subTree;
				e.subTree = f, v(p, f, m(p.el), be(p), e, i, a), t.el = f.el, u === null && vi(e, f.el), r && B(r, i), (d = t.props && t.props.onVnodeUpdated) && B(() => va(d, s, t, c), i);
			} else {
				let o, { el: s, props: c } = t, { bm: l, m: u, parent: d, root: f, type: p } = e, m = yr(t);
				if (Bi(e, !1), l && se(l), !m && (o = c && c.onVnodeBeforeMount) && va(o, d, t), Bi(e, !0), s && we) {
					let t = () => {
						e.subTree = fi(e), we(s, e.subTree, e, i, null);
					};
					m && p.__asyncHydrate ? p.__asyncHydrate(s, e, t) : t();
				} else {
					f.ce && f.ce._hasShadowRoot() && f.ce._injectChildStyle(p, e.parent ? e.parent.type : void 0);
					let o = e.subTree = fi(e);
					v(null, o, n, r, e, i, a), t.el = o.el;
				}
				if (u && B(u, i), !m && (o = c && c.onVnodeMounted)) {
					let e = t;
					B(() => va(o, d, e), i);
				}
				(t.shapeFlag & 256 || d && yr(d.vnode) && d.vnode.shapeFlag & 256) && e.a && B(e.a, i), e.isMounted = !0, t = n = r = null;
			}
		};
		e.scope.on();
		let c = e.effect = new ke(s);
		e.scope.off();
		let l = e.update = c.run.bind(c), u = e.job = c.runIfDirty.bind(c);
		u.i = e, u.id = e.uid, c.scheduler = () => vn(u), Bi(e, !0), l();
	}, ue = (e, t, n) => {
		t.component = e;
		let r = e.vnode.props;
		e.vnode = t, e.next = null, Ci(e, t.props, r, n), Ii(e, t.children, n), We(), xn(e), Ge();
	}, fe = (e, t, n, r, i, a, o, s, c = !1) => {
		let l = e && e.children, u = e ? e.shapeFlag : 0, d = t.children, { patchFlag: f, shapeFlag: m } = t;
		if (f > 0) {
			if (f & 128) {
				me(l, d, n, r, i, a, o, s, c);
				return;
			}
			if (f & 256) {
				pe(l, d, n, r, i, a, o, s, c);
				return;
			}
		}
		m & 8 ? (u & 16 && ye(l, i, a), d !== l && p(n, d)) : u & 16 ? m & 16 ? me(l, d, n, r, i, a, o, s, c) : ye(l, i, a, !0) : (u & 8 && p(n, ""), m & 16 && T(d, n, r, i, a, o, s, c));
	}, pe = (e, t, r, i, a, o, s, c, l) => {
		e ||= n, t ||= n;
		let u = e.length, d = t.length, f = Math.min(u, d), p;
		for (p = 0; p < f; p++) {
			let n = t[p] = l ? ha(t[p]) : ma(t[p]);
			v(e[p], n, r, null, a, o, s, c, l);
		}
		u > d ? ye(e, a, o, !0, !1, f) : T(t, r, i, a, o, s, c, l, f);
	}, me = (e, t, r, i, a, o, s, c, l) => {
		let u = 0, d = t.length, f = e.length - 1, p = d - 1;
		for (; u <= f && u <= p;) {
			let n = e[u], i = t[u] = l ? ha(t[u]) : ma(t[u]);
			if (oa(n, i)) v(n, i, r, null, a, o, s, c, l);
			else break;
			u++;
		}
		for (; u <= f && u <= p;) {
			let n = e[f], i = t[p] = l ? ha(t[p]) : ma(t[p]);
			if (oa(n, i)) v(n, i, r, null, a, o, s, c, l);
			else break;
			f--, p--;
		}
		if (u > f) {
			if (u <= p) {
				let e = p + 1, n = e < d ? t[e].el : i;
				for (; u <= p;) v(null, t[u] = l ? ha(t[u]) : ma(t[u]), r, n, a, o, s, c, l), u++;
			}
		} else if (u > p) for (; u <= f;) ge(e[u], a, o, !0), u++;
		else {
			let m = u, h = u, g = /* @__PURE__ */ new Map();
			for (u = h; u <= p; u++) {
				let e = t[u] = l ? ha(t[u]) : ma(t[u]);
				e.key != null && g.set(e.key, u);
			}
			let _, y = 0, b = p - h + 1, x = !1, S = 0, C = Array(b);
			for (u = 0; u < b; u++) C[u] = 0;
			for (u = m; u <= f; u++) {
				let n = e[u];
				if (y >= b) {
					ge(n, a, o, !0);
					continue;
				}
				let i;
				if (n.key != null) i = g.get(n.key);
				else for (_ = h; _ <= p; _++) if (C[_ - h] === 0 && oa(n, t[_])) {
					i = _;
					break;
				}
				i === void 0 ? ge(n, a, o, !0) : (C[i - h] = u + 1, i >= S ? S = i : x = !0, v(n, t[i], r, null, a, o, s, c, l), y++);
			}
			let w = x ? Ui(C) : n;
			for (_ = w.length - 1, u = b - 1; u >= 0; u--) {
				let e = h + u, n = t[e], f = t[e + 1], p = e + 1 < d ? f.el || Ki(f) : i;
				C[u] === 0 ? v(null, n, r, p, a, o, s, c, l) : x && (_ < 0 || u !== w[_] ? he(n, r, p, 2) : _--);
			}
		}
	}, he = (e, t, n, r, i = null) => {
		let { el: a, type: c, transition: l, children: u, shapeFlag: d } = e;
		if (d & 6) {
			he(e.component.subTree, t, n, r);
			return;
		}
		if (d & 128) {
			e.suspense.move(t, n, r);
			return;
		}
		if (d & 64) {
			c.move(e, t, n, Ce);
			return;
		}
		if (c === V) {
			o(a, t, n);
			for (let e = 0; e < u.length; e++) he(u[e], t, n, r);
			o(e.anchor, t, n);
			return;
		}
		if (c === Zi) {
			S(e, t, n);
			return;
		}
		if (r !== 2 && d & 1 && l) if (r === 0) l.persisted && !a[Qn] ? o(a, t, n) : (l.beforeEnter(a), o(a, t, n), B(() => l.enter(a), i));
		else {
			let { leave: r, delayLeave: i, afterLeave: c } = l, u = () => {
				e.ctx.isUnmounted ? s(a) : o(a, t, n);
			}, d = () => {
				let e = a._isLeaving || !!a[Qn];
				a._isLeaving && a[Qn](!0), l.persisted && !e ? u() : r(a, () => {
					u(), c && c();
				});
			};
			i ? i(a, u, d) : d();
		}
		else o(a, t, n);
	}, ge = (e, t, n, r = !1, i = !1) => {
		let { type: a, props: o, ref: s, children: c, dynamicChildren: l, shapeFlag: u, patchFlag: d, dirs: f, cacheIndex: p, memo: m } = e;
		if (d === -2 && (i = !1), s != null && (We(), _r(s, null, n, e, !0), Ge()), p != null && (t.renderCache[p] = void 0), u & 256) {
			t.ctx.deactivate(e);
			return;
		}
		let h = u & 1 && f, g = !yr(e), _;
		if (g && (_ = o && o.onVnodeBeforeUnmount) && va(_, t, e), u & 6) ve(e.component, n, r);
		else {
			if (u & 128) {
				e.suspense.unmount(n, r);
				return;
			}
			h && kn(e, null, t, "beforeUnmount"), u & 64 ? e.type.remove(e, t, n, Ce, r) : l && !l.hasOnce && (a !== V || d > 0 && d & 64) ? ye(l, t, n, !1, !0) : (a === V && d & 384 || !i && u & 16) && ye(c, t, n), r && O(e);
		}
		let v = m != null && p == null;
		(g && (_ = o && o.onVnodeUnmounted) || h || v) && B(() => {
			_ && va(_, t, e), h && kn(e, null, t, "unmounted"), v && (e.el = null);
		}, n);
	}, O = (e) => {
		let { type: t, el: n, anchor: r, transition: i } = e;
		if (t === V) {
			_e(n, r);
			return;
		}
		if (t === Zi) {
			C(e);
			return;
		}
		let a = () => {
			s(n), i && !i.persisted && i.afterLeave && i.afterLeave();
		};
		if (e.shapeFlag & 1 && i && !i.persisted) {
			let { leave: t, delayLeave: r } = i, o = () => t(n, a);
			r ? r(e.el, a, o) : o();
		} else a();
	}, _e = (e, t) => {
		let n;
		for (; e !== t;) n = h(e), s(e), e = n;
		s(t);
	}, ve = (e, t, n) => {
		let { bum: r, scope: i, job: a, subTree: o, um: s, m: c, a: l } = e;
		Gi(c), Gi(l), r && se(r), i.stop(), a && (a.flags |= 8, ge(o, e, t, n)), s && B(s, t), B(() => {
			e.isUnmounted = !0;
		}, t);
	}, ye = (e, t, n, r = !1, i = !1, a = 0) => {
		for (let o = a; o < e.length; o++) ge(e[o], t, n, r, i);
	}, be = (e) => {
		if (e.shapeFlag & 6) return be(e.component.subTree);
		if (e.shapeFlag & 128) return e.suspense.next();
		let t = h(e.anchor || e.el), n = t && t[zn];
		return n ? h(n) : t;
	}, xe = !1, Se = (e, t, n) => {
		let r;
		e == null ? t._vnode && (ge(t._vnode, null, null, !0), r = t._vnode.component) : v(t._vnode || null, e, t, null, null, null, n), t._vnode = e, xe ||= (xe = !0, xn(r), Sn(), !1);
	}, Ce = {
		p: v,
		um: ge,
		m: he,
		r: O,
		mt: D,
		mc: T,
		pc: fe,
		pbc: E,
		n: be,
		o: e
	}, k, we;
	return i && ([k, we] = i(Ce)), {
		render: Se,
		hydrate: k,
		createApp: ai(Se, k)
	};
}
function zi({ type: e, props: t }, n) {
	return n === "svg" && e === "foreignObject" || n === "mathml" && e === "annotation-xml" && t && t.encoding && t.encoding.includes("html") ? void 0 : n;
}
function Bi({ effect: e, job: t }, n) {
	n ? (e.flags |= 32, t.flags |= 4) : (e.flags &= -33, t.flags &= -5);
}
function Vi(e, t) {
	return (!e || e && !e.pendingBranch) && t && !t.persisted;
}
function Hi(e, t, n = !1) {
	let r = e.children, i = t.children;
	if (d(r) && d(i)) for (let e = 0; e < r.length; e++) {
		let t = r[e], a = i[e];
		a.shapeFlag & 1 && !a.dynamicChildren && ((a.patchFlag <= 0 || a.patchFlag === 32) && (a = i[e] = ha(i[e]), a.el = t.el), !n && a.patchFlag !== -2 && Hi(t, a)), a.type === Yi && (a.patchFlag === -1 && (a = i[e] = ha(a)), a.el = t.el), a.type === Xi && !a.el && (a.el = t.el);
	}
}
function Ui(e) {
	let t = e.slice(), n = [0], r, i, a, o, s, c = e.length;
	for (r = 0; r < c; r++) {
		let c = e[r];
		if (c !== 0) {
			if (i = n[n.length - 1], e[i] < c) {
				t[r] = i, n.push(r);
				continue;
			}
			for (a = 0, o = n.length - 1; a < o;) s = a + o >> 1, e[n[s]] < c ? a = s + 1 : o = s;
			c < e[n[a]] && (a > 0 && (t[r] = n[a - 1]), n[a] = r);
		}
	}
	for (a = n.length, o = n[a - 1]; a-- > 0;) n[a] = o, o = t[o];
	return n;
}
function Wi(e) {
	let t = e.subTree.component;
	if (t) return t.asyncDep && !t.asyncResolved ? t : Wi(t);
}
function Gi(e) {
	if (e) for (let t = 0; t < e.length; t++) e[t].flags |= 8;
}
function Ki(e) {
	if (e.placeholder) return e.placeholder;
	let t = e.component;
	return t ? Ki(t.subTree) : null;
}
var qi = (e) => e.__isSuspense;
function Ji(e, t) {
	t && t.pendingBranch ? d(e) ? t.effects.push(...e) : t.effects.push(e) : bn(e);
}
var V = /* @__PURE__ */ Symbol.for("v-fgt"), Yi = /* @__PURE__ */ Symbol.for("v-txt"), Xi = /* @__PURE__ */ Symbol.for("v-cmt"), Zi = /* @__PURE__ */ Symbol.for("v-stc"), Qi = [], $i = null;
function H(e = !1) {
	Qi.push($i = e ? null : []);
}
function ea() {
	Qi.pop(), $i = Qi[Qi.length - 1] || null;
}
var ta = 1;
function na(e, t = !1) {
	ta += e, e < 0 && $i && t && ($i.hasOnce = !0);
}
function ra(e) {
	return e.dynamicChildren = ta > 0 ? $i || n : null, ea(), ta > 0 && $i && $i.push(e), e;
}
function U(e, t, n, r, i, a) {
	return ra(W(e, t, n, r, i, a, !0));
}
function ia(e, t, n, r, i) {
	return ra(G(e, t, n, r, i, !0));
}
function aa(e) {
	return e ? e.__v_isVNode === !0 : !1;
}
function oa(e, t) {
	return e.type === t.type && e.key === t.key;
}
var sa = ({ key: e }) => e ?? null, ca = ({ ref: e, ref_key: t, ref_for: n }) => (typeof e == "number" && (e = "" + e), e == null ? null : g(e) || /* @__PURE__ */ P(e) || h(e) ? {
	i: Tn,
	r: e,
	k: t,
	f: !!n
} : e);
function W(e, t = null, n = null, r = 0, i = null, a = e === V ? 0 : 1, o = !1, s = !1) {
	let c = {
		__v_isVNode: !0,
		__v_skip: !0,
		type: e,
		props: t,
		key: t && sa(t),
		ref: t && ca(t),
		scopeId: En,
		slotScopeIds: null,
		children: n,
		component: null,
		suspense: null,
		ssContent: null,
		ssFallback: null,
		dirs: null,
		transition: null,
		el: null,
		anchor: null,
		target: null,
		targetStart: null,
		targetAnchor: null,
		staticCount: 0,
		shapeFlag: a,
		patchFlag: r,
		dynamicProps: i,
		dynamicChildren: null,
		appContext: null,
		ctx: Tn
	};
	return s ? (ga(c, n), a & 128 && e.normalize(c)) : n && (c.shapeFlag |= g(n) ? 8 : 16), ta > 0 && !o && $i && (c.patchFlag > 0 || a & 6) && c.patchFlag !== 32 && $i.push(c), c;
}
var G = la;
function la(e, t = null, n = null, r = 0, i = null, a = !1) {
	if ((!e || e === Lr) && (e = Xi), aa(e)) {
		let r = da(e, t, !0);
		return n && ga(r, n), ta > 0 && !a && $i && (r.shapeFlag & 6 ? $i[$i.indexOf(e)] = r : $i.push(r)), r.patchFlag = -2, r;
	}
	if (Ra(e) && (e = e.__vccOpts), t) {
		t = ua(t);
		let { class: e, style: n } = t;
		e && !g(e) && (t.class = O(e)), v(n) && (/* @__PURE__ */ Ht(n) && !d(n) && (n = s({}, n)), t.style = fe(n));
	}
	let o = g(e) ? 1 : qi(e) ? 128 : Bn(e) ? 64 : v(e) ? 4 : h(e) ? 2 : 0;
	return W(e, t, n, r, i, o, a, !0);
}
function ua(e) {
	return e ? /* @__PURE__ */ Ht(e) || xi(e) ? s({}, e) : e : null;
}
function da(e, t, n = !1, r = !1) {
	let { props: i, ref: a, patchFlag: o, children: s, transition: c } = e, l = t ? _a(i || {}, t) : i, u = {
		__v_isVNode: !0,
		__v_skip: !0,
		type: e.type,
		props: l,
		key: l && sa(l),
		ref: t && t.ref ? n && a ? d(a) ? a.concat(ca(t)) : [a, ca(t)] : ca(t) : a,
		scopeId: e.scopeId,
		slotScopeIds: e.slotScopeIds,
		children: s,
		target: e.target,
		targetStart: e.targetStart,
		targetAnchor: e.targetAnchor,
		staticCount: e.staticCount,
		shapeFlag: e.shapeFlag,
		patchFlag: t && e.type !== V ? o === -1 ? 16 : o | 16 : o,
		dynamicProps: e.dynamicProps,
		dynamicChildren: e.dynamicChildren,
		appContext: e.appContext,
		dirs: e.dirs,
		transition: c,
		component: e.component,
		suspense: e.suspense,
		ssContent: e.ssContent && da(e.ssContent),
		ssFallback: e.ssFallback && da(e.ssFallback),
		placeholder: e.placeholder,
		el: e.el,
		anchor: e.anchor,
		ctx: e.ctx,
		ce: e.ce
	};
	return c && r && dr(u, c.clone(u)), u;
}
function fa(e = " ", t = 0) {
	return G(Yi, null, e, t);
}
function pa(e, t) {
	let n = G(Zi, null, e);
	return n.staticCount = t, n;
}
function K(e = "", t = !1) {
	return t ? (H(), ia(Xi, null, e)) : G(Xi, null, e);
}
function ma(e) {
	return e == null || typeof e == "boolean" ? G(Xi) : d(e) ? G(V, null, e.slice()) : aa(e) ? ha(e) : G(Yi, null, String(e));
}
function ha(e) {
	return e.el === null && e.patchFlag !== -1 || e.memo ? e : da(e);
}
function ga(e, t) {
	let n = 0, { shapeFlag: r } = e;
	if (t == null) t = null;
	else if (d(t)) n = 16;
	else if (typeof t == "object") if (r & 65) {
		let n = t.default;
		n && (n._c && (n._d = !1), ga(e, n()), n._c && (n._d = !0));
		return;
	} else {
		n = 32;
		let r = t._;
		!r && !xi(t) ? t._ctx = Tn : r === 3 && Tn && (Tn.slots._ === 1 ? t._ = 1 : (t._ = 2, e.patchFlag |= 1024));
	}
	else if (h(t)) {
		if (r & 65) {
			ga(e, { default: t });
			return;
		}
		t = {
			default: t,
			_ctx: Tn
		}, n = 32;
	} else t = String(t), r & 64 ? (n = 16, t = [fa(t)]) : n = 8;
	e.children = t, e.shapeFlag |= n;
}
function _a(...e) {
	let t = {};
	for (let n = 0; n < e.length; n++) {
		let r = e[n];
		for (let e in r) if (e === "class") t.class !== r.class && (t.class = O([t.class, r.class]));
		else if (e === "style") t.style = fe([t.style, r.style]);
		else if (a(e)) {
			let n = t[e], i = r[e];
			i && n !== i && !(d(n) && n.includes(i)) ? t[e] = n ? [].concat(n, i) : i : i == null && n == null && !o(e) && (t[e] = i);
		} else e !== "" && (t[e] = r[e]);
	}
	return t;
}
function va(e, t, n, r = null) {
	sn(e, t, 7, [n, r]);
}
var ya = ri(), ba = 0;
function xa(e, n, r) {
	let i = e.type, a = (n ? n.appContext : e.appContext) || ya, o = {
		uid: ba++,
		vnode: e,
		type: i,
		parent: n,
		appContext: a,
		root: null,
		next: null,
		subTree: null,
		effect: null,
		update: null,
		job: null,
		scope: new Ee(!0),
		render: null,
		proxy: null,
		exposed: null,
		exposeProxy: null,
		withProxy: null,
		provides: n ? n.provides : Object.create(a.provides),
		ids: n ? n.ids : [
			"",
			0,
			0
		],
		accessCache: null,
		renderCache: [],
		components: null,
		directives: null,
		propsOptions: Di(i, a),
		emitsOptions: ui(i, a),
		emit: null,
		emitted: null,
		propsDefaults: t,
		inheritAttrs: i.inheritAttrs,
		ctx: t,
		data: t,
		props: t,
		attrs: t,
		slots: t,
		refs: t,
		setupState: t,
		setupContext: null,
		suspense: r,
		suspenseId: r ? r.pendingId : 0,
		asyncDep: null,
		asyncResolved: !1,
		isMounted: !1,
		isUnmounted: !1,
		isDeactivated: !1,
		bc: null,
		c: null,
		bm: null,
		m: null,
		bu: null,
		u: null,
		um: null,
		bum: null,
		da: null,
		a: null,
		rtg: null,
		rtc: null,
		ec: null,
		sp: null
	};
	return o.ctx = { _: o }, o.root = n ? n.root : o, o.emit = ci.bind(null, o), e.ce && e.ce(o), o;
}
var q = null, Sa = () => q || Tn, Ca, wa;
{
	let e = de(), t = (t, n) => {
		let r;
		return (r = e[t]) || (r = e[t] = []), r.push(n), (e) => {
			r.length > 1 ? r.forEach((t) => t(e)) : r[0](e);
		};
	};
	Ca = t("__VUE_INSTANCE_SETTERS__", (e) => q = e), wa = t("__VUE_SSR_SETTERS__", (e) => Oa = e);
}
var Ta = (e) => {
	let t = q;
	return Ca(e), e.scope.on(), () => {
		e.scope.off(), Ca(t);
	};
}, Ea = () => {
	q && q.scope.off(), Ca(null);
};
function Da(e) {
	return e.vnode.shapeFlag & 4;
}
var Oa = !1;
function ka(e, t = !1, n = !1) {
	t && wa(t);
	let { props: r, children: i } = e.vnode, a = Da(e);
	Si(e, r, a, t), Fi(e, i, n || t);
	let o = a ? Aa(e, t) : void 0;
	return t && wa(!1), o;
}
function Aa(e, t) {
	let n = e.type;
	e.accessCache = /* @__PURE__ */ Object.create(null), e.proxy = new Proxy(e.ctx, Vr);
	let { setup: r } = n;
	if (r) {
		We();
		let n = e.setupContext = r.length > 1 ? Ia(e) : null, i = Ta(e), a = on(r, e, 0, [e.props, n]), o = y(a);
		if (Ge(), i(), (o || e.sp) && !yr(e) && mr(e), o) {
			if (a.then(Ea, Ea), t) return a.then((n) => {
				ja(e, n, t);
			}).catch((t) => {
				cn(t, e, 0);
			});
			e.asyncDep = a;
		} else ja(e, a, t);
	} else Pa(e, t);
}
function ja(e, t, n) {
	h(t) ? e.type.__ssrInlineRender ? e.ssrRender = t : e.render = t : v(t) && (e.setupState = Xt(t)), Pa(e, n);
}
var Ma, Na;
function Pa(e, t, n) {
	let i = e.type;
	if (!e.render) {
		if (!t && Ma && !i.render) {
			let t = i.template || Jr(e).template;
			if (t) {
				let { isCustomElement: n, compilerOptions: r } = e.appContext.config, { delimiters: a, compilerOptions: o } = i;
				i.render = Ma(t, s(s({
					isCustomElement: n,
					delimiters: a
				}, r), o));
			}
		}
		e.render = i.render || r, Na && Na(e);
	}
	{
		let t = Ta(e);
		We();
		try {
			Wr(e);
		} finally {
			Ge(), t();
		}
	}
}
var Fa = { get(e, t) {
	return M(e, "get", ""), e[t];
} };
function Ia(e) {
	return {
		attrs: new Proxy(e.attrs, Fa),
		slots: e.slots,
		emit: e.emit,
		expose: (t) => {
			e.exposed = t || {};
		}
	};
}
function La(e) {
	return e.exposed ? e.exposeProxy ||= new Proxy(Xt(Ut(e.exposed)), {
		get(t, n) {
			if (n in t) return t[n];
			if (n in zr) return zr[n](e);
		},
		has(e, t) {
			return t in e || t in zr;
		}
	}) : e.proxy;
}
function Ra(e) {
	return h(e) && "__vccOpts" in e;
}
var J = (e, t) => /* @__PURE__ */ Qt(e, t, Oa);
function za(e, t, n) {
	try {
		na(-1);
		let r = arguments.length;
		return r === 2 ? v(t) && !d(t) ? aa(t) ? G(e, null, [t]) : G(e, t) : G(e, null, t) : (r > 3 ? n = Array.prototype.slice.call(arguments, 2) : r === 3 && aa(n) && (n = [n]), G(e, t, n));
	} finally {
		na(1);
	}
}
var Ba = "3.5.40", Va = void 0, Ha = typeof window < "u" && window.trustedTypes;
if (Ha) try {
	Va = /* @__PURE__ */ Ha.createPolicy("vue", { createHTML: (e) => e });
} catch {}
var Ua = Va ? (e) => Va.createHTML(e) : (e) => e, Wa = "http://www.w3.org/2000/svg", Ga = "http://www.w3.org/1998/Math/MathML", Ka = typeof document < "u" ? document : null, qa = Ka && /* @__PURE__ */ Ka.createElement("template"), Ja = {
	insert: (e, t, n) => {
		t.insertBefore(e, n || null);
	},
	remove: (e) => {
		let t = e.parentNode;
		t && t.removeChild(e);
	},
	createElement: (e, t, n, r) => {
		let i = t === "svg" ? Ka.createElementNS(Wa, e) : t === "mathml" ? Ka.createElementNS(Ga, e) : n ? Ka.createElement(e, { is: n }) : Ka.createElement(e);
		return e === "select" && r && r.multiple != null && i.setAttribute("multiple", r.multiple), i;
	},
	createText: (e) => Ka.createTextNode(e),
	createComment: (e) => Ka.createComment(e),
	setText: (e, t) => {
		e.nodeValue = t;
	},
	setElementText: (e, t) => {
		e.textContent = t;
	},
	parentNode: (e) => e.parentNode,
	nextSibling: (e) => e.nextSibling,
	querySelector: (e) => Ka.querySelector(e),
	setScopeId(e, t) {
		e.setAttribute(t, "");
	},
	insertStaticContent(e, t, n, r, i, a) {
		let o = n ? n.previousSibling : t.lastChild;
		if (i && (i === a || i.nextSibling)) for (; t.insertBefore(i.cloneNode(!0), n), !(i === a || !(i = i.nextSibling)););
		else {
			qa.innerHTML = Ua(r === "svg" ? `<svg>${e}</svg>` : r === "mathml" ? `<math>${e}</math>` : e);
			let i = qa.content;
			if (r === "svg" || r === "mathml") {
				let e = i.firstChild;
				for (; e.firstChild;) i.appendChild(e.firstChild);
				i.removeChild(e);
			}
			t.insertBefore(i, n);
		}
		return [o ? o.nextSibling : t.firstChild, n ? n.previousSibling : t.lastChild];
	}
}, Ya = "transition", Xa = "animation", Za = /* @__PURE__ */ Symbol("_vtc"), Qa = {
	name: String,
	type: String,
	css: {
		type: Boolean,
		default: !0
	},
	duration: [
		String,
		Number,
		Object
	],
	enterFromClass: String,
	enterActiveClass: String,
	enterToClass: String,
	appearFromClass: String,
	appearActiveClass: String,
	appearToClass: String,
	leaveFromClass: String,
	leaveActiveClass: String,
	leaveToClass: String
}, $a = /* @__PURE__ */ s({}, nr, Qa), eo = /* @__PURE__ */ ((e) => (e.displayName = "Transition", e.props = $a, e))((e, { slots: t }) => za(or, ro(e), t)), to = (e, t = []) => {
	d(e) ? e.forEach((e) => e(...t)) : e && e(...t);
}, no = (e) => e ? d(e) ? e.some((e) => e.length > 1) : e.length > 1 : !1;
function ro(e) {
	let t = {};
	for (let n in e) n in Qa || (t[n] = e[n]);
	if (e.css === !1) return t;
	let { name: n = "v", type: r, duration: i, enterFromClass: a = `${n}-enter-from`, enterActiveClass: o = `${n}-enter-active`, enterToClass: c = `${n}-enter-to`, appearFromClass: l = a, appearActiveClass: u = o, appearToClass: d = c, leaveFromClass: f = `${n}-leave-from`, leaveActiveClass: p = `${n}-leave-active`, leaveToClass: m = `${n}-leave-to` } = e, h = io(i), g = h && h[0], _ = h && h[1], { onBeforeEnter: v, onEnter: y, onEnterCancelled: b, onLeave: x, onLeaveCancelled: S, onBeforeAppear: C = v, onAppear: w = y, onAppearCancelled: ee = b } = t, te = (e, t, n, r) => {
		e._enterCancelled = r, so(e, t ? d : c), so(e, t ? u : o), n && n();
	}, ne = (e, t) => {
		e._isLeaving = !1, so(e, f), so(e, m), so(e, p), t && t();
	}, T = (e) => (t, n) => {
		let i = e ? w : y, o = () => te(t, e, n);
		to(i, [t, o]), co(() => {
			so(t, e ? l : a), oo(t, e ? d : c), no(i) || uo(t, r, g, o);
		});
	};
	return s(t, {
		onBeforeEnter(e) {
			to(v, [e]), oo(e, a), oo(e, o);
		},
		onBeforeAppear(e) {
			to(C, [e]), oo(e, l), oo(e, u);
		},
		onEnter: T(!1),
		onAppear: T(!0),
		onLeave(e, t) {
			e._isLeaving = !0;
			let n = () => ne(e, t);
			oo(e, f), e._enterCancelled ? (oo(e, p), ho(e)) : (ho(e), oo(e, p)), co(() => {
				e._isLeaving && (so(e, f), oo(e, m), no(x) || uo(e, r, _, n));
			}), to(x, [e, n]);
		},
		onEnterCancelled(e) {
			te(e, !1, void 0, !0), to(b, [e]);
		},
		onAppearCancelled(e) {
			te(e, !0, void 0, !0), to(ee, [e]);
		},
		onLeaveCancelled(e) {
			ne(e), to(S, [e]);
		}
	});
}
function io(e) {
	if (e == null) return null;
	if (v(e)) return [ao(e.enter), ao(e.leave)];
	{
		let t = ao(e);
		return [t, t];
	}
}
function ao(e) {
	return le(e);
}
function oo(e, t) {
	t.split(/\s+/).forEach((t) => t && e.classList.add(t)), (e[Za] || (e[Za] = /* @__PURE__ */ new Set())).add(t);
}
function so(e, t) {
	t.split(/\s+/).forEach((t) => t && e.classList.remove(t));
	let n = e[Za];
	n && (n.delete(t), n.size || (e[Za] = void 0));
}
function co(e) {
	requestAnimationFrame(() => {
		requestAnimationFrame(e);
	});
}
var lo = 0;
function uo(e, t, n, r) {
	let i = e._endId = ++lo, a = () => {
		i === e._endId && r();
	};
	if (n != null) return setTimeout(a, n);
	let { type: o, timeout: s, propCount: c } = fo(e, t);
	if (!o) return r();
	let l = o + "end", u = 0, d = () => {
		e.removeEventListener(l, f), a();
	}, f = (t) => {
		t.target === e && ++u >= c && d();
	};
	setTimeout(() => {
		u < c && d();
	}, s + 1), e.addEventListener(l, f);
}
function fo(e, t) {
	let n = window.getComputedStyle(e), r = (e) => (n[e] || "").split(", "), i = r(`${Ya}Delay`), a = r(`${Ya}Duration`), o = po(i, a), s = r(`${Xa}Delay`), c = r(`${Xa}Duration`), l = po(s, c), u = null, d = 0, f = 0;
	t === Ya ? o > 0 && (u = Ya, d = o, f = a.length) : t === Xa ? l > 0 && (u = Xa, d = l, f = c.length) : (d = Math.max(o, l), u = d > 0 ? o > l ? Ya : Xa : null, f = u ? u === Ya ? a.length : c.length : 0);
	let p = u === Ya && /\b(?:transform|all)(?:,|$)/.test(r(`${Ya}Property`).toString());
	return {
		type: u,
		timeout: d,
		propCount: f,
		hasTransform: p
	};
}
function po(e, t) {
	for (; e.length < t.length;) e = e.concat(e);
	return Math.max(...t.map((t, n) => mo(t) + mo(e[n])));
}
function mo(e) {
	return e === "auto" ? 0 : Number(e.slice(0, -1).replace(",", ".")) * 1e3;
}
function ho(e) {
	return (e ? e.ownerDocument : document).body.offsetHeight;
}
function go(e, t, n) {
	let r = e[Za];
	r && (t = (t ? [t, ...r] : [...r]).join(" ")), t == null ? e.removeAttribute("class") : n ? e.setAttribute("class", t) : e.className = t;
}
var _o = /* @__PURE__ */ Symbol("_vod"), vo = /* @__PURE__ */ Symbol("_vsh"), yo = /* @__PURE__ */ Symbol(""), bo = /(?:^|;)\s*display\s*:/;
function xo(e, t, n) {
	let r = e.style, i = g(n), a = !1;
	if (n && !i) {
		if (t) if (g(t)) for (let e of t.split(";")) {
			let t = e.slice(0, e.indexOf(":")).trim();
			n[t] ?? Co(r, t, "");
		}
		else for (let e in t) n[e] ?? Co(r, e, "");
		for (let i in n) {
			i === "display" && (a = !0);
			let o = n[i];
			o == null ? Co(r, i, "") : Do(e, i, !g(t) && t ? t[i] : void 0, o) || Co(r, i, o);
		}
	} else if (i) {
		if (t !== n) {
			let e = r[yo];
			e && (n += ";" + e), r.cssText = n, a = bo.test(n);
		}
	} else t && e.removeAttribute("style");
	_o in e && (e[_o] = a ? r.display : "", e[vo] && (r.display = "none"));
}
var So = /\s*!important$/;
function Co(e, t, n) {
	if (d(n)) n.forEach((n) => Co(e, t, n));
	else if (n ??= "", t.startsWith("--")) e.setProperty(t, n);
	else {
		let r = Eo(e, t);
		So.test(n) ? e.setProperty(E(r), n.replace(So, ""), "important") : e[r] = n;
	}
}
var wo = [
	"Webkit",
	"Moz",
	"ms"
], To = {};
function Eo(e, t) {
	let n = To[t];
	if (n) return n;
	let r = T(t);
	if (r !== "filter" && r in e) return To[t] = r;
	r = ie(r);
	for (let n = 0; n < wo.length; n++) {
		let i = wo[n] + r;
		if (i in e) return To[t] = i;
	}
	return t;
}
function Do(e, t, n, r) {
	return e.tagName === "TEXTAREA" && (t === "width" || t === "height") && g(r) && n === r;
}
var Oo = "http://www.w3.org/1999/xlink";
function ko(e, t, n, r, i, a = ve(t)) {
	r && t.startsWith("xlink:") ? n == null ? e.removeAttributeNS(Oo, t.slice(6, t.length)) : e.setAttributeNS(Oo, t, n) : n == null || a && !ye(n) ? e.removeAttribute(t) : e.setAttribute(t, a ? "" : _(n) ? String(n) : n);
}
function Ao(e, t, n, r, i) {
	if (t === "innerHTML" || t === "textContent") {
		n != null && (e[t] = t === "innerHTML" ? Ua(n) : n);
		return;
	}
	let a = e.tagName;
	if (t === "value" && a !== "PROGRESS" && !a.includes("-")) {
		let r = a === "OPTION" ? e.getAttribute("value") || "" : e.value, i = n == null ? e.type === "checkbox" ? "on" : "" : String(n);
		(r !== i || !("_value" in e)) && (e.value = i), n ?? e.removeAttribute(t), e._value = n;
		return;
	}
	let o = !1;
	if (n === "" || n == null) {
		let r = typeof e[t];
		r === "boolean" ? n = ye(n) : n == null && r === "string" ? (n = "", o = !0) : r === "number" && (n = 0, o = !0);
	}
	try {
		e[t] = n;
	} catch {}
	o && e.removeAttribute(i || t);
}
function jo(e, t, n, r) {
	e.addEventListener(t, n, r);
}
function Mo(e, t, n, r) {
	e.removeEventListener(t, n, r);
}
var No = /* @__PURE__ */ Symbol("_vei");
function Po(e, t, n, r, i = null) {
	let a = e[No] || (e[No] = {}), o = a[t];
	if (r && o) o.value = r;
	else {
		let [n, s] = Lo(t);
		r ? jo(e, n, a[t] = Vo(r, i), s) : o && (Mo(e, n, o, s), a[t] = void 0);
	}
}
var Fo = /(Once|Passive|Capture)$/, Io = /^on:?(?:Once|Passive|Capture)$/;
function Lo(e) {
	let t, n;
	for (; (n = e.match(Fo)) && !Io.test(e);) t ||= {}, e = e.slice(0, e.length - n[1].length), t[n[1].toLowerCase()] = !0;
	return [e[2] === ":" ? e.slice(3) : E(e.slice(2)), t];
}
var Ro = 0, zo = /* @__PURE__ */ Promise.resolve(), Bo = () => Ro ||= (zo.then(() => Ro = 0), Date.now());
function Vo(e, t) {
	let n = (e) => {
		if (!e._vts) e._vts = Date.now();
		else if (e._vts <= n.attached) return;
		let r = n.value;
		if (d(r)) {
			let n = e.stopImmediatePropagation;
			e.stopImmediatePropagation = () => {
				n.call(e), e._stopped = !0;
			};
			let i = r.slice(), a = [e];
			for (let n = 0; n < i.length && !e._stopped; n++) {
				let e = i[n];
				e && sn(e, t, 5, a);
			}
		} else sn(r, t, 5, [e]);
	};
	return n.value = e, n.attached = Bo(), n;
}
var Ho = (e) => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && e.charCodeAt(2) > 96 && e.charCodeAt(2) < 123, Uo = (e, t, n, r, i, s) => {
	let c = i === "svg";
	t === "class" ? go(e, r, c) : t === "style" ? xo(e, n, r) : a(t) ? o(t) || Po(e, t, n, r, s) : (t[0] === "." ? (t = t.slice(1), !0) : t[0] === "^" ? (t = t.slice(1), !1) : Wo(e, t, r, c)) ? (Ao(e, t, r), !e.tagName.includes("-") && (t === "value" || t === "checked" || t === "selected") && ko(e, t, r, c, s, t !== "value")) : e._isVueCE && (Go(e, t) || e._def.__asyncLoader && (/[A-Z]/.test(t) || !g(r))) ? Ao(e, T(t), r, s, t) : (t === "true-value" ? e._trueValue = r : t === "false-value" && (e._falseValue = r), ko(e, t, r, c));
};
function Wo(e, t, n, r) {
	if (r) return !!(t === "innerHTML" || t === "textContent" || t in e && Ho(t) && h(n));
	if (t === "spellcheck" || t === "draggable" || t === "translate" || t === "autocorrect" || t === "sandbox" && e.tagName === "IFRAME" || t === "form" || t === "list" && e.tagName === "INPUT" || t === "type" && e.tagName === "TEXTAREA") return !1;
	if (t === "width" || t === "height") {
		let t = e.tagName;
		if (t === "IMG" || t === "VIDEO" || t === "CANVAS" || t === "SOURCE") return !1;
	}
	return Ho(t) && g(n) ? !1 : t in e;
}
function Go(e, t) {
	let n = e._def.props;
	if (!n) return !1;
	let r = T(t);
	return Array.isArray(n) ? n.some((e) => T(e) === r) : Object.keys(n).some((e) => T(e) === r);
}
var Ko = (e) => {
	let t = e.props["onUpdate:modelValue"] || !1;
	return d(t) ? (e) => se(t, e) : t;
};
function qo(e) {
	e.target.composing = !0;
}
function Jo(e) {
	let t = e.target;
	t.composing && (t.composing = !1, t.dispatchEvent(new Event("input")));
}
var Yo = /* @__PURE__ */ Symbol("_assign");
function Xo(e, t, n) {
	return t && (e = e.trim()), n && (e = ce(e)), e;
}
var Zo = {
	created(e, { modifiers: { lazy: t, trim: n, number: r } }, i) {
		e[Yo] = Ko(i);
		let a = r || i.props && i.props.type === "number";
		jo(e, t ? "change" : "input", (t) => {
			t.target.composing || e[Yo](Xo(e.value, n, a));
		}), (n || a) && jo(e, "change", () => {
			e.value = Xo(e.value, n, a);
		}), t || (jo(e, "compositionstart", qo), jo(e, "compositionend", Jo), jo(e, "change", Jo));
	},
	mounted(e, { value: t }) {
		e.value = t ?? "";
	},
	beforeUpdate(e, { value: t, oldValue: n, modifiers: { lazy: r, trim: i, number: a } }, o) {
		if (e[Yo] = Ko(o), e.composing) return;
		let s = (a || e.type === "number") && !/^0\d/.test(e.value) ? ce(e.value) : e.value, c = t ?? "";
		if (s === c) return;
		let l = e.getRootNode();
		(l instanceof Document || l instanceof ShadowRoot) && l.activeElement === e && e.type !== "range" && (r && t === n || i && e.value.trim() === c) || (e.value = c);
	}
}, Qo = {
	deep: !0,
	created(e, t, n) {
		e[Yo] = Ko(n), jo(e, "change", () => {
			let t = e._modelValue, n = ns(e), r = e.checked, i = e[Yo];
			if (d(t)) {
				let e = Se(t, n), a = e !== -1;
				if (r && !a) i(t.concat(n));
				else if (!r && a) {
					let n = [...t];
					n.splice(e, 1), i(n);
				}
			} else if (p(t)) {
				let e = new Set(t);
				r ? e.add(n) : e.delete(n), i(e);
			} else i(rs(e, r));
		});
	},
	mounted: $o,
	beforeUpdate(e, t, n) {
		e[Yo] = Ko(n), $o(e, t, n);
	}
};
function $o(e, { value: t, oldValue: n }, r) {
	e._modelValue = t;
	let i;
	if (d(t)) i = Se(t, r.props.value) > -1;
	else if (p(t)) i = t.has(r.props.value);
	else {
		if (t === n) return;
		i = xe(t, rs(e, !0));
	}
	e.checked !== i && (e.checked = i);
}
var es = {
	deep: !0,
	created(e, { value: t, modifiers: { number: n } }, r) {
		e._modelValue = t, jo(e, "change", () => {
			let t = Array.prototype.filter.call(e.options, (e) => e.selected).map((e) => n ? ce(ns(e)) : ns(e));
			e[Yo](e.multiple ? p(e._modelValue) ? new Set(t) : t : t[0]), e._assigning = !0, gn(() => {
				e._assigning = !1;
			});
		}), e[Yo] = Ko(r);
	},
	mounted(e, { value: t }) {
		ts(e, t);
	},
	beforeUpdate(e, { value: t }, n) {
		e._modelValue = t, e[Yo] = Ko(n);
	},
	updated(e, { value: t }) {
		e._assigning || ts(e, t);
	}
};
function ts(e, t) {
	let n = e.multiple, r = d(t);
	if (!(n && !r && !p(t))) {
		for (let i = 0, a = e.options.length; i < a; i++) {
			let a = e.options[i], o = ns(a);
			if (n) if (r) {
				let e = typeof o;
				a.selected = e === "string" || e === "number" ? t.some((e) => String(e) === String(o)) : Se(t, o) > -1;
			} else a.selected = t.has(o);
			else if (xe(ns(a), t)) {
				e.selectedIndex !== i && (e.selectedIndex = i);
				return;
			}
		}
		!n && e.selectedIndex !== -1 && (e.selectedIndex = -1);
	}
}
function ns(e) {
	return "_value" in e ? e._value : e.value;
}
function rs(e, t) {
	let n = t ? "_trueValue" : "_falseValue";
	return n in e ? e[n] : t;
}
var is = [
	"ctrl",
	"shift",
	"alt",
	"meta"
], as = {
	stop: (e) => e.stopPropagation(),
	prevent: (e) => e.preventDefault(),
	self: (e) => e.target !== e.currentTarget,
	ctrl: (e) => !e.ctrlKey,
	shift: (e) => !e.shiftKey,
	alt: (e) => !e.altKey,
	meta: (e) => !e.metaKey,
	left: (e) => "button" in e && e.button !== 0,
	middle: (e) => "button" in e && e.button !== 1,
	right: (e) => "button" in e && e.button !== 2,
	exact: (e, t) => is.some((n) => e[`${n}Key`] && !t.includes(n))
}, os = (e, t) => {
	if (!e) return e;
	let n = e._withMods ||= {}, r = t.join(".");
	return n[r] || (n[r] = ((n, ...r) => {
		for (let e = 0; e < t.length; e++) {
			let r = as[t[e]];
			if (r && r(n, t)) return;
		}
		return e(n, ...r);
	}));
}, ss = {
	esc: "escape",
	space: " ",
	up: "arrow-up",
	left: "arrow-left",
	right: "arrow-right",
	down: "arrow-down",
	delete: "backspace"
}, cs = (e, t) => {
	let n = e._withKeys ||= {}, r = t.join(".");
	return n[r] || (n[r] = ((n) => {
		if (!("key" in n)) return;
		let r = E(n.key);
		if (t.some((e) => e === r || ss[e] === r)) return e(n);
	}));
}, ls = /* @__PURE__ */ s({ patchProp: Uo }, Ja), us;
function ds() {
	return us ||= Li(ls);
}
var fs = ((...e) => {
	let t = ds().createApp(...e), { mount: n } = t;
	return t.mount = (e) => {
		let r = ms(e);
		if (!r) return;
		let i = t._component;
		!h(i) && !i.render && !i.template && (i.template = r.innerHTML), r.nodeType === 1 && (r.textContent = "");
		let a = n(r, !1, ps(r));
		return r instanceof Element && (r.removeAttribute("v-cloak"), r.setAttribute("data-v-app", "")), a;
	}, t;
});
function ps(e) {
	if (e instanceof SVGElement) return "svg";
	if (typeof MathMLElement == "function" && e instanceof MathMLElement) return "mathml";
}
function ms(e) {
	return g(e) ? document.querySelector(e) : e;
}
//#endregion
//#region src/api.ts
async function hs(e, t = {}) {
	let n = await fetch(e, {
		credentials: "same-origin",
		...t,
		headers: {
			Accept: "application/json",
			...t.headers || {}
		}
	}), r = (n.headers.get("content-type") || "").includes("application/json") ? await n.json() : await n.text();
	if (!n.ok) {
		let e = typeof r == "object" && r ? r.error || r.detail || r.message : r;
		throw Error(String(e || `Request failed (${n.status})`));
	}
	return r;
}
function gs(e) {
	return hs(e);
}
function _s(e, t = {}) {
	return hs(e, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(t)
	});
}
function vs(e, t) {
	return hs(e, {
		method: "PUT",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(t)
	});
}
//#endregion
//#region src/trainerStore.ts
var ys = () => ({
	running: !1,
	exit_code: null,
	log_lines: []
}), bs = () => ({
	personal: [],
	negative: [],
	personal_count: 0,
	negative_count: 0
}), xs = () => ({
	items: [],
	captured_count: 0,
	personal_count: 0,
	negative_count: 0
}), Ss = () => ({
	items: [],
	total_size_bytes: 0,
	total_file_count: 0
}), Cs = () => ({
	enabled: !1,
	wake_phrase: "",
	language: "en",
	english_accent: "mixed",
	stt_engine: "faster_whisper",
	minimum_transcript_chars: 2,
	delete_confirmed_wakes: !1,
	promote_close_misses: !1,
	schedule_hours: 24,
	minimum_new_negatives: 3,
	advertised_base_url: "",
	tater_url: "http://127.0.0.1:8501",
	notify_satellites: !0,
	train_microwakeword: !0,
	train_openwakeword: !1,
	train_nanowakeword_cnn: !1,
	train_nanowakeword_gru: !1,
	generated_negative_phrases: ""
}), Y = /* @__PURE__ */ Ft({
	activeView: "trainer",
	initialized: !1,
	busy: /* @__PURE__ */ new Set(),
	phrase: "",
	language: "en",
	englishAccent: "mixed",
	ttsMode: "hybrid",
	trainMicroWakeWord: !0,
	trainOpenWakeWord: !1,
	trainNanoWakeWordCnn: !1,
	trainNanoWakeWordGru: !1,
	generatedNegativePhrases: "",
	languages: [{
		code: "en",
		label: "English (en)",
		engines: ["omnivoice"]
	}],
	englishAccents: [
		{
			code: "mixed",
			label: "Mixed English"
		},
		{
			code: "australian",
			label: "Australian"
		},
		{
			code: "american",
			label: "American"
		},
		{
			code: "british",
			label: "British"
		},
		{
			code: "canadian",
			label: "Canadian"
		},
		{
			code: "irish",
			label: "Irish"
		},
		{
			code: "scottish",
			label: "Scottish"
		},
		{
			code: "new_zealand",
			label: "New Zealand"
		},
		{
			code: "indian",
			label: "Indian"
		},
		{
			code: "south_african",
			label: "South African"
		}
	],
	session: {},
	samples: bs(),
	captured: xs(),
	training: ys(),
	auto: {},
	autoForm: Cs(),
	wakeWords: [],
	managedData: Ss(),
	selectedFiles: [],
	sampleBucket: "personal",
	samplePage: {
		personal: 0,
		negative: 0
	},
	uploadProgress: 0,
	uploadLabel: "No upload in progress",
	uploadDetail: "Choose files and upload when you are ready.",
	consoleOpen: !1,
	taterLinkOpen: !1,
	trimItem: null,
	trimBucket: "personal",
	toast: {
		message: "",
		tone: "success",
		serial: 0
	}
}), ws = !!(window.__wakeWordTrainerMac?.dataFolderPicker && window.webkit?.messageHandlers?.wakeWordTrainerStorage), Ts = 0, Es = 0, Ds = J(() => Number(Y.samples.personal_count ?? Y.session.takes_received ?? 0)), Os = J(() => Number(Y.samples.negative_count ?? Y.captured.negative_count ?? 0)), ks = J(() => Y.languages.find((e) => e.code === Y.language) || Y.languages[0]), As = J(() => {
	let e = ks.value?.engines?.length ? ks.value.engines : ["omnivoice"], t = Y.ttsMode === "piper" ? e.filter((e) => e === "piper") : Y.ttsMode === "hybrid" ? e : e.filter((e) => e !== "piper"), n = {
		omnivoice: "OmniVoice",
		qwen3: "Qwen3",
		moss: "MOSS",
		piper: "Piper"
	}, r = Y.ttsMode === "piper" ? "Legacy" : Fs(ks.value?.quality || "experimental");
	return `${t.map((e) => n[e] || e).join(" + ") || "Unavailable"} · ${r}`;
}), js = J(() => !!(Y.training.running || Y.training.exit_code !== null || Y.training.log_lines?.length)), Ms = J(() => Y.samples[Y.sampleBucket] || []), Ns = J(() => !!Y.auto.trainer_link?.linked), Ps = J(() => {
	let e = Y.auto.stt_engines;
	return Array.isArray(e) && e.length ? e : [{
		id: "faster_whisper",
		label: "Faster Whisper"
	}, {
		id: "parakeet_onnx",
		label: "Parakeet ONNX"
	}];
});
function Fs(e) {
	return String(e || "").replaceAll("_", " ").replace(/\b\w/g, (e) => e.toUpperCase());
}
function X(e) {
	return e ? Y.busy.has(e) : Y.busy.size > 0;
}
function Z(e, t) {
	t ? Y.busy.add(e) : Y.busy.delete(e);
}
function Q(e, t = "success") {
	Y.toast = {
		message: String(e || ""),
		tone: t,
		serial: Y.toast.serial + 1
	};
}
function $(e, t) {
	Q(e instanceof Error ? e.message : t, "error");
}
function Is(e) {
	Y.session = e || {}, Array.isArray(e.available_languages) && e.available_languages.length && (Y.languages = e.available_languages), Array.isArray(e.available_english_accents) && e.available_english_accents.length && (Y.englishAccents = e.available_english_accents), e.raw_phrase && (Y.phrase = e.raw_phrase), e.language && (Y.language = e.language), e.english_accent && (Y.englishAccent = e.english_accent), e.tts_mode && (Y.ttsMode = e.tts_mode), e.training && (Y.training = e.training);
}
async function Ls() {
	let e = await gs("/api/session");
	return Is(e), e;
}
async function Rs() {
	if (!Y.phrase.trim()) {
		Q("Enter a wake phrase first.", "warning");
		return;
	}
	Z("session", !0);
	try {
		let e = await _s("/api/start_session", {
			phrase: Y.phrase.trim(),
			language: Y.language,
			english_accent: Y.englishAccent,
			tts_mode: Y.ttsMode
		});
		Is(e), Q(`Session ${e.safe_word || "started"} is ready.`);
	} catch (e) {
		$(e, "Session failed to start.");
	} finally {
		Z("session", !1);
	}
}
async function zs() {
	let e = !!Y.training.running;
	if (!(e && !window.confirm("Training is running. Stop training cleanly and end this session?"))) {
		Z("session", !0), Es &&= (window.clearInterval(Es), 0);
		try {
			Is(await _s("/api/stop_session")), Q(e ? "Training stopped cleanly and the session ended." : "Session ended. You can edit the wake phrase now.");
		} catch (t) {
			e && dc(), $(t, "Session could not be stopped.");
		} finally {
			Z("session", !1);
		}
	}
}
function Bs() {
	if (!Y.phrase.trim() || !("speechSynthesis" in window)) return;
	let e = new SpeechSynthesisUtterance(Y.phrase.trim());
	e.lang = Y.language, window.speechSynthesis.cancel(), window.speechSynthesis.speak(e);
}
function Vs() {
	let e = ks.value?.engines || [], t = e.some((e) => e !== "piper"), n = e.includes("piper");
	Y.ttsMode === "modern" && !t && (Y.ttsMode = "piper"), Y.ttsMode === "hybrid" && !(t && n) && (Y.ttsMode = t ? "modern" : "piper"), Y.ttsMode === "piper" && !n && (Y.ttsMode = "modern"), (Y.language !== "en" || Y.ttsMode === "piper") && (Y.englishAccent = "mixed");
}
async function Hs(e = !1) {
	e || Z("samples", !0);
	try {
		let e = await gs("/api/samples");
		Y.samples = {
			...bs(),
			...e
		};
		for (let e of ["personal", "negative"]) {
			let t = Math.max(0, Math.ceil((Y.samples[e]?.length || 0) / 50) - 1);
			Y.samplePage[e] = Math.min(Y.samplePage[e], t);
		}
		return e;
	} finally {
		e || Z("samples", !1);
	}
}
async function Us(e = !1) {
	e || Z("captured", !0);
	try {
		let e = await gs("/api/captured_audio");
		return Y.captured = {
			...xs(),
			...e
		}, e;
	} finally {
		e || Z("captured", !1);
	}
}
function Ws(e) {
	let t = e.target;
	Y.selectedFiles = Array.from(t.files || []);
}
function Gs(e, t, n) {
	return new Promise((r, i) => {
		let a = new XMLHttpRequest(), o = new FormData();
		o.append("file", e, e.name), a.open("POST", "/api/upload_personal_sample"), a.responseType = "json", a.upload.onprogress = (r) => {
			r.lengthComputable && (Y.uploadProgress = Math.round((t + r.loaded / r.total) / n * 100), Y.uploadLabel = `Uploading ${e.name} (${t + 1}/${n})`, Y.uploadDetail = "Sending and normalizing the recording.");
		}, a.onload = () => {
			let t = a.response || {};
			a.status >= 200 && a.status < 300 ? r(t) : i(Error(t.error || `Upload failed for ${e.name}`));
		}, a.onerror = () => i(/* @__PURE__ */ Error(`Upload failed for ${e.name}`)), a.send(o);
	});
}
async function Ks(e) {
	if (!Y.session.safe_word) {
		Q("Start a trainer session before uploading samples.", "warning");
		return;
	}
	if (Y.selectedFiles.length) {
		Z("upload", !0);
		try {
			let t = [...Y.selectedFiles];
			for (let e = 0; e < t.length; e += 1) await Gs(t[e], e, t.length);
			Y.uploadProgress = 100, Y.uploadLabel = "Upload complete", Y.uploadDetail = `${t.length} sample${t.length === 1 ? "" : "s"} saved in the required training format.`, Y.selectedFiles = [], e && (e.value = ""), await Promise.all([Ls(), Hs(!0)]), Q("Personal samples uploaded.");
		} catch (e) {
			Y.uploadProgress = 0, $(e, "Sample upload failed.");
		} finally {
			Z("upload", !1);
		}
	}
}
async function qs(e, t) {
	if (!(t === "discard" && !window.confirm(`Discard ${e.saved_as} from the captured-audio inbox?`))) {
		Z("review", !0);
		try {
			await _s(`/api/captured_audio/${encodeURIComponent(e.saved_as)}/${t}`), await Promise.all([
				Ls(),
				Us(!0),
				Hs(!0)
			]), Q(t === "approve_personal" ? "Clip added to personal samples." : t === "mark_negative" ? "Clip marked negative." : "Clip discarded.");
		} catch (e) {
			$(e, "Review action failed.");
		} finally {
			Z("review", !1);
		}
	}
}
async function Js(e, t) {
	if (window.confirm(`Remove ${e.saved_as} from ${t} samples?`)) {
		Z("review", !0);
		try {
			await hs(`/api/samples/${t}/${encodeURIComponent(e.saved_as)}`, { method: "DELETE" }), await Hs(!0), Q("Sample removed.");
		} catch (e) {
			$(e, "Sample removal failed.");
		} finally {
			Z("review", !1);
		}
	}
}
async function Ys(e, t) {
	if (!window.confirm(`Revert ${e.saved_as} to its pre-trim version?`)) return;
	let n = new FormData();
	n.append("bucket", t), n.append("file_name", e.saved_as), Z("review", !0);
	try {
		await hs("/api/samples/revert", {
			method: "POST",
			body: n
		}), await Hs(!0), Q("Original sample restored.");
	} catch (e) {
		$(e, "Sample revert failed.");
	} finally {
		Z("review", !1);
	}
}
async function Xs(e) {
	let t = e === "personal" ? Ds.value : Os.value;
	if (!(!t || !window.confirm(`Clear ${t} ${e} sample${t === 1 ? "" : "s"}?`))) {
		Z("review", !0);
		try {
			await _s(e === "personal" ? "/api/reset_recordings" : "/api/reset_negative_samples"), await Promise.all([
				Ls(),
				Hs(!0),
				Us(!0)
			]), Q(`${Fs(e)} samples cleared.`);
		} catch (e) {
			$(e, "Samples could not be cleared.");
		} finally {
			Z("review", !1);
		}
	}
}
function Zs(e, t) {
	Y.auto = e || {}, t && (Y.autoForm = {
		...Cs(),
		...e.config || {}
	}, Array.isArray(e.config?.generated_negative_phrases) && (Y.autoForm.generated_negative_phrases = e.config.generated_negative_phrases.join("\n")), Y.autoForm.wake_phrase || (Y.autoForm.wake_phrase = Y.session.raw_phrase || ""), Y.autoForm.language || (Y.autoForm.language = Y.session.language || "en"), Y.autoForm.english_accent || (Y.autoForm.english_accent = Y.session.english_accent || "mixed"), String(Y.autoForm.language).toLowerCase().startsWith("en") || (Y.autoForm.english_accent = "mixed"));
}
async function Qs(e = !1) {
	let t = await gs("/api/auto_train");
	return Zs(t, e), t;
}
async function $s() {
	if (![
		Y.autoForm.train_microwakeword,
		Y.autoForm.train_openwakeword,
		Y.autoForm.train_nanowakeword_cnn,
		Y.autoForm.train_nanowakeword_gru
	].some(Boolean)) {
		Q("Select at least one model for Auto Training.", "warning");
		return;
	}
	Z("auto", !0);
	try {
		let e = await vs("/api/auto_train", Y.autoForm);
		Zs(e, !0), Q(e.config?.enabled ? "Auto Training saved and enabled." : "Auto Training saved.");
	} catch (e) {
		$(e, "Auto Training settings failed to save.");
	} finally {
		Z("auto", !1);
	}
}
async function ec(e) {
	Z("auto", !0);
	try {
		let t = await _s("/api/auto_train/action", { action: e });
		Zs(t, !1), e === "train_now" && (Y.consoleOpen = !0, dc()), Q(e === "review_now" ? `${Number(t.queued || 0)} clips queued for review.` : e === "train_now" ? "Training started." : "Wake word published.");
	} catch (e) {
		$(e, "Auto Training action failed.");
	} finally {
		Z("auto", !1);
	}
}
async function tc(e, t) {
	Z("link", !0);
	try {
		return await _s("/api/tater_link/claim", {
			tater_url: e.trim(),
			pairing_code: t.trim()
		}), Y.autoForm.tater_url = e.trim(), await Qs(!1), Q("Trainer linked securely to Tater."), !0;
	} catch (e) {
		return $(e, "Tater link failed."), !1;
	} finally {
		Z("link", !1);
	}
}
async function nc() {
	if (window.confirm("Unlink this trainer from Tater?")) {
		Z("auto", !0);
		try {
			await _s("/api/tater_link/unlink"), await Qs(!1), Q("Trainer unlinked from Tater.", "warning");
		} catch (e) {
			$(e, "Tater unlink failed.");
		} finally {
			Z("auto", !1);
		}
	}
}
async function rc(e = !1) {
	e || Z("firmware", !0);
	try {
		let e = await gs("/api/trained_wake_words/catalog");
		Y.wakeWords = Array.isArray(e.wake_words) ? e.wake_words : [];
	} finally {
		e || Z("firmware", !1);
	}
}
async function ic() {
	Z("data", !0);
	try {
		let e = await gs("/api/data");
		return Y.managedData = {
			...Ss(),
			...e
		}, e;
	} finally {
		Z("data", !1);
	}
}
function ac() {
	let e = window.webkit?.messageHandlers?.wakeWordTrainerStorage;
	if (!ws || !e) {
		Q("Open this page in the WakeWord Trainer Mac app to change the data folder.", "warning");
		return;
	}
	e.postMessage({ action: "choose" });
}
async function oc(e) {
	if (!e.file_count) return;
	let t = `${hc(e.size_bytes)} · ${Number(e.file_count).toLocaleString()} file${e.file_count === 1 ? "" : "s"}`, n = e.rebuild_note ? `\n\n${e.rebuild_note}` : "";
	if (window.confirm(`Permanently delete ${e.label} (${t})?${n}\n\nThis cannot be undone.`)) {
		Z("data-delete", !0);
		try {
			let t = await hs(`/api/data/${encodeURIComponent(e.id)}`, { method: "DELETE" });
			Y.managedData = {
				...Ss(),
				...t
			}, await Promise.allSettled([
				Ls(),
				Hs(!0),
				Us(!0),
				rc(!0)
			]), Q(`${e.label} deleted. ${hc(e.size_bytes)} released.`);
		} catch (t) {
			$(t, `${e.label} could not be deleted.`);
		} finally {
			Z("data-delete", !1);
		}
	}
}
async function sc(e) {
	try {
		await navigator.clipboard.writeText(e), Q("Wake-word JSON URL copied.");
	} catch (e) {
		$(e, "Clipboard unavailable.");
	}
}
async function cc() {
	if (![
		Y.trainMicroWakeWord,
		Y.trainOpenWakeWord,
		Y.trainNanoWakeWordCnn,
		Y.trainNanoWakeWordGru
	].some(Boolean)) {
		Q("Select at least one wake-word model to train.", "warning");
		return;
	}
	await Promise.all([Ls(), Hs(!0)]);
	let e = !1;
	if (!(!Ds.value && (e = window.confirm("No positive samples are saved. Train anyway without personal voices?"), !e))) {
		Z("training-start", !0), Y.training = {
			running: !0,
			exit_code: null,
			log_lines: ["Waiting for training output…"]
		}, Y.consoleOpen = !0;
		try {
			await _s("/api/train", {
				allow_no_personal: e,
				train_microwakeword: Y.trainMicroWakeWord,
				train_openwakeword: Y.trainOpenWakeWord,
				train_nanowakeword_cnn: Y.trainNanoWakeWordCnn,
				train_nanowakeword_gru: Y.trainNanoWakeWordGru,
				generated_negative_phrases: Y.generatedNegativePhrases
			}), dc();
		} catch (e) {
			Y.training = {
				running: !1,
				exit_code: 1,
				log_lines: [e instanceof Error ? e.message : String(e)]
			}, $(e, "Training could not start.");
		} finally {
			Z("training-start", !1);
		}
	}
}
async function lc(e = "") {
	Z("oww-retry", !0), Y.training = {
		running: !0,
		exit_code: null,
		log_lines: ["Starting openWakeWord-only retry…"]
	}, Y.consoleOpen = !0;
	try {
		await _s("/api/train_openwakeword", { safe_word: e }), dc();
	} catch (e) {
		Y.training = {
			running: !1,
			exit_code: 1,
			log_lines: [e instanceof Error ? e.message : String(e)]
		}, $(e, "openWakeWord retry could not start.");
	} finally {
		Z("oww-retry", !1);
	}
}
async function uc(e, t = "") {
	let n = e.toLowerCase();
	Z("nww-revalidate", !0), Y.training = {
		running: !0,
		exit_code: null,
		log_lines: [`Revalidating existing NanoWakeWord ${n.toUpperCase()} candidate…`]
	}, Y.consoleOpen = !0;
	try {
		await _s("/api/revalidate_nanowakeword", {
			architecture: n,
			safe_word: t
		}), dc();
	} catch (e) {
		Y.training = {
			running: !1,
			exit_code: 1,
			log_lines: [e instanceof Error ? e.message : String(e)]
		}, $(e, "NanoWakeWord candidate revalidation could not start.");
	} finally {
		Z("nww-revalidate", !1);
	}
}
function dc() {
	if (Es) return;
	let e = async () => {
		try {
			let e = await gs("/api/train_status");
			Y.training = {
				...ys(),
				...e.training || {}
			}, Y.training.running || (window.clearInterval(Es), Es = 0, await Promise.all([Hs(!0), rc(!0)]), Q(Y.training.exit_code === 0 ? "Training finished successfully." : `Training ended with exit ${Y.training.exit_code}.`, Y.training.exit_code === 0 ? "success" : "error"));
		} catch {}
	};
	e(), Es = window.setInterval(() => void e(), 1500);
}
async function fc() {
	Z("bootstrap", !0);
	try {
		await Promise.allSettled([
			Ls(),
			Hs(!0),
			Us(!0),
			Qs(!0),
			rc(!0)
		]), Vs();
		try {
			let e = await gs("/api/train_status");
			Y.training = {
				...ys(),
				...e.training || {}
			}, Y.training.running && (Y.consoleOpen = !0, dc());
		} catch {}
		Ts = window.setInterval(() => {
			Y.activeView === "auto" && !X("auto") && Qs(!1).catch(() => void 0);
		}, 2500), Y.initialized = !0;
	} finally {
		Z("bootstrap", !1);
	}
}
function pc() {
	window.clearInterval(Ts), window.clearInterval(Es), Ts = 0, Es = 0;
}
function mc(e) {
	if (!e) return "";
	let t = new Date(String(e));
	return Number.isNaN(t.getTime()) ? String(e) : t.toLocaleString();
}
function hc(e) {
	let t = Math.max(0, Number(e) || 0);
	if (t < 1024) return `${Math.round(t)} B`;
	let n = [
		"KB",
		"MB",
		"GB",
		"TB"
	], r = t / 1024, i = n[0];
	for (let e = 1; e < n.length && r >= 1024; e += 1) r /= 1024, i = n[e];
	return `${r >= 10 ? r.toFixed(1) : r.toFixed(2)} ${i}`;
}
function gc(e) {
	if (!e) return "16 kHz · mono · 16-bit WAV";
	let t = Number(e.sample_rate || e.sample_rate_hz || 16e3), n = Number(e.channels || 1) === 1 ? "mono" : `${e.channels} channels`, r = Number(e.bits_per_sample || e.sample_width_bits || 16);
	return `${Math.round(t / 1e3)} kHz · ${n} · ${r}-bit`;
}
function _c(e) {
	if (e.blocked_by_vad) return {
		label: "Blocked by VAD",
		tone: "warning"
	};
	let t = String(e.event_type || "").toLowerCase();
	return t.includes("close") ? {
		label: e.capture_label || "Close miss",
		tone: "warning"
	} : t.includes("false") ? {
		label: e.capture_label || "False trigger",
		tone: "error"
	} : t.includes("wake") || t.includes("detect") ? {
		label: e.capture_label || "Wake trigger",
		tone: "success"
	} : {
		label: e.capture_label || "Captured",
		tone: "neutral"
	};
}
function vc(e, t) {
	return e.audio_url || `/api/audio/${t}/${encodeURIComponent(e.saved_as)}`;
}
//#endregion
//#region src/components/AudioTrimModal.vue?vue&type=script&setup=true&lang.ts
var yc = {
	class: "modal trim-modal",
	role: "dialog",
	"aria-modal": "true",
	"aria-label": "Trim audio"
}, bc = { class: "modal-head" }, xc = {
	key: 0,
	class: "empty-state"
}, Sc = { class: "range-grid" }, Cc = ["max"], wc = ["min", "max"], Tc = { class: "row space" }, Ec = { class: "pill" }, Dc = {
	key: 0,
	class: "pill success"
}, Oc = { class: "row modal-actions" }, kc = ["disabled"], Ac = /* @__PURE__ */ pr({
	__name: "AudioTrimModal",
	setup(e) {
		let t = /* @__PURE__ */ Kt(null), n = /* @__PURE__ */ Kt(null), r = /* @__PURE__ */ Kt(0), i = /* @__PURE__ */ Kt(0), a = /* @__PURE__ */ Kt(0), o = /* @__PURE__ */ Kt([]), s = /* @__PURE__ */ Kt(!1), c = /* @__PURE__ */ Kt(!1);
		Pn(() => Y.trimItem, async (e) => {
			if (!e) {
				n.value = null;
				return;
			}
			s.value = !0;
			try {
				let t = `/api/audio/${encodeURIComponent(Y.trimBucket)}/${encodeURIComponent(e.saved_as)}`, s = await fetch(t);
				if (!s.ok) throw Error("Audio could not be loaded.");
				let c = new (window.AudioContext || window.webkitAudioContext)();
				n.value = await c.decodeAudioData(await s.arrayBuffer()), r.value = n.value.duration, i.value = 0, a.value = r.value, await c.close();
				try {
					let t = await hs(`/api/samples/${encodeURIComponent(Y.trimBucket)}/${encodeURIComponent(e.saved_as)}/vad`, { method: "POST" });
					o.value = Array.isArray(t.segments) ? t.segments : [], o.value.length && (i.value = Math.max(0, Number(o.value[0].start || 0)), a.value = Math.min(r.value, Number(o.value[0].end || r.value)));
				} catch {
					o.value = [];
				}
				await gn(), d();
			} catch (e) {
				Q(e instanceof Error ? e.message : "Audio could not be loaded.", "error"), l();
			} finally {
				s.value = !1;
			}
		}, { immediate: !0 }), Pn([i, a], () => d());
		function l() {
			Y.trimItem = null, n.value = null, o.value = [];
		}
		function u() {
			let e = o.value[0];
			e && (i.value = Number(e.start), a.value = Number(e.end));
		}
		function d() {
			let e = t.value, s = n.value;
			if (!e || !s || !r.value) return;
			let c = e.getBoundingClientRect();
			if (!c.width || !c.height) return;
			let l = window.devicePixelRatio || 1;
			e.width = Math.round(c.width * l), e.height = Math.round(c.height * l);
			let u = e.getContext("2d");
			if (!u) return;
			u.scale(l, l);
			let d = c.width, f = c.height, p = f / 2, m = s.getChannelData(0), h = Math.max(1, Math.floor(m.length / d));
			u.clearRect(0, 0, d, f), u.strokeStyle = "rgba(222, 218, 212, .24)", u.lineWidth = 1, u.beginPath();
			for (let e = 0; e < d; e += 1) {
				let t = 1, n = -1;
				for (let r = 0; r < h; r += 1) {
					let i = m[Math.floor(e) * h + r] || 0;
					t = Math.min(t, i), n = Math.max(n, i);
				}
				u.moveTo(e, p + t * p * .84), u.lineTo(e, p + n * p * .84);
			}
			u.stroke();
			let g = i.value / r.value * d, _ = a.value / r.value * d;
			u.fillStyle = "rgba(8, 8, 9, .66)", u.fillRect(0, 0, g, f), u.fillRect(_, 0, d - _, f), u.fillStyle = "rgba(255, 145, 52, .12)", u.fillRect(g, 0, _ - g, f), u.strokeStyle = "#ff9134", u.lineWidth = 2;
			for (let e of [g, _]) u.beginPath(), u.moveTo(e, 0), u.lineTo(e, f), u.stroke();
			u.strokeStyle = "rgba(68, 225, 165, .55)";
			for (let e of o.value) {
				let t = e.start / r.value * d;
				u.beginPath(), u.moveTo(t, 0), u.lineTo(t, f), u.stroke();
			}
		}
		function f() {
			let e = n.value;
			if (!e) return;
			let t = new (window.AudioContext || window.webkitAudioContext)(), r = t.createBufferSource();
			r.buffer = e, r.connect(t.destination), r.start(0, i.value, Math.max(.01, a.value - i.value)), r.onended = () => void t.close();
		}
		async function p() {
			let e = n.value;
			if (!e) throw Error("Audio is not loaded.");
			let t = Math.floor(i.value * e.sampleRate), r = Math.min(Math.floor(a.value * e.sampleRate), e.length), o = 16e3, s;
			if (e.sampleRate === o) s = e.getChannelData(0).slice(t, r);
			else {
				let n = Math.max(1, Math.floor((r - t) * o / e.sampleRate)), c = new OfflineAudioContext(1, n, o), l = c.createBufferSource();
				l.buffer = e, l.connect(c.destination), l.start(0, i.value, a.value - i.value), s = (await c.startRendering()).getChannelData(0);
			}
			let c = /* @__PURE__ */ new ArrayBuffer(44 + s.length * 2), l = new DataView(c);
			l.setUint32(0, 1380533830, !1), l.setUint32(4, 36 + s.length * 2, !0), l.setUint32(8, 1463899717, !1), l.setUint32(12, 1718449184, !1), l.setUint32(16, 16, !0), l.setUint16(20, 1, !0), l.setUint16(22, 1, !0), l.setUint32(24, o, !0), l.setUint32(28, o * 2, !0), l.setUint16(32, 2, !0), l.setUint16(34, 16, !0), l.setUint32(36, 1684108385, !1), l.setUint32(40, s.length * 2, !0);
			for (let e = 0; e < s.length; e += 1) l.setInt16(44 + e * 2, Math.max(-32768, Math.min(32767, Math.round(s[e] * 32767))), !0);
			return new Blob([c], { type: "audio/wav" });
		}
		async function m() {
			let e = Y.trimItem;
			if (e) {
				c.value = !0;
				try {
					let t = new FormData();
					t.append("file", await p(), "trimmed.wav"), t.append("bucket", Y.trimBucket), t.append("source_file", e.saved_as), t.append("start_time", i.value.toFixed(3)), t.append("end_time", a.value.toFixed(3));
					let n = await hs("/api/samples/trim", {
						method: "POST",
						body: t
					});
					l(), await Hs(!0), Q(n.message || "Trimmed sample saved.");
				} catch (e) {
					Q(e instanceof Error ? e.message : "Trim failed.", "error");
				} finally {
					c.value = !1;
				}
			}
		}
		function h() {
			Y.trimItem && d();
		}
		return window.addEventListener("resize", h), jr(() => window.removeEventListener("resize", h)), (e, n) => (H(), ia(Yn, { to: "body" }, [F(Y).trimItem ? (H(), U("div", {
			key: 0,
			class: "modal-backdrop",
			onClick: os(l, ["self"])
		}, [W("section", yc, [
			W("header", bc, [W("div", null, [n[2] ||= W("span", { class: "eyebrow" }, "Audio editor", -1), W("h2", null, "Trim " + k(F(Y).trimItem.saved_as), 1)]), W("button", {
				type: "button",
				class: "button ghost",
				onClick: l
			}, "Close")]),
			n[3] ||= W("p", { class: "muted" }, "Keep the spoken wake phrase and remove excess silence or noise. VAD markers appear in green.", -1),
			s.value ? (H(), U("div", xc, "Loading waveform…")) : (H(), U(V, { key: 1 }, [
				W("canvas", {
					ref_key: "canvas",
					ref: t,
					class: "waveform"
				}, null, 512),
				W("div", Sc, [W("label", null, [W("span", null, "Start · " + k(i.value.toFixed(2)) + "s", 1), L(W("input", {
					"onUpdate:modelValue": n[0] ||= (e) => i.value = e,
					type: "range",
					min: "0",
					max: Math.max(0, a.value - .01),
					step: ".01"
				}, null, 8, Cc), [[
					Zo,
					i.value,
					void 0,
					{ number: !0 }
				]])]), W("label", null, [W("span", null, "End · " + k(a.value.toFixed(2)) + "s", 1), L(W("input", {
					"onUpdate:modelValue": n[1] ||= (e) => a.value = e,
					type: "range",
					min: Math.min(r.value, i.value + .01),
					max: r.value,
					step: ".01"
				}, null, 8, wc), [[
					Zo,
					a.value,
					void 0,
					{ number: !0 }
				]])])]),
				W("div", Tc, [W("span", Ec, "Selection " + k(Math.max(0, a.value - i.value).toFixed(2)) + "s", 1), o.value.length ? (H(), U("span", Dc, k(o.value.length) + " speech segment" + k(o.value.length === 1 ? "" : "s"), 1)) : K("", !0)]),
				W("div", Oc, [
					W("button", {
						type: "button",
						onClick: f
					}, "Play selection"),
					o.value.length ? (H(), U("button", {
						key: 0,
						type: "button",
						onClick: u
					}, "Select first VAD")) : K("", !0),
					W("button", {
						type: "button",
						class: "button primary",
						disabled: c.value,
						onClick: m
					}, k(c.value ? "Saving…" : "Save trim"), 9, kc)
				])
			], 64))
		])])) : K("", !0)]));
	}
}), jc = { class: "app-shell" }, Mc = { class: "app-header" }, Nc = { class: "header-status" }, Pc = {
	key: 0,
	class: "session-chip"
}, Fc = {
	class: "tabs",
	"aria-label": "Trainer areas"
}, Ic = ["onClick"], Lc = { class: "tab-full" }, Rc = { class: "tab-short" }, zc = { key: 0 }, Bc = { class: "main-content" }, Vc = {
	key: 0,
	class: "loading-panel"
}, Hc = { class: "panel" }, Uc = { class: "panel-head" }, Wc = { class: "form-grid phrase-form" }, Gc = { class: "field wide" }, Kc = ["disabled"], qc = { class: "field" }, Jc = ["disabled"], Yc = ["value"], Xc = {
	key: 0,
	class: "field"
}, Zc = ["disabled"], Qc = ["value"], $c = { class: "field" }, el = ["disabled"], tl = ["disabled"], nl = ["disabled"], rl = ["disabled"], il = { class: "row form-actions" }, al = ["disabled"], ol = ["disabled"], sl = ["disabled"], cl = { class: "panel" }, ll = { class: "panel-head" }, ul = { class: "stats" }, dl = { class: "model-picker" }, fl = {
	class: "model-choice-grid",
	role: "group",
	"aria-label": "Wake-word models to train"
}, pl = ["aria-pressed"], ml = ["aria-pressed"], hl = ["aria-pressed"], gl = {
	key: 0,
	class: "nano-architecture-panel"
}, _l = { class: "nano-architecture-heading" }, vl = {
	class: "nano-architecture-grid",
	role: "group",
	"aria-label": "NanoWakeWord architectures"
}, yl = ["aria-pressed"], bl = ["aria-pressed"], xl = {
	key: 1,
	class: "hard-negative-card"
}, Sl = { class: "hard-negative-head" }, Cl = { class: "hard-negative-engines" }, wl = { class: "field" }, Tl = {
	key: 0,
	class: "training-summary-card"
}, El = { class: "training-summary-grid" }, Dl = {
	key: 0,
	class: "summary-metrics"
}, Ol = { class: "train-action" }, kl = ["disabled"], Al = ["disabled"], jl = ["disabled"], Ml = { class: "panel-footer" }, Nl = ["disabled"], Pl = { class: "hero auto-hero" }, Fl = { class: "panel" }, Il = { class: "toggle-list" }, Ll = { class: "form-grid" }, Rl = { class: "field" }, zl = { class: "field" }, Bl = {
	key: 0,
	class: "field"
}, Vl = ["value"], Hl = { class: "field wide" }, Ul = ["value"], Wl = { class: "field" }, Gl = { class: "panel" }, Kl = { class: "form-grid" }, ql = { class: "field" }, Jl = { class: "field" }, Yl = { class: "model-picker" }, Xl = {
	class: "model-choice-grid",
	role: "group",
	"aria-label": "Auto Training wake-word models"
}, Zl = ["aria-pressed"], Ql = ["aria-pressed"], $l = ["aria-pressed"], eu = {
	key: 0,
	class: "nano-architecture-panel"
}, tu = { class: "nano-architecture-heading" }, nu = {
	class: "nano-architecture-grid",
	role: "group",
	"aria-label": "Auto Training NanoWakeWord architectures"
}, ru = ["aria-pressed"], iu = ["aria-pressed"], au = {
	key: 1,
	class: "hard-negative-card"
}, ou = { class: "hard-negative-head" }, su = { class: "hard-negative-engines" }, cu = { class: "field" }, lu = {
	key: 0,
	class: "training-summary-card"
}, uu = { class: "training-summary-grid" }, du = {
	key: 0,
	class: "summary-metrics"
}, fu = { class: "stats" }, pu = { class: "format-value" }, mu = { class: "format-value" }, hu = { class: "panel" }, gu = { class: "form-grid" }, _u = { class: "field wide" }, vu = { class: "field wide" }, yu = { class: "link-row" }, bu = ["disabled"], xu = ["disabled"], Su = { class: "toggle-list compact" }, Cu = { class: "panel action-panel" }, wu = { class: "action-grid" }, Tu = ["disabled"], Eu = ["disabled"], Du = ["disabled"], Ou = ["disabled"], ku = { class: "audit" }, Au = { class: "hero capture-hero" }, ju = { class: "panel" }, Mu = { class: "panel-head" }, Nu = ["disabled"], Pu = { class: "stats" }, Fu = { class: "panel" }, Iu = {
	key: 0,
	class: "empty-state"
}, Lu = {
	key: 1,
	class: "audio-list"
}, Ru = {
	key: 0,
	class: "meta-row"
}, zu = {
	key: 1,
	class: "transcript"
}, Bu = {
	key: 2,
	class: "transcript"
}, Vu = ["src"], Hu = ["disabled", "onClick"], Uu = ["disabled", "onClick"], Wu = ["disabled", "onClick"], Gu = { class: "hero samples-hero" }, Ku = { class: "pill hero-pill" }, qu = { class: "panel" }, Ju = { class: "panel-head sample-head" }, Yu = { class: "segment-control" }, Xu = { class: "row toolbar" }, Zu = ["disabled"], Qu = ["disabled"], $u = ["disabled"], ed = {
	key: 0,
	class: "empty-state"
}, td = {
	key: 1,
	class: "audio-list compact-list"
}, nd = { class: "row" }, rd = {
	key: 0,
	class: "pill warning"
}, id = {
	key: 0,
	class: "transcript"
}, ad = {
	key: 1,
	class: "transcript"
}, od = ["src"], sd = ["onClick"], cd = ["onClick"], ld = ["disabled", "onClick"], ud = {
	key: 2,
	class: "pagination"
}, dd = ["disabled"], fd = ["disabled"], pd = { class: "panel" }, md = { class: "dropzone" }, hd = ["disabled"], gd = { class: "progress-card" }, _d = { class: "progress-track" }, vd = { class: "hero data-hero" }, yd = { class: "pill hero-pill" }, bd = { class: "panel storage-location-panel" }, xd = { class: "panel-head" }, Sd = ["disabled"], Cd = { class: "storage-location" }, wd = {
	key: 0,
	class: "pill success"
}, Td = {
	key: 1,
	class: "pill neutral"
}, Ed = {
	key: 0,
	class: "data-warning"
}, Dd = { class: "panel" }, Od = { class: "panel-head" }, kd = ["disabled"], Ad = { class: "stats" }, jd = { class: "format-value" }, Md = {
	key: 0,
	class: "data-warning"
}, Nd = { class: "panel-head" }, Pd = { class: "number" }, Fd = { class: "data-list" }, Id = { class: "data-copy" }, Ld = { class: "data-title" }, Rd = {
	key: 0,
	class: "data-note"
}, zd = { class: "data-usage" }, Bd = ["disabled", "onClick"], Vd = {
	key: 0,
	class: "panel empty-state"
}, Hd = { class: "hero firmware-hero" }, Ud = { class: "panel" }, Wd = { class: "panel-head" }, Gd = ["disabled"], Kd = {
	key: 0,
	class: "empty-state"
}, qd = {
	key: 1,
	class: "word-list"
}, Jd = ["href"], Yd = {
	key: 1,
	class: "muted"
}, Xd = ["href"], Zd = ["href"], Qd = ["href"], $d = { class: "meta-row" }, ef = { key: 0 }, tf = { key: 1 }, nf = { key: 2 }, rf = ["disabled", "onClick"], af = { class: "panel compatibility-panel" }, of = {
	key: 0,
	class: "empty-state"
}, sf = {
	key: 1,
	class: "word-list"
}, cf = ["href"], lf = {
	key: 1,
	class: "muted"
}, uf = ["disabled", "onClick"], df = {
	class: "modal console-modal",
	role: "dialog",
	"aria-modal": "true",
	"aria-label": "Training console"
}, ff = { class: "modal-head" }, pf = { class: "row console-actions" }, mf = {
	class: "modal link-modal",
	role: "dialog",
	"aria-modal": "true",
	"aria-label": "Link Tater"
}, hf = { class: "modal-head" }, gf = {
	key: 0,
	class: "link-success"
}, _f = {
	key: 1,
	class: "stack"
}, vf = { class: "field" }, yf = { class: "field" }, bf = ["disabled"], xf = "/static/images/tater-wake-word-trainer.png", Sf = 50, Cf = /* @__PURE__ */ pr({
	__name: "TrainerApp",
	setup(e) {
		let t = /* @__PURE__ */ Kt(null), n = /* @__PURE__ */ Kt(null), r = /* @__PURE__ */ Kt(!0), i = /* @__PURE__ */ Kt(""), a = /* @__PURE__ */ Kt(""), o = /* @__PURE__ */ Kt(!1), s = [
			{
				id: "trainer",
				label: "Trainer",
				short: "Train"
			},
			{
				id: "auto",
				label: "Auto Training",
				short: "Auto"
			},
			{
				id: "firmware",
				label: "Wake Words",
				short: "Words"
			},
			{
				id: "captured",
				label: "Captured Audio",
				short: "Inbox"
			},
			{
				id: "samples",
				label: "Samples",
				short: "Samples"
			},
			{
				id: "data",
				label: "Data",
				short: "Data"
			}
		], c = J(() => {
			let e = Y.samplePage[Y.sampleBucket];
			return Ms.value.slice(e * Sf, (e + 1) * Sf);
		}), l = J(() => Math.max(1, Math.ceil(Ms.value.length / Sf))), u = J(() => Y.auto.state || {}), d = J(() => Y.auto.runtime || {}), f = J(() => {
			let e = u.value, t = [];
			return e.last_review_result && t.push(`Last review: ${String(e.last_review_result).replaceAll("_", " ")}`), e.last_review_file && t.push(String(e.last_review_file)), e.last_review_transcript && t.push(`STT: “${e.last_review_transcript}”`), e.last_review_error && t.push(`Error: ${e.last_review_error}`), e.last_stt_engine && t.push(`STT engine: ${String(e.last_stt_engine).replaceAll("_", " ")}`), e.last_notify_at && t.push(e.last_notify_error ? `Publish failed: ${e.last_notify_error}` : `Wake word published ${mc(e.last_notify_at)}`), t.join(" · ") || "No automatic review has run yet.";
		}), p = J(() => Y.training.running ? {
			text: "Training running",
			tone: "warning"
		} : Y.training.exit_code === 0 ? {
			text: "Training finished",
			tone: "success"
		} : Y.training.exit_code === null ? {
			text: "Not started",
			tone: "neutral"
		} : {
			text: `Exit ${Y.training.exit_code}`,
			tone: "error"
		}), m = J(() => d.value.review_running ? {
			text: `Transcribing ${d.value.review_file || "wake"}`,
			tone: "warning"
		} : Y.training.running && Y.auto.config?.enabled ? {
			text: "Training running",
			tone: "warning"
		} : Y.auto.config?.enabled ? {
			text: "Enabled",
			tone: "success"
		} : {
			text: "Disabled",
			tone: "neutral"
		}), h = J(() => Y.training.log_lines?.length ? Y.training.log_lines : ["No training output yet."]), g = J(() => {
			let e = String(Y.session.safe_word || ""), t = Y.wakeWords.filter((e) => !e.dual_model);
			return t.find((t) => String(t.key || "") === e) || t[0];
		}), _ = J(() => (Array.isArray(Y.training.summary?.models) ? Y.training.summary.models : []).find((e) => e.failure_kind === "quality_rejected" && String(e.id || "").startsWith("nano_"))), v = J(() => {
			let e = /* @__PURE__ */ new Map();
			for (let t of Y.managedData.items || []) {
				let n = e.get(t.category) || [];
				n.push(t), e.set(t.category, n);
			}
			return Array.from(e, ([e, t]) => ({
				name: e,
				items: t
			}));
		}), y = J(() => Y.trainNanoWakeWordCnn || Y.trainNanoWakeWordGru), b = J(() => Y.autoForm.train_nanowakeword_cnn || Y.autoForm.train_nanowakeword_gru), x = J(() => [
			...Y.trainMicroWakeWord ? ["MWW"] : [],
			...Y.trainOpenWakeWord ? ["OWW"] : [],
			...y.value ? ["NWW"] : []
		]), S = J(() => [
			...Y.autoForm.train_microwakeword ? ["MWW"] : [],
			...Y.autoForm.train_openwakeword ? ["OWW"] : [],
			...b.value ? ["NWW"] : []
		]);
		Pn([() => Y.language, () => Y.ttsMode], Vs), Pn(() => Y.toast.serial, () => window.setTimeout(() => {
			Y.toast.message = "";
		}, 4500)), Pn(h, async () => {
			r.value && (await gn(), r.value && n.value && (n.value.scrollTop = n.value.scrollHeight));
		}), Pn(() => Y.consoleOpen, async (e) => {
			e && (r.value = !0, await gn(), ee());
		}), Or(() => {
			fc(), document.addEventListener("keydown", C);
		}), jr(() => {
			pc(), document.removeEventListener("keydown", C);
		});
		function C(e) {
			e.key === "Escape" && (Y.consoleOpen = !1, Y.taterLinkOpen = !1, Y.trimItem = null);
		}
		function w() {
			let e = n.value;
			if (!e) return;
			let t = e.scrollHeight - e.clientHeight - e.scrollTop;
			r.value = t <= 32;
		}
		function ee() {
			let e = n.value;
			e && (r.value = !0, e.scrollTop = e.scrollHeight);
		}
		function te(e) {
			Y.activeView = e, (e === "auto" ? Qs(!1) : e === "captured" ? Us() : e === "samples" ? Hs() : e === "firmware" ? rc() : e === "data" ? ic() : Promise.resolve()).catch((e) => Q(e instanceof Error ? e.message : "Refresh failed.", "error"));
		}
		function ne(e) {
			Y.sampleBucket = e;
		}
		function T(e, t) {
			Y.trimBucket = t, Y.trimItem = e;
		}
		function re() {
			y.value ? (Y.trainNanoWakeWordCnn = !1, Y.trainNanoWakeWordGru = !1) : Y.trainNanoWakeWordCnn = !0;
		}
		function E() {
			b.value ? (Y.autoForm.train_nanowakeword_cnn = !1, Y.autoForm.train_nanowakeword_gru = !1) : Y.autoForm.train_nanowakeword_cnn = !0;
		}
		function ie(e) {
			return new Set(String(e || "").split(/[\n,]+/).map((e) => e.trim().toLocaleLowerCase()).filter(Boolean)).size;
		}
		function ae() {
			i.value = Y.autoForm.tater_url || "http://127.0.0.1:8501", a.value = "", o.value = !1, Y.taterLinkOpen = !0, gn(() => document.querySelector("#pairing-code")?.focus());
		}
		function oe() {
			let e = a.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8);
			a.value = e.length > 4 ? `${e.slice(0, 4)}-${e.slice(4)}` : e;
		}
		async function se() {
			if (!i.value.trim() || !a.value.trim()) {
				Q("Tater address and pairing code are required.", "warning");
				return;
			}
			o.value = await tc(i.value, a.value);
		}
		function D(e) {
			let t = [];
			return e.source_device && t.push(String(e.source_device)), e.wake_word && t.push(String(e.wake_word)), e.max_probability !== null && e.max_probability !== void 0 && t.push(`max ${e.max_probability}`), e.average_probability !== null && e.average_probability !== void 0 && t.push(`avg ${e.average_probability}`), e.detection_profile && t.push(`profile ${String(e.detection_profile).replaceAll("_", " ")}`), e.auto_review_status && t.push(`auto ${String(e.auto_review_status).replaceAll("_", " ")}`), e.vad_max_probability !== null && e.vad_max_probability !== void 0 && t.push(`VAD ${e.vad_max_probability}`), t;
		}
		function ce(e) {
			let t = [];
			e.original_name && e.original_name !== e.saved_as && t.push(`From ${e.original_name}`);
			let n = mc(e.reviewed_at || e.received_at || e.created_at);
			return n && t.push(`Saved ${n}`), e.message && t.push(String(e.message)), e.auto_negative && t.push("Auto-reviewed false positive"), e.auto_positive && t.push("Auto-promoted close miss"), t.join(" · ") || "Training sample";
		}
		function le(e) {
			return String(e.json_url || e.url || e.jsonUrl || "");
		}
		function ue(e) {
			return String(e.esphome_json_url || e.esphomeJsonUrl || "");
		}
		function de(e) {
			return String(e.model_url || e.modelUrl || "");
		}
		function pe(e) {
			return String(e.openwakeword_model_url || "");
		}
		function me(e) {
			return e.nanowakeword_models && typeof e.nanowakeword_models == "object" ? e.nanowakeword_models : {};
		}
		function he(e) {
			let t = e.trim().toLowerCase();
			return /^(✓|✅)|success|finished/.test(t) ? "success" : /^(✗|❌)|error|failed|traceback/.test(t) ? "error" : /^(⚠|warning)/.test(t) ? "warning" : /^={4,}|^-----|^=====/.test(t) ? "heading" : "";
		}
		return (e, d) => (H(), U("div", jc, [
			d[167] ||= W("div", {
				class: "ambient ambient-one",
				"aria-hidden": "true"
			}, null, -1),
			d[168] ||= W("div", {
				class: "ambient ambient-two",
				"aria-hidden": "true"
			}, null, -1),
			W("header", Mc, [W("div", { class: "brand" }, [W("div", {
				class: "brand-mark",
				"aria-hidden": "true"
			}, [W("img", {
				src: xf,
				alt: ""
			})]), d[59] ||= W("div", null, [
				W("span", { class: "eyebrow" }, "Tater tools"),
				W("h1", null, "Wake Word Studio"),
				W("p", null, "Generate voices, curate real recordings, train, and publish.")
			], -1)]), W("div", Nc, [d[60] ||= W("span", { class: "live-dot" }, [W("i"), fa("Local trainer")], -1), F(Y).session.safe_word ? (H(), U("span", Pc, k(F(Y).session.safe_word) + " · " + k(F(Y).language), 1)) : K("", !0)])]),
			W("nav", Fc, [(H(), U(V, null, R(s, (e) => W("button", {
				key: e.id,
				type: "button",
				class: O({ active: F(Y).activeView === e.id }),
				onClick: (t) => te(e.id)
			}, [
				W("span", Lc, k(e.label), 1),
				W("span", Rc, k(e.short), 1),
				e.id === "captured" && F(Y).captured.captured_count ? (H(), U("b", zc, k(F(Y).captured.captured_count), 1)) : K("", !0)
			], 10, Ic)), 64))]),
			W("main", Bc, [F(Y).initialized ? (H(), U(V, { key: 1 }, [F(Y).activeView === "trainer" ? (H(), U(V, { key: 0 }, [
				d[89] ||= pa("<section class=\"hero training-hero\"><div><span class=\"eyebrow\">Training studio</span><h2>Build a personal wake word</h2><p>Choose a multilingual voice route, check your real samples, then follow the model pipeline live.</p></div><div class=\"step-row\"><span><b>1</b> Phrase</span><span><b>2</b> Samples</span><span><b>3</b> Train</span></div></section>", 1),
				W("section", Hc, [
					W("header", Uc, [
						d[62] ||= W("div", { class: "number" }, "1", -1),
						d[63] ||= W("div", null, [W("h3", null, "Phrase + voice"), W("p", null, "The phrase and voice route lock while a session is active.")], -1),
						W("span", { class: O(["pill", F(Y).session.safe_word ? "success" : ""]) }, k(F(Y).session.safe_word ? `Session · ${F(Y).session.safe_word}` : "No session"), 3)
					]),
					W("div", Wc, [
						W("label", Gc, [d[64] ||= W("span", null, "Wake phrase", -1), L(W("input", {
							"onUpdate:modelValue": d[0] ||= (e) => F(Y).phrase = e,
							type: "text",
							placeholder: "e.g. \"hey tater\"",
							disabled: !!F(Y).session.safe_word || F(X)("session"),
							onKeyup: d[1] ||= cs((...e) => F(Rs) && F(Rs)(...e), ["enter"])
						}, null, 40, Kc), [[Zo, F(Y).phrase]])]),
						W("label", qc, [
							d[65] ||= W("span", null, "Language", -1),
							L(W("select", {
								"onUpdate:modelValue": d[2] ||= (e) => F(Y).language = e,
								disabled: !!F(Y).session.safe_word || F(X)("session")
							}, [(H(!0), U(V, null, R(F(Y).languages, (e) => (H(), U("option", {
								key: e.code,
								value: e.code
							}, k(e.label), 9, Yc))), 128))], 8, Jc), [[es, F(Y).language]]),
							W("small", null, k(F(As)), 1)
						]),
						F(Y).language === "en" && F(Y).ttsMode !== "piper" ? (H(), U("label", Xc, [
							d[66] ||= W("span", null, "English accent emphasis", -1),
							L(W("select", {
								"onUpdate:modelValue": d[3] ||= (e) => F(Y).englishAccent = e,
								disabled: !!F(Y).session.safe_word || F(X)("session")
							}, [(H(!0), U(V, null, R(F(Y).englishAccents, (e) => (H(), U("option", {
								key: e.code,
								value: e.code
							}, k(e.label), 9, Qc))), 128))], 8, Zc), [[es, F(Y).englishAccent]]),
							d[67] ||= W("small", null, "Qwen emphasizes this accent; MOSS carries it through accepted references. OmniVoice and Piper keep broad English coverage.", -1)
						])) : K("", !0),
						W("label", $c, [
							d[68] ||= W("span", null, "TTS source", -1),
							L(W("select", {
								"onUpdate:modelValue": d[4] ||= (e) => F(Y).ttsMode = e,
								disabled: !!F(Y).session.safe_word || F(X)("session")
							}, [
								W("option", {
									value: "hybrid",
									disabled: !F(Y).languages.find((e) => e.code === F(Y).language)?.engines?.includes("piper")
								}, "Four-provider ensemble · recommended", 8, tl),
								W("option", {
									value: "modern",
									disabled: !F(Y).languages.find((e) => e.code === F(Y).language)?.engines?.some((e) => e !== "piper")
								}, "Modern only · no Piper", 8, nl),
								W("option", {
									value: "piper",
									disabled: !F(Y).languages.find((e) => e.code === F(Y).language)?.engines?.includes("piper")
								}, "Piper only · legacy", 8, rl)
							], 8, el), [[es, F(Y).ttsMode]]),
							d[69] ||= W("small", null, "Models download once and stay cached.", -1)
						])
					]),
					W("div", il, [F(Y).session.safe_word ? (H(), U("button", {
						key: 1,
						type: "button",
						class: "button danger",
						disabled: F(X)("session"),
						onClick: d[6] ||= (...e) => F(zs) && F(zs)(...e)
					}, k(F(X)("session") ? "Stopping…" : F(Y).training.running ? "Stop session + training" : "Stop session"), 9, ol)) : (H(), U("button", {
						key: 0,
						type: "button",
						class: "button primary",
						disabled: F(X)("session") || !F(Y).phrase.trim(),
						onClick: d[5] ||= (...e) => F(Rs) && F(Rs)(...e)
					}, k(F(X)("session") ? "Starting…" : "Start session"), 9, al)), W("button", {
						type: "button",
						disabled: !F(Y).phrase.trim(),
						onClick: d[7] ||= (...e) => F(Bs) && F(Bs)(...e)
					}, "System preview", 8, sl)])
				]),
				W("section", cl, [
					W("header", ll, [
						d[70] ||= W("div", { class: "number" }, "2", -1),
						d[71] ||= W("div", null, [W("h3", null, "Train wake word"), W("p", null, "Personal positives and reviewed false-wake negatives are automatically included.")], -1),
						W("span", { class: O(["pill", p.value.tone]) }, k(p.value.text), 3)
					]),
					W("div", ul, [
						W("article", null, [d[72] ||= W("span", null, "Positive samples", -1), W("strong", null, k(F(Ds)), 1)]),
						W("article", null, [d[73] ||= W("span", null, "Negative samples", -1), W("strong", null, k(F(Os)), 1)]),
						d[74] ||= W("article", null, [W("span", null, "Training format"), W("strong", { class: "format-value" }, "16 kHz · mono · WAV")], -1)
					]),
					W("div", dl, [
						W("div", fl, [
							W("button", {
								type: "button",
								class: O(["model-choice", { active: F(Y).trainMicroWakeWord }]),
								"aria-pressed": F(Y).trainMicroWakeWord,
								onClick: d[8] ||= (e) => F(Y).trainMicroWakeWord = !F(Y).trainMicroWakeWord
							}, [...d[75] ||= [
								W("i", null, "MWW", -1),
								W("span", null, [W("strong", null, "MicroWakeWord"), W("small", null, "TFLite for ESP32 satellites and ESPHome.")], -1),
								W("b", null, "✓", -1)
							]], 10, pl),
							W("button", {
								type: "button",
								class: O(["model-choice", { active: F(Y).trainOpenWakeWord }]),
								"aria-pressed": F(Y).trainOpenWakeWord,
								onClick: d[9] ||= (e) => F(Y).trainOpenWakeWord = !F(Y).trainOpenWakeWord
							}, [...d[76] ||= [
								W("i", null, "OWW", -1),
								W("span", null, [W("strong", null, "openWakeWord"), W("small", null, "ONNX for satellites with OWW support.")], -1),
								W("b", null, "✓", -1)
							]], 10, ml),
							W("button", {
								type: "button",
								class: O(["model-choice", { active: y.value }]),
								"aria-pressed": y.value,
								onClick: re
							}, [...d[77] ||= [
								W("i", null, "NWW", -1),
								W("span", null, [W("strong", null, "NanoWakeWord"), W("small", null, "ONNX with selectable CNN and GRU builds.")], -1),
								W("b", null, "✓", -1)
							]], 10, hl)
						]),
						y.value ? (H(), U("div", gl, [W("div", _l, [d[78] ||= W("div", null, [W("strong", null, "NanoWakeWord architectures"), W("small", null, "Select either architecture or train both.")], -1), W("span", null, k(F(Y).trainNanoWakeWordCnn && F(Y).trainNanoWakeWordGru ? "2 selected" : "1 selected"), 1)]), W("div", vl, [W("button", {
							type: "button",
							class: O(["architecture-choice", { active: F(Y).trainNanoWakeWordCnn }]),
							"aria-pressed": F(Y).trainNanoWakeWordCnn,
							onClick: d[10] ||= (e) => F(Y).trainNanoWakeWordCnn = !F(Y).trainNanoWakeWordCnn
						}, [...d[79] ||= [
							W("i", null, "CNN", -1),
							W("span", null, [W("strong", null, "CNN"), W("small", null, "Recommended default with stronger recall.")], -1),
							W("b", null, "✓", -1)
						]], 10, yl), W("button", {
							type: "button",
							class: O(["architecture-choice", { active: F(Y).trainNanoWakeWordGru }]),
							"aria-pressed": F(Y).trainNanoWakeWordGru,
							onClick: d[11] ||= (e) => F(Y).trainNanoWakeWordGru = !F(Y).trainNanoWakeWordGru
						}, [...d[80] ||= [
							W("i", null, "GRU", -1),
							W("span", null, [W("strong", null, "GRU"), W("small", null, "Recurrent model tuned for fewer false triggers.")], -1),
							W("b", null, "✓", -1)
						]], 10, bl)])])) : K("", !0),
						x.value.length ? (H(), U("section", xl, [
							W("header", Sl, [
								d[81] ||= W("div", { class: "hard-negative-icon" }, "−", -1),
								d[82] ||= W("div", null, [
									W("span", { class: "eyebrow" }, "Optional precision tuning"),
									W("strong", null, "Hard negative training"),
									W("small", null, "Teach the selected models which similar-sounding phrases must not wake the assistant.")
								], -1),
								W("b", null, k(ie(F(Y).generatedNegativePhrases) ? `${ie(F(Y).generatedNegativePhrases)} phrase${ie(F(Y).generatedNegativePhrases) === 1 ? "" : "s"}` : "Optional"), 1)
							]),
							W("div", Cl, [d[83] ||= W("span", null, "Applied to", -1), (H(), U(V, null, R([
								"MWW",
								"OWW",
								"NWW"
							], (e) => W("i", {
								key: e,
								class: O({ active: x.value.includes(e) })
							}, k(e), 3)), 64))]),
							W("label", wl, [
								d[84] ||= W("span", null, "Phrases to reject", -1),
								L(W("textarea", {
									"onUpdate:modelValue": d[12] ||= (e) => F(Y).generatedNegativePhrases = e,
									rows: "4",
									placeholder: "hey later\nhey waiter\nokay tater"
								}, null, 512), [[Zo, F(Y).generatedNegativePhrases]]),
								d[85] ||= W("small", null, "One phrase per line. Each selected engine synthesizes and validates these near-misses alongside reviewed recordings and its broad negative data.", -1)
							]),
							d[86] ||= W("footer", null, [W("span", null, "Unchanged phrases reuse their cached audio on later runs."), W("strong", null, "The actual wake phrase is ignored automatically.")], -1)
						])) : K("", !0)
					]),
					!F(Y).training.running && F(Y).training.summary?.models?.length ? (H(), U("section", Tl, [W("header", null, [
						W("div", { class: O(["summary-mark", F(Y).training.summary.tone]) }, k(F(Y).training.summary.tone === "success" ? "✓" : F(Y).training.summary.tone === "error" ? "×" : "!"), 3),
						W("div", null, [
							d[87] ||= W("span", { class: "eyebrow" }, "Last completed run", -1),
							W("h4", null, k(F(Y).training.summary.wake_word), 1),
							W("p", null, [fa(k(F(Y).training.summary.message), 1), F(Y).training.summary.completed_at ? (H(), U(V, { key: 0 }, [fa(" · " + k(F(mc)(F(Y).training.summary.completed_at)), 1)], 64)) : K("", !0)])
						]),
						W("span", { class: O(["pill", F(Y).training.summary.tone]) }, k(F(Y).training.summary.overall), 3)
					]), W("div", El, [(H(!0), U(V, null, R(F(Y).training.summary.models, (e) => (H(), U("article", {
						key: e.id,
						class: O(e.tone)
					}, [
						W("header", null, [W("div", null, [W("span", null, k(e.id.replaceAll("_", " ")), 1), W("strong", null, k(e.label), 1)]), W("b", null, k(e.rating), 1)]),
						W("p", null, k(e.message), 1),
						e.metrics?.length ? (H(), U("div", Dl, [(H(!0), U(V, null, R(e.metrics, (e) => (H(), U("span", { key: `${e.label}-${e.value}` }, [W("small", null, k(e.label), 1), W("strong", null, k(e.value), 1)]))), 128))])) : K("", !0)
					], 2))), 128))])])) : K("", !0),
					W("div", Ol, [
						W("button", {
							type: "button",
							class: "button primary large",
							disabled: !F(Y).session.safe_word || F(Y).training.running || F(X)("training-start"),
							onClick: d[13] ||= (...e) => F(cc) && F(cc)(...e)
						}, k(F(Y).training.running ? "Training in progress" : "Start training"), 9, kl),
						g.value ? (H(), U("button", {
							key: 0,
							type: "button",
							disabled: F(Y).training.running || F(X)("oww-retry"),
							onClick: d[14] ||= (e) => F(lc)(String(g.value.key || ""))
						}, k(F(X)("oww-retry") ? "Starting OWW…" : "Retry OWW only"), 9, Al)) : K("", !0),
						_.value ? (H(), U("button", {
							key: 1,
							type: "button",
							disabled: F(Y).training.running || F(X)("nww-revalidate"),
							onClick: d[15] ||= (e) => F(uc)(String(_.value.id || "").replace("nano_", ""), String(F(Y).session.safe_word || ""))
						}, k(F(X)("nww-revalidate") ? "Checking NWW…" : `Revalidate ${String(_.value.label || "NWW")} candidate`), 9, jl)) : K("", !0)
					]),
					W("footer", Ml, [d[88] ||= W("span", null, "Training opens the console automatically and continues if the window is closed.", -1), W("button", {
						type: "button",
						disabled: !F(js),
						onClick: d[16] ||= (e) => F(Y).consoleOpen = !0
					}, "Open console", 8, Nl)])
				])
			], 64)) : F(Y).activeView === "auto" ? (H(), U(V, { key: 1 }, [
				W("section", Pl, [d[90] ||= W("div", null, [
					W("span", { class: "eyebrow" }, "False-positive loop"),
					W("h2", null, "Auto Training"),
					W("p", null, "Transcribe captures, sort negatives, recover close misses, retrain on schedule, and publish through Tater.")
				], -1), W("span", { class: O(["pill hero-pill", m.value.tone]) }, k(m.value.text), 3)]),
				W("section", Fl, [
					d[100] ||= W("header", { class: "panel-head" }, [W("div", { class: "number" }, "1"), W("div", null, [W("h3", null, "Review rules"), W("p", null, "Conservative local STT keeps uncertain clips in the manual inbox.")])], -1),
					W("div", Il, [
						W("label", null, [L(W("input", {
							"onUpdate:modelValue": d[17] ||= (e) => F(Y).autoForm.enabled = e,
							type: "checkbox"
						}, null, 512), [[Qo, F(Y).autoForm.enabled]]), d[91] ||= W("span", null, [W("strong", null, "Enable Auto Training"), W("small", null, "Queue eligible wake triggers for local transcription.")], -1)]),
						W("label", null, [L(W("input", {
							"onUpdate:modelValue": d[18] ||= (e) => F(Y).autoForm.delete_confirmed_wakes = e,
							type: "checkbox"
						}, null, 512), [[Qo, F(Y).autoForm.delete_confirmed_wakes]]), d[92] ||= W("span", null, [W("strong", null, "Delete confirmed good wakes"), W("small", null, "Remove normal triggers when STT confirms the phrase.")], -1)]),
						W("label", null, [L(W("input", {
							"onUpdate:modelValue": d[19] ||= (e) => F(Y).autoForm.promote_close_misses = e,
							type: "checkbox"
						}, null, 512), [[Qo, F(Y).autoForm.promote_close_misses]]), d[93] ||= W("span", null, [W("strong", null, "Promote confirmed close misses"), W("small", null, "Move verified close misses into positive samples.")], -1)])
					]),
					W("div", Ll, [
						W("label", Rl, [d[94] ||= W("span", null, "Wake phrase", -1), L(W("input", {
							"onUpdate:modelValue": d[20] ||= (e) => F(Y).autoForm.wake_phrase = e,
							type: "text"
						}, null, 512), [[Zo, F(Y).autoForm.wake_phrase]])]),
						W("label", zl, [d[95] ||= W("span", null, "STT language", -1), L(W("input", {
							"onUpdate:modelValue": d[21] ||= (e) => F(Y).autoForm.language = e,
							type: "text"
						}, null, 512), [[Zo, F(Y).autoForm.language]])]),
						String(F(Y).autoForm.language).toLowerCase().startsWith("en") ? (H(), U("label", Bl, [
							d[96] ||= W("span", null, "English accent emphasis", -1),
							L(W("select", { "onUpdate:modelValue": d[22] ||= (e) => F(Y).autoForm.english_accent = e }, [(H(!0), U(V, null, R(F(Y).englishAccents, (e) => (H(), U("option", {
								key: e.code,
								value: e.code
							}, k(e.label), 9, Vl))), 128))], 512), [[es, F(Y).autoForm.english_accent]]),
							d[97] ||= W("small", null, "Used when Auto Training needs to regenerate English TTS.", -1)
						])) : K("", !0),
						W("label", Hl, [
							d[98] ||= W("span", null, "STT engine", -1),
							L(W("select", { "onUpdate:modelValue": d[23] ||= (e) => F(Y).autoForm.stt_engine = e }, [(H(!0), U(V, null, R(F(Ps), (e) => (H(), U("option", {
								key: e.id || e.value,
								value: e.id || e.value
							}, k(e.label || e.name || e.id), 9, Ul))), 128))], 512), [[es, F(Y).autoForm.stt_engine]]),
							W("small", null, k(F(Ps).find((e) => (e.id || e.value) === F(Y).autoForm.stt_engine)?.description || "Runs locally on this trainer."), 1)
						]),
						W("label", Wl, [d[99] ||= W("span", null, "Minimum transcript characters", -1), L(W("input", {
							"onUpdate:modelValue": d[24] ||= (e) => F(Y).autoForm.minimum_transcript_chars = e,
							min: "1",
							max: "100",
							type: "number"
						}, null, 512), [[
							Zo,
							F(Y).autoForm.minimum_transcript_chars,
							void 0,
							{ number: !0 }
						]])])
					])
				]),
				W("section", Gl, [
					d[120] ||= W("header", { class: "panel-head" }, [W("div", { class: "number" }, "2"), W("div", null, [W("h3", null, "Training schedule"), W("p", null, "A run starts only after enough newly reviewed negatives accumulate.")])], -1),
					W("div", Kl, [W("label", ql, [d[102] ||= W("span", null, "Run training", -1), L(W("select", { "onUpdate:modelValue": d[25] ||= (e) => F(Y).autoForm.schedule_hours = e }, [...d[101] ||= [
						W("option", { value: 0 }, "Manually only", -1),
						W("option", { value: 6 }, "Every 6 hours", -1),
						W("option", { value: 12 }, "Every 12 hours", -1),
						W("option", { value: 24 }, "Every day", -1),
						W("option", { value: 48 }, "Every 2 days", -1),
						W("option", { value: 168 }, "Every week", -1)
					]], 512), [[
						es,
						F(Y).autoForm.schedule_hours,
						void 0,
						{ number: !0 }
					]])]), W("label", Jl, [d[103] ||= W("span", null, "Minimum new negatives", -1), L(W("input", {
						"onUpdate:modelValue": d[26] ||= (e) => F(Y).autoForm.minimum_new_negatives = e,
						min: "1",
						max: "10000",
						type: "number"
					}, null, 512), [[
						Zo,
						F(Y).autoForm.minimum_new_negatives,
						void 0,
						{ number: !0 }
					]])])]),
					W("div", Yl, [
						W("div", Xl, [
							W("button", {
								type: "button",
								class: O(["model-choice", { active: F(Y).autoForm.train_microwakeword }]),
								"aria-pressed": F(Y).autoForm.train_microwakeword,
								onClick: d[27] ||= (e) => F(Y).autoForm.train_microwakeword = !F(Y).autoForm.train_microwakeword
							}, [...d[104] ||= [
								W("i", null, "MWW", -1),
								W("span", null, [W("strong", null, "MicroWakeWord"), W("small", null, "Refresh the ESP32 and ESPHome model.")], -1),
								W("b", null, "✓", -1)
							]], 10, Zl),
							W("button", {
								type: "button",
								class: O(["model-choice", { active: F(Y).autoForm.train_openwakeword }]),
								"aria-pressed": F(Y).autoForm.train_openwakeword,
								onClick: d[28] ||= (e) => F(Y).autoForm.train_openwakeword = !F(Y).autoForm.train_openwakeword
							}, [...d[105] ||= [
								W("i", null, "OWW", -1),
								W("span", null, [W("strong", null, "openWakeWord"), W("small", null, "Refresh the openWakeWord ONNX model.")], -1),
								W("b", null, "✓", -1)
							]], 10, Ql),
							W("button", {
								type: "button",
								class: O(["model-choice", { active: b.value }]),
								"aria-pressed": b.value,
								onClick: E
							}, [...d[106] ||= [
								W("i", null, "NWW", -1),
								W("span", null, [W("strong", null, "NanoWakeWord"), W("small", null, "Refresh selected CNN and GRU models.")], -1),
								W("b", null, "✓", -1)
							]], 10, $l)
						]),
						b.value ? (H(), U("div", eu, [W("div", tu, [d[107] ||= W("div", null, [W("strong", null, "NanoWakeWord architectures"), W("small", null, "Select either architecture or retrain both.")], -1), W("span", null, k(F(Y).autoForm.train_nanowakeword_cnn && F(Y).autoForm.train_nanowakeword_gru ? "2 selected" : "1 selected"), 1)]), W("div", nu, [W("button", {
							type: "button",
							class: O(["architecture-choice", { active: F(Y).autoForm.train_nanowakeword_cnn }]),
							"aria-pressed": F(Y).autoForm.train_nanowakeword_cnn,
							onClick: d[29] ||= (e) => F(Y).autoForm.train_nanowakeword_cnn = !F(Y).autoForm.train_nanowakeword_cnn
						}, [...d[108] ||= [
							W("i", null, "CNN", -1),
							W("span", null, [W("strong", null, "CNN"), W("small", null, "Recommended default with stronger recall.")], -1),
							W("b", null, "✓", -1)
						]], 10, ru), W("button", {
							type: "button",
							class: O(["architecture-choice", { active: F(Y).autoForm.train_nanowakeword_gru }]),
							"aria-pressed": F(Y).autoForm.train_nanowakeword_gru,
							onClick: d[30] ||= (e) => F(Y).autoForm.train_nanowakeword_gru = !F(Y).autoForm.train_nanowakeword_gru
						}, [...d[109] ||= [
							W("i", null, "GRU", -1),
							W("span", null, [W("strong", null, "GRU"), W("small", null, "Recurrent model tuned for fewer false triggers.")], -1),
							W("b", null, "✓", -1)
						]], 10, iu)])])) : K("", !0),
						S.value.length ? (H(), U("section", au, [
							W("header", ou, [
								d[110] ||= W("div", { class: "hard-negative-icon" }, "−", -1),
								d[111] ||= W("div", null, [
									W("span", { class: "eyebrow" }, "Optional precision tuning"),
									W("strong", null, "Hard negative training"),
									W("small", null, "Keep near-miss protection consistent whenever Auto Training refreshes a model.")
								], -1),
								W("b", null, k(ie(F(Y).autoForm.generated_negative_phrases) ? `${ie(F(Y).autoForm.generated_negative_phrases)} phrase${ie(F(Y).autoForm.generated_negative_phrases) === 1 ? "" : "s"}` : "Optional"), 1)
							]),
							W("div", su, [d[112] ||= W("span", null, "Applied to", -1), (H(), U(V, null, R([
								"MWW",
								"OWW",
								"NWW"
							], (e) => W("i", {
								key: e,
								class: O({ active: S.value.includes(e) })
							}, k(e), 3)), 64))]),
							W("label", cu, [
								d[113] ||= W("span", null, "Phrases to reject", -1),
								L(W("textarea", {
									"onUpdate:modelValue": d[31] ||= (e) => F(Y).autoForm.generated_negative_phrases = e,
									rows: "4",
									placeholder: "hey later\nhey waiter\nokay tater"
								}, null, 512), [[Zo, F(Y).autoForm.generated_negative_phrases]]),
								d[114] ||= W("small", null, "One phrase per line. Saved with the schedule and synthesized for every selected model.", -1)
							]),
							d[115] ||= W("footer", null, [W("span", null, "Reviewed false wakes still receive the strongest model weight."), W("strong", null, "The actual wake phrase is ignored automatically.")], -1)
						])) : K("", !0)
					]),
					!F(Y).training.running && F(Y).training.summary?.models?.length ? (H(), U("section", lu, [W("header", null, [
						W("div", { class: O(["summary-mark", F(Y).training.summary.tone]) }, k(F(Y).training.summary.tone === "success" ? "✓" : F(Y).training.summary.tone === "error" ? "×" : "!"), 3),
						W("div", null, [
							d[116] ||= W("span", { class: "eyebrow" }, "Last completed run", -1),
							W("h4", null, k(F(Y).training.summary.wake_word), 1),
							W("p", null, [fa(k(F(Y).training.summary.message), 1), F(Y).training.summary.completed_at ? (H(), U(V, { key: 0 }, [fa(" · " + k(F(mc)(F(Y).training.summary.completed_at)), 1)], 64)) : K("", !0)])
						]),
						W("span", { class: O(["pill", F(Y).training.summary.tone]) }, k(F(Y).training.summary.overall), 3)
					]), W("div", uu, [(H(!0), U(V, null, R(F(Y).training.summary.models, (e) => (H(), U("article", {
						key: `auto-${e.id}`,
						class: O(e.tone)
					}, [
						W("header", null, [W("div", null, [W("span", null, k(e.id.replaceAll("_", " ")), 1), W("strong", null, k(e.label), 1)]), W("b", null, k(e.rating), 1)]),
						W("p", null, k(e.message), 1),
						e.metrics?.length ? (H(), U("div", du, [(H(!0), U(V, null, R(e.metrics, (e) => (H(), U("span", { key: `${e.label}-${e.value}` }, [W("small", null, k(e.label), 1), W("strong", null, k(e.value), 1)]))), 128))])) : K("", !0)
					], 2))), 128))])])) : K("", !0),
					W("div", fu, [
						W("article", null, [d[117] ||= W("span", null, "Pending negatives", -1), W("strong", null, k(Number(u.value.pending_negative_count || 0)), 1)]),
						W("article", null, [d[118] ||= W("span", null, "Next check", -1), W("strong", pu, k(u.value.next_run_at ? F(mc)(u.value.next_run_at) : "Manual"), 1)]),
						W("article", null, [d[119] ||= W("span", null, "Last training", -1), W("strong", mu, k(u.value.last_train_finished_at ? F(mc)(u.value.last_train_finished_at) : "Never"), 1)])
					])
				]),
				W("section", hu, [
					d[124] ||= W("header", { class: "panel-head" }, [W("div", { class: "number" }, "3"), W("div", null, [W("h3", null, "Publish to Tater"), W("p", null, "Securely activate successful models across every connected satellite.")])], -1),
					W("div", gu, [W("label", _u, [
						d[121] ||= W("span", null, "Trainer public URL", -1),
						L(W("input", {
							"onUpdate:modelValue": d[32] ||= (e) => F(Y).autoForm.advertised_base_url = e,
							type: "text",
							placeholder: "Auto-detect LAN address"
						}, null, 512), [[Zo, F(Y).autoForm.advertised_base_url]]),
						W("small", null, k(F(Y).autoForm.advertised_base_url ? `Configured: ${F(Y).autoForm.advertised_base_url}` : `Detected: ${F(Y).auto.advertised_base_url || "unavailable"}`), 1)
					]), W("label", vu, [d[122] ||= W("span", null, "Tater URL", -1), L(W("input", {
						"onUpdate:modelValue": d[33] ||= (e) => F(Y).autoForm.tater_url = e,
						type: "text"
					}, null, 512), [[Zo, F(Y).autoForm.tater_url]])])]),
					W("div", yu, [
						W("span", { class: O(["pill", F(Ns) ? "success" : "warning"]) }, k(F(Ns) ? `Linked${F(Y).auto.trainer_link?.tater_name ? ` · ${F(Y).auto.trainer_link.tater_name}` : ""}` : "Not linked"), 3),
						W("button", {
							type: "button",
							class: "button primary",
							disabled: F(X)("auto"),
							onClick: ae
						}, k(F(Ns) ? "Relink Tater" : "Link Tater"), 9, bu),
						F(Ns) ? (H(), U("button", {
							key: 0,
							type: "button",
							class: "button danger",
							disabled: F(X)("auto"),
							onClick: d[34] ||= (...e) => F(nc) && F(nc)(...e)
						}, "Unlink", 8, xu)) : K("", !0)
					]),
					W("div", Su, [W("label", null, [L(W("input", {
						"onUpdate:modelValue": d[35] ||= (e) => F(Y).autoForm.notify_satellites = e,
						type: "checkbox"
					}, null, 512), [[Qo, F(Y).autoForm.notify_satellites]]), d[123] ||= W("span", null, [W("strong", null, "Activate after successful training"), W("small", null, "Tater applies the new word globally.")], -1)])])
				]),
				W("section", Cu, [W("div", wu, [
					W("button", {
						type: "button",
						class: "button primary",
						disabled: F(X)("auto"),
						onClick: d[36] ||= (...e) => F($s) && F($s)(...e)
					}, "Save Auto Training", 8, Tu),
					W("button", {
						type: "button",
						disabled: F(X)("auto"),
						onClick: d[37] ||= (e) => F(ec)("review_now")
					}, "Review inbox now", 8, Eu),
					W("button", {
						type: "button",
						disabled: F(X)("auto") || F(Y).training.running,
						onClick: d[38] ||= (e) => F(ec)("train_now")
					}, "Train now", 8, Du),
					W("button", {
						type: "button",
						disabled: F(X)("auto") || !F(Ns),
						onClick: d[39] ||= (e) => F(ec)("notify_now")
					}, "Publish current word", 8, Ou)
				]), W("p", ku, k(f.value), 1)])
			], 64)) : F(Y).activeView === "captured" ? (H(), U(V, { key: 2 }, [
				W("section", Au, [d[125] ||= W("div", null, [
					W("span", { class: "eyebrow" }, "Capture review"),
					W("h2", null, "Captured Audio"),
					W("p", null, "Listen to clips from your satellites and turn every real-world event into a better model.")
				], -1), W("span", { class: O(["pill hero-pill", F(Y).captured.captured_count ? "warning" : ""]) }, k(F(Y).captured.captured_count ? `${F(Y).captured.captured_count} waiting` : "Inbox idle"), 3)]),
				W("section", ju, [W("header", Mu, [
					d[126] ||= W("div", { class: "number" }, "1", -1),
					d[127] ||= W("div", null, [W("h3", null, "Review queue"), W("p", null, "Approve good phrases, keep false positives as negatives, or discard noise.")], -1),
					W("button", {
						type: "button",
						disabled: F(X)("captured"),
						onClick: d[40] ||= (e) => F(Us)()
					}, k(F(X)("captured") ? "Refreshing…" : "Refresh inbox"), 9, Nu)
				]), W("div", Pu, [
					W("article", null, [d[128] ||= W("span", null, "Inbox", -1), W("strong", null, k(F(Y).captured.captured_count), 1)]),
					W("article", null, [d[129] ||= W("span", null, "Reviewed negatives", -1), W("strong", null, k(F(Os)), 1)]),
					W("article", null, [d[130] ||= W("span", null, "Personal samples", -1), W("strong", null, k(F(Ds)), 1)])
				])]),
				W("section", Fu, [d[133] ||= W("header", { class: "panel-head" }, [W("div", { class: "number" }, "2"), W("div", null, [W("h3", null, "Listen + sort"), W("p", null, "Metadata remains visible so borderline detections are easy to understand.")])], -1), F(Y).captured.items?.length ? (H(), U("div", Lu, [(H(!0), U(V, null, R(F(Y).captured.items, (e) => (H(), U("article", {
					key: e.saved_as,
					class: "audio-card"
				}, [
					W("header", null, [W("div", null, [W("strong", null, k(e.original_name || e.saved_as), 1), W("small", null, k(F(mc)(e.captured_at || e.received_at)) + " " + k(e.message || ""), 1)]), W("span", { class: O(["pill", F(_c)(e).tone]) }, k(F(_c)(e).label), 3)]),
					D(e).length ? (H(), U("div", Ru, [(H(!0), U(V, null, R(D(e), (e) => (H(), U("span", { key: e }, k(e), 1))), 128))])) : K("", !0),
					e.transcript ? (H(), U("div", zu, [d[131] ||= W("b", null, "STT", -1), fa(" " + k(e.transcript), 1)])) : K("", !0),
					e.auto_review_guided_transcript ? (H(), U("div", Bu, [d[132] ||= W("b", null, "Guided wake check", -1), fa(" " + k(e.auto_review_guided_transcript), 1)])) : K("", !0),
					W("audio", {
						controls: "",
						preload: "none",
						src: F(vc)(e, "captured")
					}, null, 8, Vu),
					W("footer", null, [W("span", null, k(e.saved_as) + " · " + k(F(gc)(e.final_format)), 1), W("div", null, [
						W("button", {
							type: "button",
							disabled: F(X)("review"),
							onClick: (t) => F(qs)(e, "approve_personal")
						}, "Add positive", 8, Hu),
						W("button", {
							type: "button",
							disabled: F(X)("review"),
							onClick: (t) => F(qs)(e, "mark_negative")
						}, "Mark negative", 8, Uu),
						W("button", {
							type: "button",
							class: "button danger ghost",
							disabled: F(X)("review"),
							onClick: (t) => F(qs)(e, "discard")
						}, "Discard", 8, Wu)
					])])
				]))), 128))])) : (H(), U("div", Iu, "No captured audio yet. Clips sent by satellites will appear here."))])
			], 64)) : F(Y).activeView === "samples" ? (H(), U(V, { key: 3 }, [
				W("section", Gu, [d[134] ||= W("div", null, [
					W("span", { class: "eyebrow" }, "Sample library"),
					W("h2", null, "Current Training Samples"),
					W("p", null, "Audit positives and negatives, trim recordings precisely, and import seed audio.")
				], -1), W("span", Ku, k(F(Ds) + F(Os)) + " total", 1)]),
				W("section", qu, [
					W("header", Ju, [
						d[137] ||= W("div", { class: "number" }, "1", -1),
						d[138] ||= W("div", null, [W("h3", null, "Saved samples"), W("p", null, "Personal clips are positives. Negative clips are false wakes and hard negatives.")], -1),
						W("div", Yu, [W("button", {
							type: "button",
							class: O({ active: F(Y).sampleBucket === "personal" }),
							onClick: d[41] ||= (e) => ne("personal")
						}, [d[135] ||= fa("Personal ", -1), W("b", null, k(F(Ds)), 1)], 2), W("button", {
							type: "button",
							class: O({ active: F(Y).sampleBucket === "negative" }),
							onClick: d[42] ||= (e) => ne("negative")
						}, [d[136] ||= fa("Negative ", -1), W("b", null, k(F(Os)), 1)], 2)])
					]),
					W("div", Xu, [
						W("button", {
							type: "button",
							disabled: F(X)("samples"),
							onClick: d[43] ||= (e) => F(Hs)()
						}, "Refresh", 8, Zu),
						W("button", {
							type: "button",
							class: "button danger ghost",
							disabled: F(X)("review") || F(Ds) === 0,
							onClick: d[44] ||= (e) => F(Xs)("personal")
						}, "Clear positives", 8, Qu),
						W("button", {
							type: "button",
							class: "button danger ghost",
							disabled: F(X)("review") || F(Os) === 0,
							onClick: d[45] ||= (e) => F(Xs)("negative")
						}, "Clear negatives", 8, $u)
					]),
					F(Ms).length ? (H(), U("div", td, [(H(!0), U(V, null, R(c.value, (e) => (H(), U("article", {
						key: e.saved_as,
						class: "audio-card"
					}, [
						W("header", null, [W("div", null, [W("strong", null, k(e.saved_as), 1), W("small", null, k(ce(e)), 1)]), W("div", nd, [e.trimmed ? (H(), U("span", rd, "Trimmed")) : K("", !0), W("span", { class: O(["pill", F(Y).sampleBucket === "personal" ? "success" : "error"]) }, k(F(Y).sampleBucket === "personal" ? "Positive" : "Negative"), 3)])]),
						e.transcript ? (H(), U("div", id, [d[139] ||= W("b", null, "STT", -1), fa(" " + k(e.transcript), 1)])) : K("", !0),
						e.auto_review_guided_transcript ? (H(), U("div", ad, [d[140] ||= W("b", null, "Guided wake check", -1), fa(" " + k(e.auto_review_guided_transcript), 1)])) : K("", !0),
						W("audio", {
							controls: "",
							preload: "none",
							src: F(vc)(e, F(Y).sampleBucket)
						}, null, 8, od),
						W("footer", null, [W("span", null, k(F(gc)(e.final_format)), 1), W("div", null, [
							W("button", {
								type: "button",
								onClick: (t) => T(e, F(Y).sampleBucket)
							}, "Trim", 8, sd),
							e.trimmed ? (H(), U("button", {
								key: 0,
								type: "button",
								onClick: (t) => F(Ys)(e, F(Y).sampleBucket)
							}, "Revert", 8, cd)) : K("", !0),
							W("button", {
								type: "button",
								class: "button danger ghost",
								disabled: F(X)("review"),
								onClick: (t) => F(Js)(e, F(Y).sampleBucket)
							}, "Remove", 8, ld)
						])])
					]))), 128))])) : (H(), U("div", ed, "No " + k(F(Y).sampleBucket) + " samples saved yet.", 1)),
					l.value > 1 ? (H(), U("div", ud, [
						W("button", {
							type: "button",
							disabled: F(Y).samplePage[F(Y).sampleBucket] === 0,
							onClick: d[46] ||= (e) => F(Y).samplePage[F(Y).sampleBucket]--
						}, "Previous", 8, dd),
						W("span", null, "Page " + k(F(Y).samplePage[F(Y).sampleBucket] + 1) + " of " + k(l.value), 1),
						W("button", {
							type: "button",
							disabled: F(Y).samplePage[F(Y).sampleBucket] >= l.value - 1,
							onClick: d[47] ||= (e) => F(Y).samplePage[F(Y).sampleBucket]++
						}, "Next", 8, fd)
					])) : K("", !0)
				]),
				W("section", pd, [
					d[142] ||= W("header", { class: "panel-head" }, [W("div", { class: "number" }, "2"), W("div", null, [W("h3", null, "Manual sample import"), W("p", null, "Optional seed recordings are normalized to the trainer’s required WAV format.")])], -1),
					W("label", md, [
						W("input", {
							ref_key: "uploadInput",
							ref: t,
							type: "file",
							multiple: "",
							accept: "audio/*,.wav,.mp3,.m4a,.flac,.ogg,.aac,.webm,.opus",
							onChange: d[48] ||= (...e) => F(Ws) && F(Ws)(...e)
						}, null, 544),
						d[141] ||= W("span", null, [W("strong", null, "Choose one or many audio files"), W("small", null, "WAV, MP3, M4A, FLAC, OGG, AAC, OPUS, and WEBM")], -1),
						W("b", null, k(F(Y).selectedFiles.length ? `${F(Y).selectedFiles.length} selected` : "Browse"), 1)
					]),
					W("button", {
						type: "button",
						class: "button primary",
						disabled: !F(Y).session.safe_word || !F(Y).selectedFiles.length || F(X)("upload"),
						onClick: d[49] ||= (e) => F(Ks)(t.value)
					}, k(F(X)("upload") ? "Uploading…" : "Upload selected samples"), 9, hd),
					W("div", gd, [
						W("div", null, [W("strong", null, k(F(Y).uploadLabel), 1), W("span", null, k(F(Y).uploadProgress) + "%", 1)]),
						W("div", _d, [W("i", { style: fe({ width: `${F(Y).uploadProgress}%` }) }, null, 4)]),
						W("small", null, k(F(Y).uploadDetail), 1)
					])
				])
			], 64)) : F(Y).activeView === "data" ? (H(), U(V, { key: 4 }, [
				W("section", vd, [d[143] ||= W("div", null, [
					W("span", { class: "eyebrow" }, "Local storage"),
					W("h2", null, "Data Management"),
					W("p", null, "See exactly what the trainer has downloaded, generated, recorded, and produced.")
				], -1), W("span", yd, k(F(hc)(F(Y).managedData.total_size_bytes)) + " total", 1)]),
				W("section", bd, [
					W("header", xd, [
						d[144] ||= W("div", { class: "number storage-icon" }, "↗", -1),
						d[145] ||= W("div", null, [W("h3", null, "Data folder"), W("p", null, "Put recordings, datasets, model downloads, caches, training environments, and results on any Mac-compatible drive.")], -1),
						F(ws) ? (H(), U("button", {
							key: 0,
							type: "button",
							disabled: F(Y).training.running || F(X)("data") || F(X)("data-delete"),
							onClick: d[50] ||= (...e) => F(ac) && F(ac)(...e)
						}, "Change Folder…", 8, Sd)) : K("", !0)
					]),
					W("div", Cd, [W("div", null, [d[146] ||= W("span", null, "Current location", -1), W("code", null, k(F(Y).managedData.data_directory || "Loading…"), 1)]), F(ws) ? (H(), U("span", wd, "Mac app")) : (H(), U("span", Td, "Open the Mac app to change"))]),
					d[147] ||= W("p", { class: "storage-hint" }, "Changing this folder safely stops the local trainer, copies and verifies the data, then restarts it. Keep an external drive connected whenever you use the trainer.", -1),
					F(Y).training.running ? (H(), U("p", Ed, "Stop the active training session before changing the data folder.")) : K("", !0)
				]),
				W("section", Dd, [
					W("header", Od, [
						d[148] ||= W("div", { class: "number" }, "i", -1),
						d[149] ||= W("div", null, [W("h3", null, "Trainer storage"), W("p", null, "Deleting an item is permanent. Required downloads and generated caches will be rebuilt the next time training needs them.")], -1),
						W("button", {
							type: "button",
							disabled: F(X)("data") || F(X)("data-delete"),
							onClick: d[51] ||= (e) => F(ic)()
						}, k(F(X)("data") ? "Scanning…" : "Refresh sizes"), 9, kd)
					]),
					W("div", Ad, [
						W("article", null, [d[150] ||= W("span", null, "Space used", -1), W("strong", jd, k(F(hc)(F(Y).managedData.total_size_bytes)), 1)]),
						W("article", null, [d[151] ||= W("span", null, "Files", -1), W("strong", null, k(Number(F(Y).managedData.total_file_count || 0).toLocaleString()), 1)]),
						W("article", null, [d[152] ||= W("span", null, "Individual items", -1), W("strong", null, k(F(Y).managedData.items.length), 1)])
					]),
					F(Y).training.running ? (H(), U("p", Md, "Stop the active training session before deleting data.")) : K("", !0)
				]),
				(H(!0), U(V, null, R(v.value, (e, t) => (H(), U("section", {
					key: e.name,
					class: "panel data-panel"
				}, [W("header", Nd, [W("div", Pd, k(t + 1), 1), W("div", null, [W("h3", null, k(e.name), 1), W("p", null, k(e.items.length) + " separately managed item" + k(e.items.length === 1 ? "" : "s"), 1)])]), W("div", Fd, [(H(!0), U(V, null, R(e.items, (e) => (H(), U("article", {
					key: e.id,
					class: O(["data-row", { empty: !e.file_count }])
				}, [
					W("div", Id, [
						W("div", Ld, [W("strong", null, k(e.label), 1), W("code", null, k(e.location), 1)]),
						W("small", null, k(e.description), 1),
						e.rebuild_note ? (H(), U("span", Rd, k(e.rebuild_note), 1)) : K("", !0)
					]),
					W("div", zd, [W("strong", null, k(F(hc)(e.size_bytes)), 1), W("span", null, k(Number(e.file_count || 0).toLocaleString()) + " file" + k(e.file_count === 1 ? "" : "s"), 1)]),
					W("button", {
						type: "button",
						class: "button danger ghost",
						disabled: !e.file_count || F(Y).training.running || F(X)("data") || F(X)("data-delete"),
						onClick: (t) => F(oc)(e)
					}, k(F(X)("data-delete") ? "Please wait…" : "Delete"), 9, Bd)
				], 2))), 128))])]))), 128)),
				!F(X)("data") && !F(Y).managedData.items.length ? (H(), U("section", Vd, "No managed trainer data was found.")) : K("", !0)
			], 64)) : F(Y).activeView === "firmware" ? (H(), U(V, { key: 5 }, [
				W("section", Hd, [d[153] ||= W("div", null, [
					W("span", { class: "eyebrow" }, "Wake-word catalog"),
					W("h2", null, "Trained Wake Words"),
					W("p", null, "Copy a local JSON package URL into Tater to switch every native satellite live.")
				], -1), W("span", { class: O(["pill hero-pill", F(Y).wakeWords.length ? "success" : "warning"]) }, k(F(Y).wakeWords.length ? `${F(Y).wakeWords.length} trained` : "Catalog empty"), 3)]),
				d[158] ||= W("div", { class: "native-notice" }, [W("strong", null, "Tater Native"), W("span", null, "These packages include model metadata and a direct model URL for live satellite updates.")], -1),
				W("section", Ud, [W("header", Wd, [
					d[154] ||= W("div", { class: "number" }, "v1", -1),
					d[155] ||= W("div", null, [W("h3", null, "Published model URLs"), W("p", null, "URLs stay local and are refreshed after each successful run.")], -1),
					W("button", {
						type: "button",
						disabled: F(X)("firmware"),
						onClick: d[52] ||= (e) => F(rc)()
					}, "Refresh", 8, Gd)
				]), F(Y).wakeWords.length ? (H(), U("div", qd, [(H(!0), U(V, null, R(F(Y).wakeWords, (e) => (H(), U("article", { key: e.key || le(e) }, [W("div", null, [
					W("strong", null, k(e.label || e.name || "Trained wake word"), 1),
					le(e) ? (H(), U("a", {
						key: 0,
						href: le(e),
						target: "_blank",
						rel: "noreferrer"
					}, "Tater wake-word bundle · " + k(le(e)), 9, Jd)) : (H(), U("span", Yd, "Bundle URL unavailable")),
					de(e) ? (H(), U("a", {
						key: 2,
						href: de(e),
						target: "_blank",
						rel: "noreferrer"
					}, "MicroWakeWord model · " + k(de(e)), 9, Xd)) : K("", !0),
					pe(e) ? (H(), U("a", {
						key: 3,
						href: pe(e),
						target: "_blank",
						rel: "noreferrer"
					}, "openWakeWord model · " + k(pe(e)), 9, Zd)) : K("", !0),
					(H(!0), U(V, null, R(me(e), (e, t) => (H(), U("a", {
						key: t,
						href: e,
						target: "_blank",
						rel: "noreferrer"
					}, "NanoWakeWord " + k(String(t).toUpperCase()) + " model · " + k(e), 9, Qd))), 128)),
					W("div", $d, [
						(H(!0), U(V, null, R(e.available_engines || [], (e) => (H(), U("span", { key: e }, k(String(e).replaceAll("_", " ")), 1))), 128)),
						e.language ? (H(), U("span", ef, k(e.language), 1)) : K("", !0),
						e.trained_at ? (H(), U("span", tf, k(F(mc)(e.trained_at)), 1)) : K("", !0),
						e.recall === void 0 ? K("", !0) : (H(), U("span", nf, "recall " + k(e.recall), 1))
					])
				]), W("button", {
					type: "button",
					disabled: !le(e),
					onClick: (t) => F(sc)(le(e))
				}, "Copy bundle URL", 8, rf)]))), 128))])) : (H(), U("div", Kd, "Train a wake word and its package will appear here."))]),
				d[159] ||= W("div", { class: "native-notice esphome-notice" }, [W("strong", null, "ESPHome"), W("span", null, "Strict micro_wake_word manifest without Tater Native or calibration extensions.")], -1),
				W("section", af, [d[157] ||= W("header", { class: "panel-head" }, [W("div", { class: "number" }, "ESP"), W("div", null, [W("h3", null, "ESPHome JSON"), W("p", null, "Use this URL as the model in an ESPHome micro_wake_word configuration.")])], -1), F(Y).wakeWords.length ? (H(), U("div", sf, [(H(!0), U(V, null, R(F(Y).wakeWords, (e) => (H(), U("article", { key: `esphome-${e.key || ue(e)}` }, [W("div", null, [
					W("strong", null, k(e.label || e.name || "Trained wake word"), 1),
					ue(e) ? (H(), U("a", {
						key: 0,
						href: ue(e),
						target: "_blank",
						rel: "noreferrer"
					}, "ESPHome JSON · " + k(ue(e)), 9, cf)) : (H(), U("span", lf, "ESPHome package URL unavailable")),
					d[156] ||= W("div", { class: "meta-row" }, [W("span", null, "Schema v2"), W("span", null, "Same TFLite model")], -1)
				]), W("button", {
					type: "button",
					disabled: !ue(e),
					onClick: (t) => F(sc)(ue(e))
				}, "Copy ESPHome URL", 8, uf)]))), 128))])) : (H(), U("div", of, "ESPHome links appear after a wake word is trained."))])
			], 64)) : K("", !0)], 64)) : (H(), U("div", Vc, [...d[61] ||= [W("span", { class: "spinner" }, null, -1), W("strong", null, "Connecting to the local trainer…", -1)]]))]),
			(H(), ia(Yn, { to: "body" }, [F(Y).consoleOpen ? (H(), U("div", {
				key: 0,
				class: "modal-backdrop console-backdrop",
				onClick: d[54] ||= os((e) => F(Y).consoleOpen = !1, ["self"])
			}, [W("section", df, [W("header", ff, [d[160] ||= W("div", null, [
				W("span", { class: "eyebrow" }, "Live pipeline"),
				W("h2", null, "Training Console"),
				W("p", null, "Closing this window does not interrupt training.")
			], -1), W("div", pf, [
				r.value ? K("", !0) : (H(), U("button", {
					key: 0,
					type: "button",
					class: "console-follow",
					onClick: ee
				}, "Jump to latest")),
				W("span", { class: O(["pill", p.value.tone]) }, k(p.value.text), 3),
				W("button", {
					type: "button",
					onClick: d[53] ||= (e) => F(Y).consoleOpen = !1
				}, "Close")
			])]), W("pre", {
				ref_key: "consoleLog",
				ref: n,
				class: "console-log",
				onScrollPassive: w
			}, [(H(!0), U(V, null, R(h.value, (e, t) => (H(), U("span", {
				key: `${t}-${e}`,
				class: O(he(e))
			}, k(e), 3))), 128))], 544)])])) : K("", !0)])),
			(H(), ia(Yn, { to: "body" }, [F(Y).taterLinkOpen ? (H(), U("div", {
				key: 0,
				class: "modal-backdrop",
				onClick: d[58] ||= os((e) => F(Y).taterLinkOpen = !1, ["self"])
			}, [W("section", mf, [W("header", hf, [W("div", null, [
				d[161] ||= W("span", { class: "eyebrow" }, "Secure pairing", -1),
				W("h2", null, k(o.value ? "Tater linked" : "Link Tater"), 1),
				W("p", null, k(o.value ? "This trainer can securely publish wake-word updates." : "Enter the short-lived code shown in Tater Voice Settings."), 1)
			]), W("button", {
				type: "button",
				onClick: d[55] ||= (e) => F(Y).taterLinkOpen = !1
			}, "Close")]), o.value ? (H(), U("div", gf, [
				d[162] ||= W("i", null, "✓", -1),
				W("strong", null, "Successfully linked" + k(F(Y).auto.trainer_link?.tater_name ? ` to ${F(Y).auto.trainer_link.tater_name}` : ""), 1),
				d[163] ||= W("span", null, "The private link key is stored locally and is never displayed.", -1)
			])) : (H(), U("div", _f, [
				W("label", vf, [d[164] ||= W("span", null, "Tater address", -1), L(W("input", {
					"onUpdate:modelValue": d[56] ||= (e) => i.value = e,
					type: "text"
				}, null, 512), [[Zo, i.value]])]),
				W("label", yf, [d[165] ||= W("span", null, "Tater pairing code", -1), L(W("input", {
					id: "pairing-code",
					"onUpdate:modelValue": d[57] ||= (e) => a.value = e,
					class: "pairing-code",
					maxlength: "9",
					placeholder: "ABCD-EFGH",
					autocomplete: "off",
					onInput: oe
				}, null, 544), [[Zo, a.value]])]),
				d[166] ||= W("small", null, "In Tater, open Voice Settings → Wake Word Trainer → Link Trainer.", -1),
				W("button", {
					type: "button",
					class: "button primary",
					disabled: F(X)("link"),
					onClick: se
				}, k(F(X)("link") ? "Linking securely…" : "Link Tater"), 9, bf)
			]))])])) : K("", !0)])),
			G(Ac),
			G(eo, { name: "toast" }, {
				default: On(() => [F(Y).toast.message ? (H(), U("div", {
					key: 0,
					class: O(["toast", F(Y).toast.tone]),
					role: "status"
				}, k(F(Y).toast.message), 3)) : K("", !0)]),
				_: 1
			})
		]));
	}
}), wf = document.getElementById("trainer-app");
if (!wf) throw Error("Missing #trainer-app mount point");
fs(Cf).mount(wf);
//#endregion
