"""Canonical Tater wake-word bundle helpers.

The bundle is the only JSON consumed by Tater.  It embeds each engine's
runtime metadata while model binaries remain adjacent downloadable artifacts.
The separate ESPHome manifest is intentionally MicroWakeWord-only.
"""

from __future__ import annotations

import copy
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping
from urllib.parse import quote


BUNDLE_SUFFIX = ".wake-bundle.json"
BUNDLE_SCHEMA_VERSION = 4
ESPHOME_MANIFEST_KEYS = (
    "type",
    "wake_word",
    "author",
    "website",
    "model",
    "trained_languages",
    "version",
    "micro",
)

# A wake bundle is a runtime manifest, not a training report. Detailed quality
# diagnostics stay in the trainer workspace so public bundles remain compact
# and never expose machine-local paths.
MICRO_PUBLIC_KEYS = (
    "type", "wake_word", "label", "author", "website", "model",
    "trained_languages", "version", "model_format", "quantization",
    "sample_rate", "micro", "tater_native", "calibration",
    "model_sha256", "model_size_bytes", "manifest", "manifest_sha256",
)
OPEN_PUBLIC_KEYS = (
    "type", "name", "model_name", "phrase", "created_at", "trained_at",
    "synced_at", "trainer_revision", "metadata", "metadata_sha256",
    "artifacts", "recommended_threshold", "recommended_patience",
    "recommended_confirmation_threshold", "recommended_confirmation_patience",
    "confirmation_required",
    "quality_evaluated", "quality_passed", "quality_status",
)
NANO_PUBLIC_KEYS = (
    "type", "name", "phrase", "created_at", "trained_at", "synced_at",
    "model_type", "architecture", "steps", "layer_size",
    "hard_negative_samples", "quality_retries_used", "model",
    "model_sha256", "model_size_bytes", "artifacts",
    "recommended_threshold", "recommended_patience",
    "quality_summary", "validated_existing_candidate", "seed", "loss_bias",
    "quality_evaluated", "quality_passed", "quality_status",
)
BOUNDARY_PUBLIC_KEYS = (
    "type", "model", "model_sha256", "model_size_bytes", "model_format",
    "quantization", "sample_rate", "threshold", "tensor_arena_size",
    "frontend", "search_before_ms", "search_after_ms", "endpoint_offset_ms",
    "training_strategy", "quality_summary",
)
MAX_BOUNDARY_MODEL_BYTES = 200 * 1024
MAX_BOUNDARY_ARENA_BYTES = 256 * 1024


def _select_nano_default(variants: Mapping[str, Any], current: str = "") -> str:
    """Choose the safest high-recall validated variant with a latency penalty."""
    ranked: list[tuple[tuple[float, ...], str]] = []
    for architecture, variant in variants.items():
        if not isinstance(variant, Mapping):
            continue
        summary = variant.get("quality_summary")
        if not isinstance(summary, Mapping):
            continue
        try:
            recall = float(summary["recall"])
            negative_rate = float(summary["negative_rate"])
            patience = int(variant.get("recommended_patience", 2))
        except (KeyError, TypeError, ValueError):
            continue
        quality_status = str(variant.get("quality_status") or "").strip().lower()
        quality_accepted = float(
            quality_status in {"", "passed"} and variant.get("quality_passed") is not False
        )
        preferred = float(recall >= 0.95 and negative_rate <= 0.05)
        utility = recall - negative_rate - 0.01 * patience
        ranked.append(
            (
                (quality_accepted, preferred, utility, -negative_rate, recall, -patience, float(architecture == "cnn")),
                str(architecture),
            )
        )
    if ranked:
        return max(ranked)[1]
    if current in variants:
        return current
    return "cnn" if "cnn" in variants else next(iter(variants), "")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return value if isinstance(value, dict) else {}


def esphome_manifest(micro_metadata: Mapping[str, Any]) -> dict[str, Any]:
    return {
        key: copy.deepcopy(micro_metadata[key])
        for key in ESPHOME_MANIFEST_KEYS
        if key in micro_metadata
    }


def bundle_path(trained_dir: Path, safe_word: str) -> Path:
    return Path(trained_dir).resolve() / f"{safe_word}{BUNDLE_SUFFIX}"


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _public_fields(metadata: Mapping[str, Any], keys: tuple[str, ...]) -> dict[str, Any]:
    return {key: copy.deepcopy(metadata[key]) for key in keys if key in metadata}


def _sanitized_existing_bundle(existing: Mapping[str, Any]) -> dict[str, Any]:
    """Remove private diagnostics whenever any part of a bundle is rewritten."""
    source = dict(existing) if existing else {}
    bundle = {
        key: copy.deepcopy(source[key])
        for key in ("schema_version", "type", "wake_word", "key", "created_at", "updated_at")
        if key in source
    }
    micro = source.get("micro_wake_word")
    if isinstance(micro, Mapping):
        bundle["micro_wake_word"] = _public_fields(micro, MICRO_PUBLIC_KEYS)
    oww = source.get("open_wake_word")
    if isinstance(oww, Mapping):
        bundle["open_wake_word"] = _public_fields(oww, OPEN_PUBLIC_KEYS)
    nano = source.get("nano_wake_word")
    if isinstance(nano, Mapping):
        variants = nano.get("variants")
        clean_variants: dict[str, Any] = {}
        if isinstance(variants, Mapping):
            for architecture, variant in variants.items():
                if isinstance(variant, Mapping):
                    clean_variants[str(architecture)] = _public_fields(variant, NANO_PUBLIC_KEYS)
        bundle["nano_wake_word"] = {
            "default_architecture": str(nano.get("default_architecture") or ""),
            "variants": clean_variants,
        }
    boundary = source.get("wake_boundary")
    if isinstance(boundary, Mapping):
        bundle["wake_boundary"] = _public_fields(boundary, BOUNDARY_PUBLIC_KEYS)
    return bundle


def _base_bundle(existing: Mapping[str, Any], safe_word: str, phrase: str) -> dict[str, Any]:
    now = _utc_now()
    bundle = _sanitized_existing_bundle(existing)
    bundle.update(
        {
            "schema_version": BUNDLE_SCHEMA_VERSION,
            "type": "tater_wake_word_bundle",
            "wake_word": phrase or str(bundle.get("wake_word") or safe_word.replace("_", " ")),
            "key": safe_word,
            "created_at": str(bundle.get("created_at") or now),
            "updated_at": now,
        }
    )
    return bundle


def _atomic_write(path: Path, payload: Mapping[str, Any]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    temporary.replace(path)
    return path


def load_bundle(trained_dir: Path, safe_word: str) -> dict[str, Any]:
    return read_json(bundle_path(trained_dir, safe_word))


def prune_unreferenced_companion_artifacts(
    trained_dir: Path,
    safe_word: str,
    bundle: Mapping[str, Any],
) -> None:
    """Remove obsolete public metadata/DNN files without touching training data."""
    root = Path(trained_dir).resolve()
    oww = bundle.get("open_wake_word")
    referenced = {
        Path(str(oww.get("metadata") or "")).name
        if isinstance(oww, Mapping) else ""
    }
    nano = bundle.get("nano_wake_word")
    variants = nano.get("variants") if isinstance(nano, Mapping) else None
    if isinstance(variants, Mapping):
        for variant in variants.values():
            if isinstance(variant, Mapping):
                referenced.add(Path(str(variant.get("model") or "")).name)
    boundary = bundle.get("wake_boundary")
    if isinstance(boundary, Mapping):
        referenced.add(Path(str(boundary.get("model") or "")).name)
    candidates = {
        f"{safe_word}.oww.json",
        f"{safe_word}.nww.cnn.json",
        f"{safe_word}.nww.dnn.json",
        f"{safe_word}.nww.gru.json",
        f"{safe_word}.nww.dnn.onnx",
        f"{safe_word}.boundary.tflite",
    }
    for name in candidates - referenced:
        try:
            (root / name).unlink()
        except FileNotFoundError:
            pass


def publish_micro_wake_word(
    *,
    trained_dir: Path,
    safe_word: str,
    phrase: str,
    metadata: Mapping[str, Any],
    model_path: Path,
) -> Path:
    model = Path(model_path).resolve()
    if not model.is_file():
        raise RuntimeError(f"microWakeWord model not found: {model}")
    section = _public_fields(metadata, MICRO_PUBLIC_KEYS)
    section["model"] = model.name
    section["model_sha256"] = sha256_file(model)
    section["model_size_bytes"] = model.stat().st_size
    bundle = _base_bundle(load_bundle(trained_dir, safe_word), safe_word, phrase)
    bundle["micro_wake_word"] = section
    path = _atomic_write(bundle_path(trained_dir, safe_word), bundle)
    prune_unreferenced_companion_artifacts(trained_dir, safe_word, bundle)
    return path


def publish_wake_boundary(
    *,
    trained_dir: Path,
    safe_word: str,
    phrase: str,
    model_path: Path,
    metadata: Mapping[str, Any] | None = None,
) -> Path:
    """Publish the causal wake-end scorer shared by every detector mode."""
    model = Path(model_path).resolve()
    if not model.is_file():
        raise RuntimeError(f"wake boundary model not found: {model}")
    if model.stat().st_size > MAX_BOUNDARY_MODEL_BYTES:
        raise ValueError(
            f"wake boundary model exceeds {MAX_BOUNDARY_MODEL_BYTES} bytes"
        )
    source = dict(metadata or {})
    threshold = float(source.get("threshold", 0.80))
    arena = int(source.get("tensor_arena_size", 64 * 1024))
    if not 0.0 < threshold <= 1.0:
        raise ValueError("wake boundary threshold must be between 0 and 1")
    if not 64 * 1024 <= arena <= MAX_BOUNDARY_ARENA_BYTES:
        raise ValueError("wake boundary tensor arena must be between 65536 and 262144 bytes")
    section = _public_fields(source, BOUNDARY_PUBLIC_KEYS)
    section.update(
        {
            "type": "wake_word_end",
            "model": model.name,
            "model_sha256": sha256_file(model),
            "model_size_bytes": model.stat().st_size,
            "model_format": "tflite_stream_state_internal_quant",
            "quantization": "int8",
            "sample_rate": 16000,
            "threshold": threshold,
            "tensor_arena_size": arena,
            "search_before_ms": int(source.get("search_before_ms", 700)),
            "search_after_ms": int(source.get("search_after_ms", 120)),
            "endpoint_offset_ms": int(source.get("endpoint_offset_ms", 0)),
            "training_strategy": str(source.get("training_strategy") or "endpoint_hard_negative_v1"),
        }
    )
    section.setdefault(
        "frontend",
        {
            "name": "tflm_microfrontend",
            "sample_rate": 16000,
            "feature_duration_ms": 30,
            "feature_step_ms": 10,
            "feature_size": 40,
            "input_feature_frames": 2,
            "lower_band_limit": 125.0,
            "upper_band_limit": 7500.0,
        },
    )
    bundle = _base_bundle(load_bundle(trained_dir, safe_word), safe_word, phrase)
    bundle["wake_boundary"] = section
    path = _atomic_write(bundle_path(trained_dir, safe_word), bundle)
    prune_unreferenced_companion_artifacts(trained_dir, safe_word, bundle)
    return path


def publish_open_wake_word(
    *,
    trained_dir: Path,
    safe_word: str,
    phrase: str,
    metadata: Mapping[str, Any],
    artifacts: Mapping[str, Any],
    recommended_threshold: float,
    recommended_patience: int,
    recommended_confirmation_threshold: float,
    recommended_confirmation_patience: int,
) -> Path:
    section = _public_fields(metadata, OPEN_PUBLIC_KEYS)
    section.update(
        {
            "type": "open_wake_word",
            "artifacts": copy.deepcopy(dict(artifacts)),
            "recommended_threshold": recommended_threshold,
            "recommended_patience": recommended_patience,
            "recommended_confirmation_threshold": recommended_confirmation_threshold,
            "recommended_confirmation_patience": recommended_confirmation_patience,
        }
    )
    bundle = _base_bundle(load_bundle(trained_dir, safe_word), safe_word, phrase)
    bundle["open_wake_word"] = section
    path = _atomic_write(bundle_path(trained_dir, safe_word), bundle)
    prune_unreferenced_companion_artifacts(trained_dir, safe_word, bundle)
    return path


def publish_nano_wake_word(
    *,
    trained_dir: Path,
    safe_word: str,
    phrase: str,
    architecture: str,
    metadata: Mapping[str, Any],
    model_path: Path,
    recommended_threshold: float = 0.90,
    recommended_patience: int = 2,
) -> Path:
    architecture = str(architecture).strip().lower()
    if architecture not in {"cnn", "gru"}:
        raise ValueError(f"Unsupported NanoWakeWord architecture: {architecture}")
    model = Path(model_path).resolve()
    if not model.is_file():
        raise RuntimeError(f"NanoWakeWord model not found: {model}")
    if not 0.0 < float(recommended_threshold) <= 1.0:
        raise ValueError("NanoWakeWord recommended threshold must be between 0 and 1")
    if int(recommended_patience) < 1:
        raise ValueError("NanoWakeWord recommended patience must be at least 1")
    variant = _public_fields(metadata, NANO_PUBLIC_KEYS)
    variant.update(
        {
            "type": "nano_wake_word",
            "architecture": architecture,
            "model": model.name,
            "model_sha256": sha256_file(model),
            "model_size_bytes": model.stat().st_size,
            "recommended_threshold": recommended_threshold,
            "recommended_patience": recommended_patience,
        }
    )
    bundle = _base_bundle(load_bundle(trained_dir, safe_word), safe_word, phrase)
    nano = bundle.get("nano_wake_word")
    if not isinstance(nano, dict):
        nano = {}
    variants = nano.get("variants")
    if not isinstance(variants, dict):
        variants = {}
    variants = {
        key: value
        for key, value in variants.items()
        if str(key).strip().lower() in {"cnn", "gru"}
    }
    variants[architecture] = variant
    nano["variants"] = variants
    nano["default_architecture"] = _select_nano_default(
        variants, str(nano.get("default_architecture") or "")
    )
    bundle["nano_wake_word"] = nano
    path = _atomic_write(bundle_path(trained_dir, safe_word), bundle)
    prune_unreferenced_companion_artifacts(trained_dir, safe_word, bundle)
    return path


def migrate_legacy_micro_manifest(trained_dir: Path, manifest_path: Path) -> Path | None:
    legacy_path = Path(manifest_path)
    metadata = read_json(legacy_path)
    safe_word = legacy_path.stem
    model_name = Path(str(metadata.get("model") or f"{safe_word}.tflite")).name
    model = Path(trained_dir).resolve() / model_name
    if not metadata or not model.is_file():
        return None
    migrated = publish_micro_wake_word(
        trained_dir=trained_dir,
        safe_word=safe_word,
        phrase=str(metadata.get("wake_word") or safe_word.replace("_", " ")),
        metadata=metadata,
        model_path=model,
    )
    try:
        legacy_path.unlink()
    except OSError:
        pass
    return migrated


def bundle_catalog_fields(trained_dir: Path, safe_word: str, base_url: str = "") -> dict[str, Any]:
    path = bundle_path(trained_dir, safe_word)
    bundle = read_json(path)
    if not bundle:
        return {"available_engines": []}
    prefix = str(base_url or "").rstrip("/")

    def url_for(filename: Any) -> str:
        name = Path(str(filename or "")).name
        if not name:
            return ""
        relative = f"/api/trained_wake_words/{quote(name)}"
        return f"{prefix}{relative}" if prefix else relative

    fields: dict[str, Any] = {
        "bundle_url": url_for(path.name),
        "available_engines": [],
        "dual_model": False,
    }
    micro = bundle.get("micro_wake_word")
    if isinstance(micro, dict) and str(micro.get("model") or "").endswith(".tflite"):
        fields["available_engines"].append("micro_wake_word")
        fields["model_url"] = url_for(micro.get("model"))
    oww = bundle.get("open_wake_word")
    if isinstance(oww, dict):
        artifacts = oww.get("artifacts") if isinstance(oww.get("artifacts"), dict) else {}
        onnx = next(
            (
                row for row in artifacts.values()
                if isinstance(row, dict) and str(row.get("file") or "").endswith(".onnx")
            ),
            {},
        )
        if onnx:
            fields["available_engines"].append("open_wake_word")
            fields.update(
                {
                    "openwakeword_model_url": url_for(onnx.get("file")),
                    "openwakeword_threshold": oww.get("recommended_threshold"),
                    "openwakeword_patience": oww.get("recommended_patience"),
                    "openwakeword_confirmation_threshold": oww.get("recommended_confirmation_threshold"),
                    "openwakeword_confirmation_patience": oww.get("recommended_confirmation_patience"),
                    "openwakeword_confirmation_required": bool(oww.get("confirmation_required")),
                    "openwakeword_quality_status": oww.get("quality_status"),
                    "openwakeword_quality_passed": oww.get("quality_passed"),
                }
            )
    nano = bundle.get("nano_wake_word")
    variants = nano.get("variants") if isinstance(nano, dict) and isinstance(nano.get("variants"), dict) else {}
    nano_urls: dict[str, str] = {}
    nano_quality_status: dict[str, str] = {}
    nano_quality_passed: dict[str, bool] = {}
    for architecture in ("cnn", "gru"):
        variant = variants.get(architecture)
        if not isinstance(variant, dict):
            continue
        model_url = url_for(variant.get("model"))
        if model_url:
            nano_urls[architecture] = model_url
            nano_quality_status[architecture] = str(variant.get("quality_status") or "")
            nano_quality_passed[architecture] = variant.get("quality_passed") is True
    if nano_urls:
        fields["available_engines"].append("nano_wake_word")
        fields["nanowakeword_models"] = nano_urls
        fields["nanowakeword_architectures"] = list(nano_urls)
        fields["nanowakeword_default_architecture"] = nano.get("default_architecture")
        fields["nanowakeword_quality_status"] = nano_quality_status
        fields["nanowakeword_quality_passed"] = nano_quality_passed
    boundary = bundle.get("wake_boundary")
    if isinstance(boundary, dict) and str(boundary.get("model") or "").endswith(".tflite"):
        fields["wake_boundary_available"] = True
        fields["wake_boundary_model_url"] = url_for(boundary.get("model"))
        fields["wake_boundary_threshold"] = boundary.get("threshold")
    else:
        fields["wake_boundary_available"] = False
    fields["dual_model"] = "micro_wake_word" in fields["available_engines"] and "open_wake_word" in fields["available_engines"]
    return fields
