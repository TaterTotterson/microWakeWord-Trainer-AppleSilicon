from __future__ import annotations

import json
import pathlib
import unittest


REPO_ROOT = pathlib.Path(__file__).resolve().parents[1]


class VueTrainerUiTests(unittest.TestCase):
    def test_frontend_uses_typed_vue_and_vite(self) -> None:
        package = json.loads((REPO_ROOT / "frontend" / "package.json").read_text(encoding="utf-8"))
        self.assertEqual(package["dependencies"]["vue"], "3.5.40")
        self.assertIn("vue-tsc --noEmit", package["scripts"]["build"])
        self.assertIn("vite build", package["scripts"]["build"])

        config = (REPO_ROOT / "frontend" / "vite.config.ts").read_text(encoding="utf-8")
        self.assertIn('"../static/ui"', config)
        self.assertIn('fileName: () => "trainer-ui.js"', config)

    def test_header_shows_version_from_app_metadata(self) -> None:
        app = (REPO_ROOT / "frontend" / "src" / "TrainerApp.vue").read_text(encoding="utf-8")
        styles = (REPO_ROOT / "frontend" / "src" / "trainer.css").read_text(encoding="utf-8")
        config = (REPO_ROOT / "frontend" / "vite.config.ts").read_text(encoding="utf-8")

        self.assertIn("CFBundleShortVersionString", config)
        self.assertIn("__TRAINER_VERSION__", config)
        self.assertIn("local-trainer-status", app)
        self.assertIn("trainerVersion", app)
        self.assertIn(".local-trainer-status", styles)

    def test_static_shell_loads_prebuilt_bundle(self) -> None:
        index = (REPO_ROOT / "static" / "index.html").read_text(encoding="utf-8")
        self.assertIn('id="trainer-app"', index)
        self.assertIn('/static/ui/trainer-ui.css', index)
        self.assertIn('/static/ui/trainer-ui.js', index)
        self.assertNotIn("fonts.googleapis.com", index)

        self.assertGreater((REPO_ROOT / "static" / "ui" / "trainer-ui.js").stat().st_size, 100_000)
        self.assertGreater((REPO_ROOT / "static" / "ui" / "trainer-ui.css").stat().st_size, 10_000)

    def test_theme_matches_tater_bridge_in_light_and_dark_modes(self) -> None:
        styles = (REPO_ROOT / "frontend" / "src" / "workspace.css").read_text(encoding="utf-8")
        entry = (REPO_ROOT / "frontend" / "src" / "main.ts").read_text(encoding="utf-8")
        for token in ("--bg: #f5f3ef", "--bg: #111213", "--panel: #ffffff", "--panel: #1b1c1e",
                      "--action: #b94b1a", "--action: #e87b40", "prefers-color-scheme: light"):
            self.assertIn(token, styles)
        self.assertGreater(entry.index('"./workspace.css"'), entry.index('"./trainer.css"'))

    def test_reactive_ui_keeps_trainer_workflows(self) -> None:
        app = (REPO_ROOT / "frontend" / "src" / "TrainerApp.vue").read_text(encoding="utf-8")
        store = (REPO_ROOT / "frontend" / "src" / "trainerStore.ts").read_text(encoding="utf-8")
        trim = (REPO_ROOT / "frontend" / "src" / "components" / "AudioTrimModal.vue").read_text(encoding="utf-8")

        for workflow in (
            "startSession",
            "stopSession",
            "startTraining",
            "saveAuto",
            "runAutoAction",
            "reviewCaptured",
            "uploadSelectedFiles",
            "deleteManagedData",
        ):
            self.assertIn(workflow, app)

        for endpoint in (
            "/api/start_session",
            "/api/stop_session",
            "/api/upload_personal_sample",
            "/api/captured_audio",
            "/api/auto_train",
            "/api/train_status",
            "/api/trained_wake_words/catalog",
            "/api/data",
        ):
            self.assertIn(endpoint, store)

        self.assertIn("OfflineAudioContext", trim)
        self.assertIn("/api/samples/trim", trim)
        self.assertIn(':disabled="Boolean(trainer.session.safe_word)', app)
        self.assertIn("changeView('data')", app)

    def test_training_console_pauses_follow_mode_when_scrolled_up(self) -> None:
        app = (REPO_ROOT / "frontend" / "src" / "TrainerApp.vue").read_text(encoding="utf-8")

        self.assertIn("const consoleFollowing = ref(true)", app)
        self.assertIn("distanceFromBottom <= 32", app)
        self.assertIn('if (!consoleFollowing.value) return', app)
        self.assertIn('@scroll.passive="onConsoleScroll"', app)
        self.assertIn("Jump to latest", app)

    def test_training_console_has_one_themed_progress_card(self) -> None:
        app = (REPO_ROOT / "frontend" / "src" / "TrainerApp.vue").read_text(encoding="utf-8")
        styles = (REPO_ROOT / "frontend" / "src" / "trainer.css").read_text(encoding="utf-8")
        types = (REPO_ROOT / "frontend" / "src" / "types.ts").read_text(encoding="utf-8")

        self.assertIn('class="console-progress"', app)
        self.assertIn("trainingProgressPercent", app)
        self.assertIn("console-progress-scan", styles)
        self.assertIn("progress?: TrainingProgress | null", types)

    def test_data_view_exposes_native_macos_folder_picker(self) -> None:
        app = (REPO_ROOT / "frontend" / "src" / "TrainerApp.vue").read_text(encoding="utf-8")
        store = (REPO_ROOT / "frontend" / "src" / "trainerStore.ts").read_text(encoding="utf-8")
        types = (REPO_ROOT / "frontend" / "src" / "types.ts").read_text(encoding="utf-8")

        self.assertIn("Change Folder…", app)
        self.assertIn("macDataFolderPickerAvailable", app)
        self.assertIn("wakeWordTrainerStorage", store)
        self.assertIn('handler.postMessage({ action: "choose" })', store)
        self.assertIn("data_directory?: string", types)

    def test_all_wake_word_model_targets_are_selectable(self) -> None:
        app = (REPO_ROOT / "frontend" / "src" / "TrainerApp.vue").read_text(encoding="utf-8")
        store = (REPO_ROOT / "frontend" / "src" / "trainerStore.ts").read_text(encoding="utf-8")
        styles = (REPO_ROOT / "frontend" / "src" / "trainer.css").read_text(encoding="utf-8")
        for target in ("trainMicroWakeWord", "trainOpenWakeWord", "trainNanoWakeWordCnn", "trainNanoWakeWordGru"):
            self.assertIn(target, app)
            self.assertIn(target, store)
        for field in ("train_microwakeword", "train_openwakeword", "train_nanowakeword_cnn", "train_nanowakeword_gru"):
            self.assertIn(field, store)
        self.assertEqual(app.count('class="model-choice-grid"'), 2)
        self.assertEqual(app.count('class="nano-architecture-grid"'), 2)
        self.assertIn("toggleManualNano", app)
        self.assertIn("toggleAutoNano", app)
        self.assertIn(".model-choice.active", styles)
        self.assertIn(".nano-architecture-panel", styles)

    def test_saved_positive_and_negative_cards_keep_stt_results_visible(self) -> None:
        app = (REPO_ROOT / "frontend" / "src" / "TrainerApp.vue").read_text(encoding="utf-8")
        types = (REPO_ROOT / "frontend" / "src" / "types.ts").read_text(encoding="utf-8")

        self.assertEqual(app.count('v-if="item.transcript" class="transcript"'), 2)
        self.assertEqual(app.count('v-if="item.auto_review_guided_transcript"'), 2)
        self.assertIn("auto_review_guided_transcript?: string", types)

    def test_wake_word_card_uses_explicit_json_catalog_url(self) -> None:
        app = (REPO_ROOT / "frontend" / "src" / "components" / "WordWorkspace.vue").read_text(encoding="utf-8")
        types = (REPO_ROOT / "frontend" / "src" / "types.ts").read_text(encoding="utf-8")

        self.assertIn("catalog.value?.json_url || catalog.value?.url || catalog.value?.jsonUrl", app)
        self.assertIn("copyWakeWord(item.url)", app)
        self.assertNotIn("copyWakeWord(word.url)", app)
        self.assertIn("json_url?: string", types)

    def test_wake_words_tab_exposes_esphome_manifest_urls(self) -> None:
        app = (REPO_ROOT / "frontend" / "src" / "components" / "WordWorkspace.vue").read_text(encoding="utf-8")
        types = (REPO_ROOT / "frontend" / "src" / "types.ts").read_text(encoding="utf-8")

        self.assertIn("ESPHome JSON", app)
        self.assertIn("selected.value.esphome_json_url", app)
        self.assertIn("Copy {{ item.key === 'bundle' ? 'bundle JSON URL' : 'ESPHome URL' }}", app)
        self.assertIn("esphome_json_url?: string", types)

    def test_wake_words_tab_exposes_boundary_model_urls(self) -> None:
        app = (REPO_ROOT / "frontend" / "src" / "components" / "WordWorkspace.vue").read_text(encoding="utf-8")
        types = (REPO_ROOT / "frontend" / "src" / "types.ts").read_text(encoding="utf-8")

        self.assertIn("word.wake_boundary_model_url", app)
        self.assertIn("Wake boundary model ·", app)
        self.assertIn("wake boundary · threshold", app)
        self.assertIn("wake_boundary_model_url?: string", types)
        self.assertIn("wake_boundary_threshold?: number", types)

    def test_guided_flow_and_version_selection_are_explicit(self) -> None:
        app = (REPO_ROOT / "frontend/src/TrainerApp.vue").read_text(encoding="utf-8")
        welcome = (REPO_ROOT / "frontend/src/components/TrainerWelcome.vue").read_text(encoding="utf-8")
        word = (REPO_ROOT / "frontend/src/components/WordWorkspace.vue").read_text(encoding="utf-8")
        store = (REPO_ROOT / "frontend/src/trainerStore.ts").read_text(encoding="utf-8")
        for action in ("Create a wake word", "Browse wake words", "Open word"):
            self.assertIn(action, welcome)
        browse = app.split("function openWord(", 1)[1].split("async function createWord", 1)[0]
        self.assertNotIn("startSession", browse)
        self.assertNotIn("useSavedWord", browse)
        self.assertIn("trainer.activeView = \"word\"", browse)
        self.assertIn("publishSavedVersion(word, selected)", word)
        self.assertIn("!selected?.restorable || trainer.training.running", word)
        self.assertLess(word.index('class="json-link-grid"'), word.index("Raw model files"))
        self.assertIn("/publish`", store)
        self.assertIn("Compare with current", word)

    def test_training_is_a_full_page_with_persistent_running_status(self) -> None:
        app = (REPO_ROOT / "frontend/src/TrainerApp.vue").read_text(encoding="utf-8")
        self.assertIn("trainer.activeView === 'training'", app)
        self.assertIn('class="training-status-strip"', app)
        self.assertNotIn('class="modal console-modal"', app)
        self.assertIn("Current stage progress", app)
        self.assertIn("trainingStages", app)
        self.assertIn("Jump to latest", app)
        self.assertIn("Stop training", app)

    def test_runtime_packaging_uses_bundle_without_node(self) -> None:
        dockerfiles = [REPO_ROOT / "dockerfile", REPO_ROOT / "dockerfile.blackwell"]
        for dockerfile in dockerfiles:
            if not dockerfile.exists():
                continue
            source = dockerfile.read_text(encoding="utf-8")
            self.assertIn("COPY --chown=root:root static/ /root/mww-scripts/static/", source)
            self.assertNotIn("npm install", source)
            self.assertIn("wake_word_versions.py", source)

        macos_builder = REPO_ROOT / "macos" / "WakeWordTrainer" / "scripts" / "build_app.sh"
        if macos_builder.exists():
            source = macos_builder.read_text(encoding="utf-8")
            self.assertIn("--exclude='frontend/node_modules/'", source)
            self.assertNotIn("--exclude='static/'", source)


if __name__ == "__main__":
    unittest.main()
