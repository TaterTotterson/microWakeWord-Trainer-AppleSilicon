import type { JsonRecord } from "./api";

export type ViewName = "home" | "word" | "training" | "trainer" | "auto" | "firmware" | "captured" | "samples" | "data";
export type SampleBucket = "personal" | "negative";

export interface LanguageOption extends JsonRecord {
  code: string;
  label: string;
  engines?: string[];
  quality?: string;
}

export interface AccentOption extends JsonRecord {
  code: string;
  label: string;
}

export interface TrainingState extends JsonRecord {
  running: boolean;
  exit_code: number | null;
  log_lines: string[];
  summary?: TrainingSummary | null;
  progress?: TrainingProgress | null;
}

export interface TrainingProgress extends JsonRecord {
  stage?: string;
  label: string;
  current?: number | null;
  total?: number | null;
  percent?: number | null;
  elapsed?: string;
  eta?: string;
  rate?: number | null;
  rate_text?: string;
  unit?: string;
  status?: string;
}

export interface TrainingSummaryMetric extends JsonRecord {
  label: string;
  value: string;
}

export interface TrainingSummaryModel extends JsonRecord {
  id: string;
  label: string;
  status: string;
  rating: string;
  tone: string;
  message: string;
  metrics: TrainingSummaryMetric[];
}

export interface TrainingSummary extends JsonRecord {
  wake_word: string;
  completed_at?: string;
  overall: string;
  tone: string;
  message: string;
  models: TrainingSummaryModel[];
}

export interface SessionPayload extends JsonRecord {
  safe_word?: string;
  raw_phrase?: string;
  language?: string;
  english_accent?: string;
  tts_mode?: string;
  takes_received?: number;
  available_languages?: LanguageOption[];
  available_english_accents?: AccentOption[];
  training?: TrainingState;
}

export interface AudioItem extends JsonRecord {
  capture_id?: string;
  capture_scope?: string;
  dataset_wake_word?: string;
  review_wake_word?: string;
  assignment_status?: "assigned" | "unassigned";
  saved_as: string;
  original_name?: string;
  audio_url?: string;
  final_format?: JsonRecord;
  transcript?: string;
  transcribed_at?: string;
  auto_review_guided_transcript?: string;
  auto_review_stt_engine?: string;
  auto_review_stt_model?: string;
}

export interface SamplesPayload extends JsonRecord {
  personal: AudioItem[];
  negative: AudioItem[];
  personal_count: number;
  negative_count: number;
}

export interface CapturedPayload extends JsonRecord {
  items: AudioItem[];
  captured_count: number;
  personal_count: number;
  negative_count: number;
}

export interface AutoTrainForm extends JsonRecord {
  enabled: boolean;
  wake_phrase: string;
  language: string;
  english_accent: string;
  stt_engine: string;
  minimum_transcript_chars: number;
  delete_confirmed_wakes: boolean;
  promote_close_misses: boolean;
  schedule_hours: number;
  minimum_new_negatives: number;
  advertised_base_url: string;
  tater_url: string;
  notify_satellites: boolean;
  train_microwakeword: boolean;
  train_openwakeword: boolean;
  train_nanowakeword_cnn: boolean;
  train_nanowakeword_gru: boolean;
  generated_negative_phrases: string;
}

export interface AutoTrainPayload extends JsonRecord {
  config?: Partial<AutoTrainForm>;
  state?: JsonRecord;
  runtime?: JsonRecord;
  trainer_link?: JsonRecord;
  advertised_base_url?: string;
}

export interface WakeWordItem extends JsonRecord {
  key?: string;
  label?: string;
  url?: string;
  json_url?: string;
  jsonUrl?: string;
  esphome_json_url?: string;
  esphomeJsonUrl?: string;
  model_url?: string;
  modelUrl?: string;
  dual_model?: boolean;
  bundle_url?: string;
  openwakeword_model_url?: string;
  wake_boundary_available?: boolean;
  wake_boundary_model_url?: string;
  wake_boundary_threshold?: number;
  available_engines?: string[];
  nanowakeword_architectures?: string[];
  nanowakeword_models?: Record<string, string>;
}

export interface WakeWordLibraryItem extends JsonRecord {
  safe_word: string;
  phrase: string;
  language?: string;
  english_accent?: string;
  tts_mode?: string;
  active: boolean;
  published_run_id?: string;
  personal_count?: number;
  negative_count?: number;
  has_published_bundle: boolean;
  boundary_only_ready?: boolean;
  dataset_size_bytes: number;
  dataset_file_count: number;
  run_count: number;
  latest_run?: TrainingRun | null;
}

export interface TrainingRun extends JsonRecord {
  run_id: string;
  run_kind: string;
  safe_word: string;
  wake_word: string;
  completed_at: string;
  selected_models: string[];
  summary?: TrainingSummary;
  version?: number;
  is_current?: boolean;
  restorable?: boolean;
  json_url?: string;
  esphome_json_url?: string;
  artifact_urls?: Record<string, string>;
  artifacts?: string[];
}

export interface ManagedDataItem extends JsonRecord {
  id: string;
  label: string;
  category: string;
  description: string;
  location: string;
  size_bytes: number;
  file_count: number;
  exists: boolean;
  rebuild_note?: string;
}

export interface ManagedDataPayload extends JsonRecord {
  data_directory?: string;
  items: ManagedDataItem[];
  total_size_bytes: number;
  total_file_count: number;
}

export interface ToastState {
  message: string;
  tone: "success" | "warning" | "error";
  serial: number;
}
